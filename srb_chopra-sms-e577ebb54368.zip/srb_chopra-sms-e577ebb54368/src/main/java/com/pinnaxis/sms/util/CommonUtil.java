package com.pinnaxis.sms.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class CommonUtil {

    public static final DateTimeFormatter dateTimeFormatter1 = DateTimeFormatter.ofPattern("yyyy/MM/dd");
    public static final DateTimeFormatter dateTimeFormatter2 = DateTimeFormatter.ofPattern("dd-MMM-yyyy hh:mm:ss");
    public static final DateTimeFormatter dateTimeFormatter3 = DateTimeFormatter.ofPattern("MMMM-yyyy");
    public static final DateTimeFormatter dateTimeFormatter4 = DateTimeFormatter.ofPattern("ddMMyyyy");

    public static final DateTimeFormatter dateTimeFormatter5 = DateTimeFormatter.ofPattern("yyyy-MM");
    public static final DateTimeFormatter dateTimeFormatter6 = DateTimeFormatter.ofPattern("dd/MMM/yyyy");

    private static final DateTimeFormatter formatter = new DateTimeFormatterBuilder()
            .parseCaseInsensitive()
            .appendPattern("MMMM-yyyy")
            .toFormatter(Locale.ENGLISH);

    public static Map<String, Long> sortedMapByValues(List<String> sortedEntries, Map<String, Long> input) {
        return sortedEntries.stream()
                .peek(e -> {
                    if (!input.containsKey(e)) {
                        input.put(e, 0L);
                    }
                }).map(e -> new AbstractMap.SimpleEntry<>(e, input.get(e)))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                        (oldValue, newValue) -> oldValue, LinkedHashMap::new));
    }

    public static Map<Integer, List<Long>> sortedIntergerMapByValues(List<Integer> sortedEntries, Map<Integer, List<Long>> input) {
        return sortedEntries.stream()
                .peek(e -> {
                    if (!input.containsKey(e)) {
                        input.put(e, Collections.emptyList());
                    }
                }).map(e -> new AbstractMap.SimpleEntry<>(e, input.get(e)))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                        (oldValue, newValue) -> oldValue, LinkedHashMap::new));
    }

    public static LocalDate convertStringToDate(String date, DateTimeFormatter formatter) {
        return LocalDate.parse(date, formatter);
    }

    public static LocalDate convertStringToEndDate(String date, DateTimeFormatter formatter) {
        LocalDate endDate = LocalDate.parse(date, formatter);
        return endDate.withDayOfMonth(endDate.lengthOfMonth());
    }

    public static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor)
    {
        Map<Object, Boolean> map = new ConcurrentHashMap<>();
        return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }
}

