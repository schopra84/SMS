package com.pinnaxis.sms.services;

import com.pinnaxis.sms.model.SubmissionData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReportsDataSetService {

    @Autowired
    private DTOService dtoService;

    public List<SubmissionData> getReportDataSetsCaseNumber(String caseNumber) {
        List<SubmissionData> submissionDatas= dtoService.loadSubmissionData();
        return submissionDatas.parallelStream()
                .filter(c -> c.getCaseNumber().equalsIgnoreCase(caseNumber)).collect(Collectors.toList());
    }
}
