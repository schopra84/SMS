package com.pinnaxis.sms.services;

import com.pinnaxis.sms.dao.*;
import com.pinnaxis.sms.dao.model.*;
import com.pinnaxis.sms.util.SMSConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CacheService implements SMSConstant {

    @Autowired
    private CaseDetailsRepository caseDetailsRepository;

    @Autowired
    private PendingSubmissionsRepository pendingSubmissionsRepository;

    @Autowired
    private QualityRepository qualityRepository;

    @Autowired
    private ReceivedCasesRepository receivedCasesRepository;

    @Autowired
    private WorkloadRepository workloadRepository;

//    @Autowired
//    private DataMigrationRepository dataMigrationRepository;

    @Cacheable(value = VIEW_CASE_DETAILS)
    public List<CaseDetailsInfo> getCaseDetails() {
        return caseDetailsRepository.findAll();
    }

    @Cacheable(value = VIEW_PENDING_SUBMISSIONS)
    public List<PendingSubmissionsInfo> getPendingSubmissions() {
        return pendingSubmissionsRepository.findAll();
    }

    @Cacheable(value = VIEW_QUALITY)
    public List<QualityInfo> getQualityDetails() {
        return qualityRepository.findAll();
    }

    @Cacheable(value = VIEW_RECEIVED_CASES)
    public List<ReceivedCasesInfo> getReceivedCases() {
        return receivedCasesRepository.findAll();
    }

    @Cacheable(value = VIEW_WORKLOAD)
    public List<WorkloadInfo> getWorkload() {
        return workloadRepository.findAll();
    }

    public long migrateData(long piModuleType, long piMethodType) {
        return caseDetailsRepository.migrateExecution(piModuleType, piMethodType);
    }

    @Caching(evict = {
            @CacheEvict(value = SMSConstant.VIEW_CASE_DETAILS, allEntries = true),
            @CacheEvict(value = SMSConstant.VIEW_PENDING_SUBMISSIONS, allEntries = true),
            @CacheEvict(value = SMSConstant.VIEW_QUALITY, allEntries = true),
            @CacheEvict(value = SMSConstant.VIEW_RECEIVED_CASES, allEntries = true),
            @CacheEvict(value = SMSConstant.VIEW_WORKLOAD, allEntries = true)
    })
    public void clearCache() {
        //This method will remove entries from cache.
    }

    public void reloadCache() {
        getCaseDetails();
        getPendingSubmissions();
        getQualityDetails();
        getReceivedCases();
        getWorkload();
    }

}
