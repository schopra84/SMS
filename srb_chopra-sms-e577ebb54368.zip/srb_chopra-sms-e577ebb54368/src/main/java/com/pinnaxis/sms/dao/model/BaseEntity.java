package com.pinnaxis.sms.dao.model;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@MappedSuperclass
public class BaseEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CASE_ID") private Long caseId;
    @Column(name = "DELETED_DATE") private LocalDate deletedDate;
    @Column(name = "DUE_SOON") private LocalDate dueSoon;
    @Column(name = "CASE_NUM") private String caseNum;
    @Column(name = "COUNTRY") private String country;
    @Column(name = "USER_NAME") private String userName;
    @Column(name = "EVENT_NAME") private String eventName;
    @Column(name = "AWARE_DATE") private LocalDate awareDate;
    @Column(name = "PRODUCT_NAME") private String productName;
    @Column(name = "SERIOUSNESS") private String seriousness;
    @Column(name = "GENERIC_NAME") private String genericName;
    @Column(name = "STUDY_NUM") private String studyNum;
    @Column(name = "REPORT_TYPE") private String reportType;
    @Column(name = "STATE_NAME") private String stateName;
    @Column(name = "INIT_REPT_DATE") private LocalDate initReptDate;
    @Column(name = "GROUP_NAME") private String groupName;
    @Column(name = "CASE_CAUSALITY") private String caseCausality;
    @Column(name = "LAST_UPDATE_TIME") private LocalDate lastUpdateTime;
    @Column(name = "OTHER_PRODUCTS") private String otherProducts;
    @Column(name = "NO_OF_SUBMISSION") private Long noOfSubmission;
    @Column(name = "NO_OF_CONTACT_LOG") private Long noOfContactLog;
    @Column(name = "LOCK_DATE") private LocalDate lockDate;
    @Column(name = "OPEN_CLOSE_CASE") private Long openCloseCase;
    @Column(name = "STATE_ID") private Long stateId;
    @Column(name = "CREATED_USER_NAME") private String createdUserName;

    public Long getCaseId() {
        return caseId;
    }

    public void setCaseId(Long caseId) {
        this.caseId = caseId;
    }

    public LocalDate getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(LocalDate deletedDate) {
        this.deletedDate = deletedDate;
    }

    public LocalDate getDueSoon() {
        return dueSoon;
    }

    public void setDueSoon(LocalDate dueSoon) {
        this.dueSoon = dueSoon;
    }

    public String getCaseNum() {
        return caseNum;
    }

    public void setCaseNum(String caseNum) {
        this.caseNum = caseNum;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public LocalDate getAwareDate() {
        return awareDate;
    }

    public void setAwareDate(LocalDate awareDate) {
        this.awareDate = awareDate;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getSeriousness() {
        return seriousness;
    }

    public void setSeriousness(String seriousness) {
        this.seriousness = seriousness;
    }

    public String getGenericName() {
        return genericName;
    }

    public void setGenericName(String genericName) {
        this.genericName = genericName;
    }

    public String getStudyNum() {
        return studyNum;
    }

    public void setStudyNum(String studyNum) {
        this.studyNum = studyNum;
    }

    public String getReportType() {
        return reportType;
    }

    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public LocalDate getInitReptDate() {
        return initReptDate;
    }

    public void setInitReptDate(LocalDate initReptDate) {
        this.initReptDate = initReptDate;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getCaseCausality() {
        return caseCausality;
    }

    public void setCaseCausality(String caseCausality) {
        this.caseCausality = caseCausality;
    }

    public LocalDate getLastUpdateTime() {
        return lastUpdateTime;
    }

    public void setLastUpdateTime(LocalDate lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }

    public String getOtherProducts() {
        return otherProducts;
    }

    public void setOtherProducts(String otherProducts) {
        this.otherProducts = otherProducts;
    }

    public Long getNoOfSubmission() {
        return noOfSubmission;
    }

    public void setNoOfSubmission(Long noOfSubmission) {
        this.noOfSubmission = noOfSubmission;
    }

    public Long getNoOfContactLog() {
        return noOfContactLog;
    }

    public void setNoOfContactLog(Long noOfContactLog) {
        this.noOfContactLog = noOfContactLog;
    }

    public LocalDate getLockDate() {
        return lockDate;
    }

    public void setLockDate(LocalDate lockDate) {
        this.lockDate = lockDate;
    }

    public Long getOpenCloseCase() {
        return openCloseCase;
    }

    public void setOpenCloseCase(Long openCloseCase) {
        this.openCloseCase = openCloseCase;
    }

    public Long getStateId() {
        return stateId;
    }

    public void setStateId(Long stateId) {
        this.stateId = stateId;
    }

    public String getCreatedUserName() {
        return createdUserName;
    }

    public void setCreatedUserName(String createdUserName) {
        this.createdUserName = createdUserName;
    }
}
