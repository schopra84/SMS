package com.pinnaxis.sms.model;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public class LineChart {
    private String title;
    private String subTitle;
    private List<String> xCategories;
    private String yTitle;
    private List<Map<String, Object>>  series;
    private Map<String, Collection<List<Long>>> toolTip;

    public LineChart(String title, String subTitle, String yTitle) {
        this.title = title;
        this.subTitle = subTitle;
        this.yTitle = yTitle;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubTitle() {
        return subTitle;
    }

    public void setSubTitle(String subTitle) {
        this.subTitle = subTitle;
    }

    public List<String> getxCategories() {
        return xCategories;
    }

    public void setxCategories(List<String> xCategories) {
        this.xCategories = xCategories;
    }

    public String getyTitle() {
        return yTitle;
    }

    public void setyTitle(String yTitle) {
        this.yTitle = yTitle;
    }

    public List<Map<String, Object>> getSeries() {
        return series;
    }

    public void setSeries(List<Map<String, Object>> series) {
        this.series = series;
    }

    public Map<String, Collection<List<Long>>> getToolTip() {
        return toolTip;
    }

    public void setToolTip(Map<String, Collection<List<Long>>> toolTip) {
        this.toolTip = toolTip;
    }
}
