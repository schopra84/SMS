package com.pinnaxis.sms.services;

import com.pinnaxis.sms.config.ApplicationProperties;
import com.pinnaxis.sms.model.*;
import com.pinnaxis.sms.util.CommonUtil;
import com.pinnaxis.sms.util.SMSConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@ConfigurationProperties("app")
public class TrackCaseService implements SMSConstant {

    private List<String> reportTypeSortOrder;
    private List<String> caseSeriousness;
    private List<String> dueSoon;
    private List<String> noProgress;
    private List<String> pastDue;
    private List<String> currentDays;

    private String toadyDue;

    @Autowired
    private DTOService dtoService;

    @Autowired
    private ApplicationProperties properties;

    @PostConstruct
    public void init() {
        reportTypeSortOrder = properties.getReportType();
        caseSeriousness = new ArrayList<>();
        caseSeriousness.add("Serious");
        caseSeriousness.add("Non Serious");

        pastDue = new ArrayList<>();
        pastDue.add("<-3");
        pastDue.add("-3");
        pastDue.add("-2");
        pastDue.add("-1");

        toadyDue = "0";

        currentDays = new ArrayList<>();
        currentDays.add("1");
        currentDays.add("2");
        currentDays.add("3");
        currentDays.add(">3");

        dueSoon = new ArrayList<>();
        dueSoon.add(PAST_DUE);
        dueSoon.add(TODAY_DUE);
        dueSoon.add("1 Day");
        dueSoon.add("2 Day");
        dueSoon.add("3 Day");
        dueSoon.add(">3 Day");

        noProgress = new ArrayList<>();
        noProgress.add("1");
        noProgress.add("2");
        noProgress.add("3");
        noProgress.add("4");
        noProgress.add("5");
        noProgress.add("> 5");

    }

    public void populateWorkflowStateData(WorkflowState workflowState, String workflowSate, String todayDateVal) throws ParseException {
        LocalDate todayDate = CommonUtil.convertStringToDate(todayDateVal, CommonUtil.dateTimeFormatter4);
        List<OpenCase> allOpenCases = dtoService.loadOpenCases(todayDate);

        Supplier<Stream<OpenCase>> openCases = () -> allOpenCases.parallelStream()
                .filter(c -> c.getWorkflowStateCategory().equalsIgnoreCase(workflowSate) && Objects.isNull(c.getDeletedDate()))
                .peek(c -> {
                    if(pastDue.contains(c.getDueSoon())) {
                        c.setDueSoon(PAST_DUE);
                    } else if(c.getDueSoon().equalsIgnoreCase(toadyDue)) {
                        c.setDueSoon(TODAY_DUE);
                    } else if(currentDays.contains(c.getDueSoon())) {
                        c.setDueSoon(c.getDueSoon() + " Day");
                    }
                });
        Map<String, Long> caseSeriousnessMap = CommonUtil.sortedMapByValues(caseSeriousness,openCases.get().collect(Collectors.groupingBy(OpenCase::getCaseSeriousness, Collectors.counting())));
        Map<String, Long> dueSoonMap = CommonUtil.sortedMapByValues(dueSoon,openCases.get().filter(e -> !StringUtils.isEmpty(e.getDueSoon())).collect(Collectors.groupingBy(OpenCase::getDueSoon, Collectors.counting())));
        Map<String, Long> noProgressMap = CommonUtil.sortedMapByValues(noProgress,openCases.get().collect(Collectors.groupingBy(OpenCase::getNoProgress, Collectors.counting())));
        Map<String, Long> reportStatusMap = CommonUtil.sortedMapByValues(reportTypeSortOrder, openCases.get().collect(Collectors.groupingBy(OpenCase::getReportType, Collectors.counting())));

        long totalCases = openCases.get().collect(Collectors.counting());
        workflowState.setReportStatus(reportStatusMap);
        workflowState.setNoProgress(noProgressMap);
        workflowState.setDueSoon(dueSoonMap);
        workflowState.setCaseSeriousness(caseSeriousnessMap);
        workflowState.setTotalCases(totalCases);
    }

    public void populateDueSoonData(DueSoon dueSoon, String days, String todayDateVal) {
        LocalDate todayDate = CommonUtil.convertStringToDate(todayDateVal, CommonUtil.dateTimeFormatter4);
        List<OpenCase> allOpenCases = dtoService.loadOpenCases(todayDate);
        Set<String> filter = new HashSet<>();
        Collections.addAll(filter, days.split(","));

        Supplier<Stream<OpenCase>> openCases = () -> allOpenCases.stream()
        .filter(c -> filter.contains(c.getDueSoon()) && Objects.isNull(c.getDeletedDate()));

        Map<String, Long> noProgressMap = CommonUtil.sortedMapByValues(noProgress,openCases.get().collect(Collectors.groupingBy(OpenCase::getNoProgress, Collectors.counting())));
        Map<String, Long> reportStatusMap = CommonUtil.sortedMapByValues(reportTypeSortOrder, openCases.get().collect(Collectors.groupingBy(OpenCase::getReportType, Collectors.counting())));

        WorkflowState dataEntry = new WorkflowState();
        populateCaseSeriousness("Data Entry", openCases, dataEntry);
        WorkflowState qualityReview = new WorkflowState();
        populateCaseSeriousness("Quality Review", openCases, qualityReview);
        WorkflowState medicalReview = new WorkflowState();
        populateCaseSeriousness("Medical Review", openCases, medicalReview);
        WorkflowState distribution = new WorkflowState();
        populateCaseSeriousness("Distribution", openCases, distribution);
        long totalCases = openCases.get().collect(Collectors.counting());

        dueSoon.setDataEntry(dataEntry);
        dueSoon.setQualityReview(qualityReview);
        dueSoon.setMedicalReview(medicalReview);
        dueSoon.setDistribution(distribution);
        dueSoon.setNoProgress(noProgressMap);
        dueSoon.setReportStatus(reportStatusMap);
        dueSoon.setTotalCases(totalCases);
    }

    private void populateCaseSeriousness(String stateCategory, Supplier<Stream<OpenCase>> openCases, WorkflowState workflowState){
        Supplier<Stream<OpenCase>> stateCategorgySupplier = () -> openCases.get()
                .filter(c -> c.getWorkflowStateCategory().equalsIgnoreCase(stateCategory));
        Map<String, Long> caseSeriousnessMap = CommonUtil.sortedMapByValues(caseSeriousness,stateCategorgySupplier.get().collect(Collectors.groupingBy(OpenCase::getCaseSeriousness, Collectors.counting())));
        long totalCases = stateCategorgySupplier.get().collect(Collectors.counting());
        workflowState.setTotalCases(totalCases);
        workflowState.setCaseSeriousness(caseSeriousnessMap);
    }

    public List<OpenCase> getCaseDetails(String todayDateVal, String type1, String filter1,
            String type2, String filter2, String type3, String filter3) {
        final Set<String> set = new HashSet<>();
        Collections.addAll(set, filter1.split(","));
        LocalDate todayDate = CommonUtil.convertStringToDate(todayDateVal, CommonUtil.dateTimeFormatter4);
        List<OpenCase> allOpenCases = dtoService.loadOpenCases(todayDate);
        List<OpenCase> openCases = allOpenCases.parallelStream()
                .filter(c -> Objects.isNull(c.getDeletedDate()))
                .filter(c -> {
                    boolean filter = false;
                    switch (type1) {
                        case "stateCategorgy":
                            filter = c.getWorkflowStateCategory().equalsIgnoreCase(filter1);
                            break;
                        case "User":
                            filter = c.getUserName().equalsIgnoreCase(filter1);
                            break;
                        case "Group":
                            filter = c.getStateName().equalsIgnoreCase(filter1);
                            break;
                        default:
                            break;
                    }
                    return filter;
                })
                .filter(c -> {
                    boolean filter = true;
                    switch (type2) {
                        case "caseType":
                            filter = c.getReportType().equalsIgnoreCase(filter2);
                            break;
                        case "caseSeriousness":
                            filter = String.valueOf(c.getCaseSeriousness()).equalsIgnoreCase(filter2);
                            break;
                        case "stateCategorgy":
                            filter = c.getWorkflowStateCategory().equalsIgnoreCase(filter2);
                            break;
                        case "dueSoon":
                            if(filter2.equalsIgnoreCase(PAST_DUE)) {
                                filter = Objects.nonNull(c.getDueSoon()) ? pastDue.contains(c.getDueSoon()) : false;
                            } else if (filter2.equalsIgnoreCase(TODAY_DUE)) {
                                filter = Objects.nonNull(c.getDueSoon()) ? c.getDueSoon().equalsIgnoreCase(toadyDue) : false;
                            } else {
                                filter = Objects.nonNull(c.getDueSoon()) ? c.getDueSoon().equalsIgnoreCase(filter2.replace(" Day", BLANK)) : false;
                            }
                            break;
                        case "noProgress":
                            filter = c.getNoProgress().equalsIgnoreCase(filter2);
                            break;
                        default:
                            break;
                    }
                    return filter;
                })
                .filter(c -> {
                    boolean filter = true;
                    if(!StringUtils.isEmpty(type3)){
                        filter = c.getWorkflowStateCategory().equalsIgnoreCase(filter3);
                    }
                    return filter;
                })
                .collect(Collectors.toList());
        return openCases;
    }
}
