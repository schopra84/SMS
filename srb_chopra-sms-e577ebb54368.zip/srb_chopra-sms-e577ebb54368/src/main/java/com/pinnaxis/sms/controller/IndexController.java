package com.pinnaxis.sms.controller;

import com.pinnaxis.sms.model.KeyIndicatorVo;
import com.pinnaxis.sms.model.OpenCase;
import com.pinnaxis.sms.model.SubmissionData;
import com.pinnaxis.sms.services.DashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@SessionAttributes("userName")
public class IndexController {

    @Autowired
    private DashboardService dashboardService;

    @RequestMapping("/dashboard")
    public String dashboard(){
        return "dashboard";
    }

    @RequestMapping("/keyIndicators")
    public String getKeyIndicators(@RequestParam(value = "todayDate") String todayDate,
                            Model model){
        List<List<KeyIndicatorVo>> keyIndicatorsVo = dashboardService.getKeyIndicators(todayDate);
        model.addAttribute("keyIndicatorsVo", keyIndicatorsVo);
        return "keyIndicators";
    }

    @RequestMapping("/loginUser")
    public ResponseEntity loginUser(@ModelAttribute("userName") String userName){
        return ResponseEntity.ok(userName);
    }

    @RequestMapping(value = "/keyIndicatorsOpenCases", method = RequestMethod.GET)
    public ResponseEntity<?> keyIndicatorsOpenCases(
            @RequestParam(value = "todayDate") String todayDate,
            @RequestParam(value = "filterType") String filterType) {
        List<OpenCase> openCases = dashboardService.getOpenCaseList(todayDate, filterType);
        return ResponseEntity.ok(openCases);
    }

    @RequestMapping(value = "/keyIndicatorsSubmissionCases", method = RequestMethod.GET)
    public ResponseEntity<?> keyIndicatorsSubmissionCases() {
        List<SubmissionData> submissionCases = dashboardService.getSubmissionCaseList();
        return ResponseEntity.ok(submissionCases);
    }
}
