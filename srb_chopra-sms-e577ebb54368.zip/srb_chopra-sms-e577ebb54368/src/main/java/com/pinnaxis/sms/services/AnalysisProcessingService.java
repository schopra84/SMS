package com.pinnaxis.sms.services;

import com.pinnaxis.sms.model.ClosedCaseAnalysis;
import com.pinnaxis.sms.model.LineChart;
import com.pinnaxis.sms.util.CommonUtil;
import com.pinnaxis.sms.util.SMSConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@Component
public class AnalysisProcessingService implements SMSConstant {

    @Autowired
    private DTOService dtoService;

    public LineChart getMonthlyProcessingCaseCount(String caseType, String dateFilter) {
        LineChart chart = new LineChart("Case Count", "", "Count");

        int range;
        switch (dateFilter) {
            case "3m":
                range = 3;
                break;
            case "6m":
                range = 6;
                break;
            case "9m":
                range = 9;
                break;
            case "1y":
                range = 12;
                break;
            default:
                range = 0;
                break;
        }
        final YearMonth ym = YearMonth.now();
        List<YearMonth> lastOneYear = revRange(0, range)
                .boxed().map(i -> ym.minusMonths(i)).collect(Collectors.toList());
        final YearMonth pym = lastOneYear.get(0);

        LocalDate startDate = pym.atDay(1);
        LocalDate endDate = ym.atEndOfMonth();

        List<ClosedCaseAnalysis> closedCaseAnalysis = dtoService.loadClosedCaseAnalysis();
        List<ClosedCaseAnalysis> closedCasesAfterFilter = closedCaseAnalysis.stream()
                .filter(c -> {
                    boolean isFilterIn;
                    if (caseType.equalsIgnoreCase("all")) {
                        isFilterIn = true;
                    } else {
                        isFilterIn = c.getCaseType().equalsIgnoreCase(caseType);
                    }
                    return isFilterIn;
                })
                .filter(c -> Objects.nonNull(c.getClosedDate()) && (c.getClosedDate().equals(startDate) || c.getClosedDate().isAfter(startDate))
                        && (c.getClosedDate().equals(endDate) || c.getClosedDate().isBefore(endDate)))
                .collect(Collectors.toList());

        List<Integer> lastOneYearVal = lastOneYear.stream()
                .map(l -> l.getMonthValue())
                .collect(Collectors.toList());

        List<String> xCategories = lastOneYear.stream()
                .map(d -> d.getMonth().getDisplayName(TextStyle.SHORT, Locale.ENGLISH) + "/" + d.getYear())
                .collect(Collectors.toList());

        List<Map<String, Object>> series = new ArrayList();

//        LocalDateTime now = LocalDateTime.now();
//        final int month = now.getMonthValue();
//        final int day = now.getDayOfMonth();


        if(caseType.equalsIgnoreCase("all") || caseType.equalsIgnoreCase(MARKETED)) {
            Map<Integer, Long> marketedTotalData = getMonthlyAverageProcessCases(() -> closedCasesAfterFilter.stream()
                    .filter(c -> c.getCaseType().equalsIgnoreCase(MARKETED)));

            Map<Integer, Long> marketedSeriousData = getMonthlyAverageProcessCases(() -> closedCasesAfterFilter.stream()
                    .filter(c -> c.getCaseType().equalsIgnoreCase(MARKETED) && c.getCaseSeriousness().equalsIgnoreCase(SERIOUS)));

            Map<Integer, Long> marketedNoNSeriousData = getMonthlyAverageProcessCases(() -> closedCasesAfterFilter.stream()
                    .filter(c -> c.getCaseType().equalsIgnoreCase(MARKETED) && c.getCaseSeriousness().equalsIgnoreCase("Non Serious")));

            List<Map<String, Object>> marketedCases = filteredData(marketedTotalData, marketedSeriousData, marketedNoNSeriousData, null, lastOneYearVal);
            Map<String, Object> marketedCaseMap = new LinkedHashMap<>();
            marketedCaseMap.put("name", MARKETED);
            marketedCaseMap.put("data", marketedCases);
            marketedCaseMap.put("color", "#7CB5EC");
            series.add(marketedCaseMap);
        }

        if(caseType.equalsIgnoreCase("all") || caseType.equalsIgnoreCase(INVESTIGATIONAL)) {

            Map<YearMonth, Long> monthlyProcessingDaysCount = closedCasesAfterFilter.stream()
                    .filter(c -> c.getCaseType().equalsIgnoreCase(INVESTIGATIONAL))
                    .collect(Collectors.groupingBy(c ->
                        YearMonth.of(c.getClosedDate().getYear(), c.getClosedDate().getMonth())
                    ,
                    Collectors.summingLong(ClosedCaseAnalysis::getDaysProcess)
            ));

            Map<Integer, Long> investigationTotalData = getMonthlyAverageProcessCases(() -> closedCasesAfterFilter.stream()
                    .filter(c -> c.getCaseType().equalsIgnoreCase(INVESTIGATIONAL)));

            Map<Integer, Long> investigationSeriousData = getMonthlyAverageProcessCases(() -> closedCasesAfterFilter.stream()
                    .filter(c -> c.getCaseType().equalsIgnoreCase(INVESTIGATIONAL) && c.getCaseSeriousness().equalsIgnoreCase(SERIOUS)));

            Map<Integer, Long> investigationNoNSeriousData = getMonthlyAverageProcessCases(() -> closedCasesAfterFilter.stream()
                    .filter(c -> c.getCaseType().equalsIgnoreCase(INVESTIGATIONAL) && c.getCaseSeriousness().equalsIgnoreCase("Non Serious")));

            Map<Integer, Long> investigationSusarData = getMonthlyAverageProcessCases(() -> closedCasesAfterFilter.stream()
                    .filter(c -> c.getCaseType().equalsIgnoreCase(INVESTIGATIONAL) && Objects.nonNull(c.getSusar()) && c.getSusar().equalsIgnoreCase("Yes")));

            List<Map<String, Object>> investigationCases = filteredData(investigationTotalData, investigationSeriousData, investigationNoNSeriousData, investigationSusarData, lastOneYearVal);
            Map<String, Object> investigationCaseMap = new LinkedHashMap<>();
            investigationCaseMap.put("name", INVESTIGATIONAL);
            investigationCaseMap.put("data", investigationCases);
            investigationCaseMap.put("color", "#b5ec7c");
            series.add(investigationCaseMap);
        }

        chart.setxCategories(xCategories);
        chart.setSeries(series);
        chart.setyTitle("Average Case Processing Time (in Days)");
        chart.setTitle("Average Case Processing Time");
//        chart.setToolTip(toolTip);
        return chart;
    }

    private Map<Integer, Long> getMonthlyAverageProcessCases(Supplier<Stream<ClosedCaseAnalysis>> stream) {
        Map<YearMonth, Double> monthlyProcessingDaysCount = stream.get()
                .collect(Collectors.groupingBy(c ->
                            YearMonth.of(c.getClosedDate().getYear(), c.getClosedDate().getMonth()),
                        Collectors.summingDouble(ClosedCaseAnalysis::getDaysProcess)
                ));
        return stream.get()
                .collect(Collectors.groupingBy(c ->
                            YearMonth.of(c.getClosedDate().getYear(), c.getClosedDate().getMonth()),
                        Collectors.counting()
                )).entrySet().stream().peek(e -> {
//                    int days = e.getKey().lengthOfMonth();
//                    if (e.getKey().getMonthValue() == month) {
//                        days = currentDay;
//                    }
                    Double totalCount = monthlyProcessingDaysCount.get(e.getKey());
                    e.setValue(Long.valueOf(Math.round(totalCount / e.getValue())));
                })
                .collect(Collectors.toMap(entry -> entry.getKey().getMonthValue(), entry -> entry.getValue()));


//                .collect(Collectors.groupingBy(c -> {
//                    cal.setTime(c.getClosedDate());
//                    return cal.get(Calendar.MONTH) + 1;
//                },
//                Collectors.averagingLong(ClosedCaseAnalysis::getDaysProcess)))
//                .entrySet().stream()
//                .collect(Collectors.toMap(entry -> entry.getKey(), entry -> Math.round(entry.getValue())));
    }

    private List<Map<String, Object>> filteredData(Map<Integer, Long> totalCounters,
                                                   Map<Integer, Long> seriousCounters,
                                                   Map<Integer, Long> NoNSeriousCounters,
                                                   Map<Integer, Long> susarData,
                                                   List<Integer> lastOneYearVal) {
//        Map<Integer, Long> seriousCounters = seriousData.stream()
//                .collect(Collectors.groupingBy(c -> c,
//                        () -> new LinkedHashMap<>(),
//                        Collectors.counting()));
//
//        Map<Integer, Long> NoNSeriousCounters = NoNSeriousData.stream()
//                .collect(Collectors.groupingBy(c -> c,
//                        () -> new LinkedHashMap<>(),
//                        Collectors.counting()));

//        Map<Integer, List<Integer>> counters = Stream.of(seriousCounters, NoNSeriousCounters)
//                .flatMap(m -> m.entrySet().stream())
//                .collect(Collectors.groupingBy(
//                        Map.Entry::getKey,
//                        Collectors.mapping(Map.Entry::getValue, Collectors.toList())
//                ));
//        Map<Integer, List<Long>> value = CommonUtil.sortedIntergerMapByValues(lastOneYearVal, counters);

        return lastOneYearVal.stream().map(m -> {
            Map<String, Object> obj = new HashMap();
            obj.put("y", totalCounters.getOrDefault(m, 0l));
            obj.put(SERIOUS, seriousCounters.getOrDefault(m, 0l));
            obj.put(NON_SERIOUS, NoNSeriousCounters.getOrDefault(m, 0l));
            if(Objects.nonNull(susarData)) {
                obj.put(SUSAR, susarData.getOrDefault(m, 0l));
            }
            return obj;
        }).collect(Collectors.toList());
    }

    private static IntStream revRange(int from, int to) {
        return IntStream.range(from, to).map(i -> to - i + from - 1);
    }

    public List<ClosedCaseAnalysis> getCaseList(String monthRange, String caseType) {
        int range;
        switch (monthRange) {
            case "3m":
                range = 2;
                break;
            case "6m":
                range = 5;
                break;
            case "9m":
                range = 8;
                break;
            case "1y":
                range = 11;
                break;
            default:
                range = 0;
                break;
        }
        final YearMonth ym = YearMonth.now();
        final YearMonth pym = ym.minusMonths(range);

        LocalDate startDate = pym.atDay(1);
        LocalDate endDate = ym.atEndOfMonth();
        List<ClosedCaseAnalysis> closedCaseAnalysis = dtoService.loadClosedCaseAnalysis();
        return filterClosedCaseAnalysis(closedCaseAnalysis, caseType, startDate, endDate);
    }

    public List<ClosedCaseAnalysis> getMonthlyCaseList(String monthYear, String caseType) {
        LocalDate startDate = CommonUtil.convertStringToDate("01/" + monthYear, CommonUtil.dateTimeFormatter6);
        LocalDate endDate = CommonUtil.convertStringToEndDate("01/" + monthYear, CommonUtil.dateTimeFormatter6);
        List<ClosedCaseAnalysis> closedCaseAnalysis = dtoService.loadClosedCaseAnalysis();
        return filterClosedCaseAnalysis(closedCaseAnalysis, caseType, startDate, endDate);
    }

    public long calculateAverageCases(String caseType, String dateFilter) {
        int range;
        switch (dateFilter) {
            case "3m":
                range = 2;
                break;
            case "6m":
                range = 5;
                break;
            case "9m":
                range = 8;
                break;
            case "1y":
                range = 11;
                break;
            default:
                range = 0;
                break;
        }
        final YearMonth ym = YearMonth.now();
        final YearMonth pym = ym.minusMonths(range);

//        long lastOneYear = revRange(0, range + 1)
//                .boxed().map(i -> ym.minusMonths(i).lengthOfMonth()).collect(Collectors.summingLong(n -> n));

        LocalDate startDate = pym.atDay(1);
        LocalDate endDate = ym.atEndOfMonth();

//        final long itemCount = lastOneYear - daysLeft;
        List<ClosedCaseAnalysis> closedCaseAnalysis = dtoService.loadClosedCaseAnalysis();
        Supplier<Stream<ClosedCaseAnalysis>> stream = () -> closedCaseAnalysis.stream()
                .filter(c -> {
                    boolean isFilterIn;
                    if (caseType.equalsIgnoreCase("all")) {
                        isFilterIn = true;
                    } else {
                        isFilterIn = c.getCaseType().equalsIgnoreCase(caseType);
                    }
                    return isFilterIn;
                })
                .filter(c -> Objects.nonNull(c.getClosedDate())
                        && (c.getClosedDate().equals(startDate) || c.getClosedDate().isAfter(startDate))
                        && (c.getClosedDate().equals(endDate) || c.getClosedDate().isBefore(endDate)));


        return Math.round(stream.get().collect(Collectors.summingDouble(ClosedCaseAnalysis::getDaysProcess)) / stream.get().collect(Collectors.counting()));
    }

    private List<ClosedCaseAnalysis> filterClosedCaseAnalysis(List<ClosedCaseAnalysis> dataList,
                                                              String caseType, LocalDate startDate, LocalDate endDate) {
        return dataList.stream()
                .filter(c -> {
                    boolean isFilterIn;
                    if (caseType.equalsIgnoreCase("all")) {
                        isFilterIn = true;
                    } else {
                        isFilterIn = c.getCaseType().equalsIgnoreCase(caseType);
                    }
                    return isFilterIn;
                })
                .filter(c -> Objects.nonNull(c.getClosedDate()) && (c.getClosedDate().equals(startDate) || c.getClosedDate().isAfter(startDate))
                        && (c.getClosedDate().equals(endDate) || c.getClosedDate().isBefore(endDate)))
                .collect(Collectors.toList());
    }
}

