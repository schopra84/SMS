package com.pinnaxis.sms.dao.model;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "V_SMS_CASE_DETAILS")
@NamedStoredProcedureQueries({
        @NamedStoredProcedureQuery(name = "migrate_execution",
                procedureName = "pkg_sms_monitor.p_migrate_execution",
                parameters = {
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "pi_Module_type", type = Long.class),
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "pi_Method_type", type = Long.class),
                        @StoredProcedureParameter(mode = ParameterMode.OUT, name = "po_err_code", type = Long.class)
                })
})
public class CaseDetailsInfo extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Column(name = "EVENT_VERBATIM") private String eventVerbatim;
    @Column(name = "SUSAR") private String susar;
    @Column(name = "WORKFLOW_CATEGORY") private String workflowCategory;
    @Column(name = "SIG_RECEIPT_DATE") private LocalDate sigReceiptDate;

    public String getEventVerbatim() {
        return eventVerbatim;
    }

    public void setEventVerbatim(String eventVerbatim) {
        this.eventVerbatim = eventVerbatim;
    }

    public String getSusar() {
        return susar;
    }

    public void setSusar(String susar) {
        this.susar = susar;
    }

    public String getWorkflowCategory() {
        return workflowCategory;
    }

    public void setWorkflowCategory(String workflowCategory) {
        this.workflowCategory = workflowCategory;
    }

    public LocalDate getSigReceiptDate() {
        return sigReceiptDate;
    }

    public void setSigReceiptDate(LocalDate sigReceiptDate) {
        this.sigReceiptDate = sigReceiptDate;
    }
}
