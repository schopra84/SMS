package com.pinnaxis.sms.model;

import java.util.Objects;

public class CaseProgress {

    private int day1 = 0;
    private int day2 = 0;
    private int day3 = 0;
    private int day4 = 0;
    private int day5 = 0;
    private int graterThen5 = 0;

    public CaseProgress() {

    }

    public CaseProgress(int day1, int day2, int day3, int day4, int day5, int graterThen5) {
        this.day1 = day1;
        this.day2 = day2;
        this.day3 = day3;
        this.day4 = day4;
        this.day5 = day5;
        this.graterThen5 = graterThen5;
    }

    public int getDay1() {
        return day1;
    }

    public void setDay1(int day1) {
        this.day1 = day1;
    }

    public void incrementDay1() {
        this.day1++;
    }

    public int getDay2() {
        return day2;
    }

    public void setDay2(int day2) {
        this.day2 = day2;
    }

    public void incrementDay2() {
        this.day2++;
    }

    public int getDay3() {
        return day3;
    }

    public void setDay3(int day3) {
        this.day3 = day3;
    }

    public void incrementDay3() {
        this.day3++;
    }

    public int getDay4() {
        return day4;
    }

    public void incrementDay4() {
        this.day4++;
    }

    public void setDay4(int day4) {
        this.day4 = day4;
    }

    public int getDay5() {
        return day5;
    }

    public void setDay5(int day5) {
        this.day5 = day5;
    }

    public void incrementDay5() {
        this.day5++;
    }

    public int getGraterThen5() {
        return graterThen5;
    }

    public void setGraterThen5(int graterThen5) {
        this.graterThen5 = graterThen5;
    }

    public void incrementGraterThen5() {
        this.graterThen5++;
    }

    @Override
    public String toString() {
        return "CaseProgress{" +
                "day1=" + day1 +
                ", day2=" + day2 +
                ", day3=" + day3 +
                ", day4=" + day4 +
                ", day5=" + day5 +
                ", graterThen5=" + graterThen5 +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CaseProgress that = (CaseProgress) o;
        return day1 == that.day1 &&
                day2 == that.day2 &&
                day3 == that.day3 &&
                day4 == that.day4 &&
                day5 == that.day5 &&
                graterThen5 == that.graterThen5;
    }

    @Override
    public int hashCode() {

        return Objects.hash(day1, day2, day3, day4, day5, graterThen5);
    }
}
