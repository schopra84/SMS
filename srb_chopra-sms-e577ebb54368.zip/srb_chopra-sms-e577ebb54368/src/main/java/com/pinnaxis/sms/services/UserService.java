package com.pinnaxis.sms.services;

import com.pinnaxis.sms.dao.UserRepository;
import com.pinnaxis.sms.dao.model.UserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Service
public class UserService implements UserDetailsService {

    @Autowired
    private HttpServletRequest request;

    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user;
        Optional<UserInfo> opUser = userRepository.findByUsername(username);
        if(opUser.isPresent()) {
            Set<GrantedAuthority> grantedAuthorities = new HashSet<>();
            grantedAuthorities.add(new SimpleGrantedAuthority("ADMIN"));
            user = new User(opUser.get().getUsername(), opUser.get().getUserPassword(), grantedAuthorities);
            request.getSession().setAttribute("userName", opUser.get().getUserFname());
        } else {
            throw new UsernameNotFoundException("User not found by name: " + username);
        }
        return user;
    }
}
