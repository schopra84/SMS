package com.pinnaxis.sms.services;

import com.pinnaxis.sms.config.ApplicationProperties;
import com.pinnaxis.sms.model.OpenCase;
import com.pinnaxis.sms.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.pinnaxis.sms.util.SMSConstant.PROBABILITY_HIGH;
import static com.pinnaxis.sms.util.SMSConstant.PROBABILITY_LOW;

@Service
public class DueSoonService {

    @Autowired
    private DTOService dtoService;

    @Autowired
    private ApplicationProperties properties;

    public List<OpenCase> getFilteredCaseList(String todayDateVal, String filter1, String type2,
                                              String filter2, String type3, String filter3) {
        LocalDate todayDate = CommonUtil.convertStringToDate(todayDateVal, CommonUtil.dateTimeFormatter4);
        List<OpenCase> openCase = dtoService.loadOpenCases(todayDate);
        Map<String, Long> userCaseCount = openCase.stream()
                .collect(Collectors.groupingBy(OpenCase::getUserName, Collectors.counting()));


        final Set<String> set = new HashSet<>();
        Collections.addAll(set, filter1.split(","));
        List<OpenCase> openCases = openCase.stream()
                .filter(c -> set.contains(c.getDueSoon()) && Objects.isNull(c.getDeletedDate()))
                .filter(c -> {
                    boolean filter = true;
                    switch (type2) {
                        case "caseType":
                            filter = c.getReportType().equalsIgnoreCase(filter2);
                            break;
                        case "caseSeriousness":
                            filter = String.valueOf(c.getCaseSeriousness()).equalsIgnoreCase(filter2);
                            break;
                        case "stateCategorgy":
                            filter = c.getWorkflowStateCategory().equalsIgnoreCase(filter2);
                            break;
                        case "dueSoon":
                            filter = Objects.nonNull(c.getDueSoon()) ? c.getDueSoon().equalsIgnoreCase(filter2) : false;
                            break;
                        case "noProgress":
                            filter = c.getNoProgress().equalsIgnoreCase(filter2);
                            break;
                        default:
                            break;
                    }
                    return filter;
                })
                .filter(c -> {
                    boolean filter = true;
                    if (!StringUtils.isEmpty(type3)) {
                        filter = c.getWorkflowStateCategory().equalsIgnoreCase(filter3);
                    }
                    return filter;
                })
                .map(c -> {
                    String probability = PROBABILITY_LOW;
                    if (userCaseCount.containsKey(c.getUserName())) {
                        if(properties.getMaxCaseProcessing().containsKey(c.getWorkflowStateCategory())) {
                            if (userCaseCount.get(c.getUserName()) > properties.getMaxCaseProcessing().get(c.getWorkflowStateCategory())) {
                                probability = PROBABILITY_HIGH;
                            }
                        } else {
                            probability = null;
                        }
                    }
                    c.setProbability(probability);
                    return c;
                })
                .collect(Collectors.toList());
        return openCases;
    }
}
