package com.pinnaxis.sms.controller;

import com.pinnaxis.sms.config.ApplicationProperties;
import com.pinnaxis.sms.config.LoggingAccessDeniedHandler;
import com.pinnaxis.sms.services.CacheService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

@Controller
@SessionAttributes("userName")
public class HomeController {

    private static final Logger log = LoggerFactory.getLogger(HomeController.class);

    @Autowired
    private CacheService cacheService;

    @Autowired
    private ApplicationProperties properties;

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/")
    public String index(@ModelAttribute("userName") String userName, Model model) {
        model.addAttribute("name", userName);
        reloadCache();
        return "index";
    }

    @GetMapping("/access-denied")
    public String accessDenied() {
        return "/error/access-denied";
    }

    @MessageMapping("/refreshCache")
    @SendTo("/topic/refreshCacheStatus")
    public String refreshCache(@Payload String message, SimpMessageHeaderAccessor headerAccessor) {
        String userName = (String) headerAccessor.getSessionAttributes().get("userName");
        String response = properties.getRefreshErrorMessage().replace("userName", userName);
        try {
            if (message.equals("success")) {
                cacheService.clearCache();
                reloadCache();
                response = properties.getRefreshSuccessMessage().replace("userName", userName);
            }
        } catch (Exception e) {
            response = "Error occurred while refreshing cache. Please contact application admin.";
            log.error("Error occur while refreshing cache");
        }
        return response;
    }


    @RequestMapping(value = "/refreshViews", method = RequestMethod.GET)
    public ResponseEntity refreshViews(@ModelAttribute("userName") String userName) {
        String errorMessage = properties.getRefreshErrorMessage().replace("userName", userName);
        ResponseEntity responseEntity = new ResponseEntity(errorMessage, HttpStatus.EXPECTATION_FAILED);
        try {
            long response = cacheService.migrateData(111, 2);
            if(response == 1) {
                responseEntity = new ResponseEntity(HttpStatus.OK);
            }
        } catch (Exception e) {
            errorMessage = "Error occurred while refreshing cache. Please contact application admin.";
            responseEntity = new ResponseEntity(errorMessage , HttpStatus.METHOD_FAILURE);
            log.error("Error occur while database views");
        }
        return responseEntity;
    }

    private void reloadCache() {
//        CompletableFuture.runAsync(() -> cacheService.getCaseDetails());
//        CompletableFuture.runAsync(() -> cacheService.getPendingSubmissions());
//        CompletableFuture.runAsync(() -> cacheService.getQualityDetails());
//        CompletableFuture.runAsync(() -> cacheService.getReceivedCases());
//        CompletableFuture.runAsync(() -> cacheService.getWorkload());

        List<Supplier<Object>> suppliers = new ArrayList<>();
        suppliers.add(() -> cacheService.getCaseDetails());
        suppliers.add(() -> cacheService.getPendingSubmissions());
        suppliers.add(() -> cacheService.getQualityDetails());
        suppliers.add(() -> cacheService.getReceivedCases());
        suppliers.add(() -> cacheService.getWorkload());

        suppliers.parallelStream().forEach(Supplier::get);
    }
}
