package com.pinnaxis.sms.model;

import com.pinnaxis.sms.util.CommonUtil;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.Objects;

public class CaseReceivedAndClosed {
    private String caseNum, caseId, initialBookingVal, folloupBookingVal, followupSeqNum, closeDateVal;

    private LocalDate initialBooking, folloupBooking, closeDate;

    private YearMonth initialBookingYM, folloupBookingYM, closeDateYM;

    public CaseReceivedAndClosed(String caseNum, String caseId, LocalDate initialBooking, LocalDate folloupBooking, String followupSeqNum, LocalDate closeDate) {
        this.caseNum = caseNum;
        this.caseId = caseId;
        this.initialBooking = initialBooking;
        this.folloupBooking = folloupBooking;
        this.followupSeqNum = followupSeqNum;
        this.closeDate = closeDate;

        if(Objects.nonNull(initialBooking)) {
//            this.initialBookingYM = YearMonth.from(initialBooking.toInstant());
            this.initialBookingVal = CommonUtil.dateTimeFormatter3.format(initialBooking);
        }
        if(Objects.nonNull(folloupBooking)) {
//            this.closeDateYM = YearMonth.from(folloupBooking.toInstant());
            this.folloupBookingVal = CommonUtil.dateTimeFormatter3.format(folloupBooking);
        }

        if(Objects.nonNull(closeDate)) {
//            this.closeDateYM = YearMonth.from(closeDate.toInstant());
            this.closeDateVal = CommonUtil.dateTimeFormatter3.format(closeDate);
        }
    }

    public String getCaseNum() {
        return caseNum;
    }

    public void setCaseNum(String caseNum) {
        this.caseNum = caseNum;
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public String getInitialBookingVal() {
        return initialBookingVal;
    }

    public void setInitialBookingVal(String initialBookingVal) {
        this.initialBookingVal = initialBookingVal;
    }

    public String getFolloupBookingVal() {
        return folloupBookingVal;
    }

    public void setFolloupBookingVal(String folloupBookingVal) {
        this.folloupBookingVal = folloupBookingVal;
    }

    public String getFollowupSeqNum() {
        return followupSeqNum;
    }

    public void setFollowupSeqNum(String followupSeqNum) {
        this.followupSeqNum = followupSeqNum;
    }

    public String getCloseDateVal() {
        return closeDateVal;
    }

    public void setCloseDateVal(String closeDateVal) {
        this.closeDateVal = closeDateVal;
    }

    public LocalDate getInitialBooking() {
        return initialBooking;
    }

    public void setInitialBooking(LocalDate initialBooking) {
        this.initialBooking = initialBooking;
    }

    public LocalDate getFolloupBooking() {
        return folloupBooking;
    }

    public void setFolloupBooking(LocalDate folloupBooking) {
        this.folloupBooking = folloupBooking;
    }

    public LocalDate getCloseDate() {
        return closeDate;
    }

    public void setCloseDate(LocalDate closeDate) {
        this.closeDate = closeDate;
    }

    public YearMonth getInitialBookingYM() {
        return initialBookingYM;
    }

    public void setInitialBookingYM(YearMonth initialBookingYM) {
        this.initialBookingYM = initialBookingYM;
    }

    public YearMonth getFolloupBookingYM() {
        return folloupBookingYM;
    }

    public void setFolloupBookingYM(YearMonth folloupBookingYM) {
        this.folloupBookingYM = folloupBookingYM;
    }

    public YearMonth getCloseDateYM() {
        return closeDateYM;
    }

    public void setCloseDateYM(YearMonth closeDateYM) {
        this.closeDateYM = closeDateYM;
    }
}
