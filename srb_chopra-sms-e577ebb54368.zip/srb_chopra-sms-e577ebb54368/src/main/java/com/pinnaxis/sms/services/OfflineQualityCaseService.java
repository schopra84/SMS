package com.pinnaxis.sms.services;

import com.pinnaxis.sms.model.CaseDataQuality;
import com.pinnaxis.sms.model.InlineCaseDetail;
import com.pinnaxis.sms.model.InlineCaseErrorDetail;
import com.pinnaxis.sms.model.LineChart;
import com.pinnaxis.sms.util.CommonUtil;
import com.pinnaxis.sms.util.SMSConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@Service
public class OfflineQualityCaseService implements SMSConstant {

    private static final long OFFLINE_TYPE = 2;

    @Autowired
    private DTOService dtoService;

//    private List<CaseDataQuality> caseDataQuality;

//    private List<CaseDataQualityError> caseDataQualityError;

//    private Map<Integer, CaseDataQualityError> caseDataQualityErrorMap;
    private List<String> errorWorkflowList;
//    private List<Integer> errorIds;
//    private List<Integer> criticalError;
//    private List<Integer> highError;
//    private List<Integer> mediumError;
//    private List<Integer> lowError;

    @PostConstruct
    public void init() {
//        caseDataQualityError = null;
        errorWorkflowList = Arrays.asList(DATA_ENTRY, QUALITY_REVIEW, MEDICAL_REVIEW, DISTRIBUTION);
//        caseDataQualityErrorMap = caseDataQualityError.stream()
//                        .collect(Collectors.toMap(CaseDataQualityError::getErrorId, Function.identity()));
//        caseDataQuality.stream().forEach(c -> c.setCaseDataQualityError(caseDataQualityErrorMap.get(c.getErrorId())));
//        errorIds = caseDataQualityError.parallelStream()
//                .map(e -> e.getErrorId()).collect(Collectors.toList());
//        criticalError = caseDataQualityError.parallelStream().filter(e -> e.getErrorSeverity().equalsIgnoreCase("Critical"))
//                .map(e -> e.getErrorId()).collect(Collectors.toList());
//        highError = caseDataQualityError.parallelStream().filter(e -> e.getErrorSeverity().equalsIgnoreCase("High"))
//                .map(e -> e.getErrorId()).collect(Collectors.toList());
//        mediumError = caseDataQualityError.parallelStream().filter(e -> e.getErrorSeverity().equalsIgnoreCase("Medium"))
//                .map(e -> e.getErrorId()).collect(Collectors.toList());
//        lowError = caseDataQualityError.parallelStream().filter(e -> e.getErrorSeverity().equalsIgnoreCase("Low"))
//                .map(e -> e.getErrorId()).collect(Collectors.toList());
    }

    public LineChart getMonthlyOfflineCaseCount(String dateFilter) {
        LineChart chart = new LineChart("Error Count", "", "Count");

        int range;
        switch (dateFilter) {
            case "3m":
                range = 3;
                break;
            case "6m":
                range = 6;
                break;
            case "9m":
                range = 9;
                break;
            case "1y":
                range = 12;
                break;
            default:
                range = 0;
                break;
        }
        final YearMonth ym = YearMonth.now();
        List<YearMonth> lastOneYear = revRange(0, range)
                .boxed().map(i -> ym.minusMonths(i)).collect(Collectors.toList());
        final YearMonth pym = lastOneYear.get(0);

        LocalDate startDate = pym.atDay(1);
        LocalDate endDate = ym.atEndOfMonth();

        Calendar cal = Calendar.getInstance();
        List<CaseDataQuality> caseDataQuality = dtoService.loadCaseDataQuality();
        List<Integer> lastOneYearVal = lastOneYear.stream()
                .map(l -> l.getMonthValue()).collect(Collectors.toList());
        Map<String, List<Map<String, Object>>> responsibleWorkflow = new HashMap<>();

//        List<CaseDataQuality> closedCasesFilteredData = caseDataQuality.stream()
//                .filter(c -> c.getClosed() == OFFLINE_TYPE && Objects.nonNull(c.getAwareDate()))
//                .filter(c -> (c.getAwareDate().equals(startDate) || c.getAwareDate().isAfter(startDate))
//                        && (c.getAwareDate().equals(endDate) || c.getAwareDate().isBefore(endDate)))
//                .map(c -> {
//                    c.setCaseDataQualityError(caseDataQualityErrorMap.get(c.getErrorId()));
//                    return c;
//                }).collect(Collectors.toList());




        Supplier<Stream<CaseDataQuality>> closedCasesFilteredSupplier = () ->  caseDataQuality.stream()
                .filter(c -> c.getClosed() == OFFLINE_TYPE && Objects.nonNull(c.getAwareDate()))
                .filter(c -> (c.getAwareDate().equals(startDate) || c.getAwareDate().isAfter(startDate))
                        && (c.getAwareDate().equals(endDate) || c.getAwareDate().isBefore(endDate)));


        errorWorkflowList.stream().forEach(w -> {
            Supplier<Stream<CaseDataQuality>> casesData = () ->
                    closedCasesFilteredSupplier.get().filter(c -> c.getErrorWorkflow().equalsIgnoreCase(w));

            Map<Integer, Long> totalCount = casesData.get()
                    .collect(Collectors.groupingBy(c -> c.getAwareDate().getMonthValue(),
                            Collectors.counting()
                    ));

            Map<Integer, Long> criticalError = casesData.get()
                    .filter(c -> c.getErrorSeverity().equalsIgnoreCase(CRITICAL))
                    .collect(Collectors.groupingBy(c -> c.getAwareDate().getMonthValue(),
                            Collectors.counting()
                    ));
            Map<Integer, Long> highError = casesData.get()
                    .filter(c -> c.getErrorSeverity().equalsIgnoreCase(HIGH))
                    .collect(Collectors.groupingBy(c -> c.getAwareDate().getMonthValue(),
                            Collectors.counting()
                    ));
            Map<Integer, Long> mediumError = casesData.get()
                    .filter(c -> c.getErrorSeverity().equalsIgnoreCase(MEDIUM))
                    .collect(Collectors.groupingBy(c -> c.getAwareDate().getMonthValue(),
                            Collectors.counting()
                    ));
            Map<Integer, Long> lowError = casesData.get()
                    .filter(c -> c.getErrorSeverity().equalsIgnoreCase(LOW))
                    .collect(Collectors.groupingBy(c -> c.getAwareDate().getMonthValue(),
                            Collectors.counting()
                    ));

            List<Map<String, Object>> data = filteredData(totalCount, criticalError, highError, mediumError, lowError, lastOneYearVal);
            responsibleWorkflow.put(w, data);
        });


//        errorWorkflowList.stream().forEach(w -> {
//
//            Supplier<Stream<CaseDataQuality>> casesData = () -> closedCasesFilteredData.stream()
//                    .filter(c -> c.getCaseDataQualityError().getErrorWorkflow().equalsIgnoreCase(w));
//
//            Map<Integer, Long> totalCount = casesData.get()
//                    .collect(Collectors.groupingBy(c -> {
//                                cal.setTime(c.getAwareDate());
//                                return cal.get(Calendar.MONTH) + 1;
//                            },
//                            Collectors.counting()
//                    ));
//
//            Map<Integer, Long> criticalError = casesData.get()
//                    .filter(c -> c.getCaseDataQualityError().getErrorSeverity().equalsIgnoreCase(CRITICAL))
//                    .collect(Collectors.groupingBy(c -> {
//                                cal.setTime(c.getAwareDate());
//                                return cal.get(Calendar.MONTH) + 1;
//                            },
//                            Collectors.counting()
//                    ));
//            Map<Integer, Long> highError = casesData.get()
//                    .filter(c -> c.getCaseDataQualityError().getErrorSeverity().equalsIgnoreCase(HIGH))
//                    .collect(Collectors.groupingBy(c -> {
//                                cal.setTime(c.getAwareDate());
//                                return cal.get(Calendar.MONTH) + 1;
//                            },
//                            Collectors.counting()
//                    ));
//            Map<Integer, Long> mediumError = casesData.get()
//                    .filter(c -> c.getCaseDataQualityError().getErrorSeverity().equalsIgnoreCase(MEDIUM))
//                    .collect(Collectors.groupingBy(c -> {
//                                cal.setTime(c.getAwareDate());
//                                return cal.get(Calendar.MONTH) + 1;
//                            },
//                            Collectors.counting()
//                    ));
//            Map<Integer, Long> lowError = casesData.get()
//                    .filter(c -> c.getCaseDataQualityError().getErrorSeverity().equalsIgnoreCase(LOW))
//                    .collect(Collectors.groupingBy(c -> {
//                                cal.setTime(c.getAwareDate());
//                                return cal.get(Calendar.MONTH) + 1;
//                            },
//                            Collectors.counting()
//                    ));
//
//            List<Map<String, Object>> data = filteredData(totalCount, criticalError, highError, mediumError, lowError, lastOneYearVal);
//            responsibleWorkflow.put(w, data);
//        });


        List<String> xCategories = lastOneYear.stream()
                .map(d -> d.getMonth().getDisplayName(TextStyle.SHORT, Locale.ENGLISH) + "/" + d.getYear())
                .collect(Collectors.toList());


        List<Map<String, Object>> series = new ArrayList();

        Map<String, Object> dataEntryMap = new LinkedHashMap<>();
        dataEntryMap.put("name", DATA_ENTRY);
        dataEntryMap.put("data", responsibleWorkflow.get(DATA_ENTRY));
        dataEntryMap.put("color", "#7CB5EC");

        Map<String, Object> qualityReviewMap = new LinkedHashMap<>();
        qualityReviewMap.put("name", QUALITY_REVIEW);
        qualityReviewMap.put("data", responsibleWorkflow.get(QUALITY_REVIEW));
        qualityReviewMap.put("color", "#b5ec7c");

        Map<String, Object> medicalReviewMap = new LinkedHashMap<>();
        medicalReviewMap.put("name", MEDICAL_REVIEW);
        medicalReviewMap.put("data", responsibleWorkflow.get(MEDICAL_REVIEW));
        medicalReviewMap.put("color", "#000000");

        Map<String, Object> distributionMap = new LinkedHashMap<>();
        distributionMap.put("name", DISTRIBUTION);
        distributionMap.put("data", responsibleWorkflow.get(DISTRIBUTION));
        distributionMap.put("color", "#f7a35c");

        series.add(dataEntryMap);
        series.add(qualityReviewMap);
        series.add(medicalReviewMap);
        series.add(distributionMap);

        chart.setxCategories(xCategories);
        chart.setSeries(series);
        return chart;
    }

    private List<Map<String, Object>> filteredData(Map<Integer, Long> totalCounters,
                                                   Map<Integer, Long> criticalError, Map<Integer, Long> highError,
                                                   Map<Integer, Long> mediumError, Map<Integer, Long> lowError,
                                                   List<Integer> lastOneYearVal) {
        return lastOneYearVal.stream().map(m -> {
            Map<String, Object> obj = new HashMap();
            obj.put("y", totalCounters.getOrDefault(m, 0l));
            obj.put(CRITICAL, criticalError.getOrDefault(m, 0l));
            obj.put(HIGH, highError.getOrDefault(m, 0l));
            obj.put(MEDIUM, mediumError.getOrDefault(m, 0l));
            obj.put(LOW, lowError.getOrDefault(m, 0l));
            return obj;
        }).collect(Collectors.toList());
    }

    private static IntStream revRange(int from, int to) {
        return IntStream.range(from, to).map(i -> to - i + from - 1);
    }

    public List<InlineCaseDetail> getOfflineCaseDetails(String monthRange) {
        int range;
        switch (monthRange) {
            case "3m":
                range = 2;
                break;
            case "6m":
                range = 5;
                break;
            case "9m":
                range = 8;
                break;
            case "1y":
                range = 11;
                break;
            default:
                range = 0;
                break;
        }
        final YearMonth ym = YearMonth.now();
        final YearMonth pym = ym.minusMonths(range);

        LocalDate startDate = pym.atDay(1);
        LocalDate endDate = ym.atEndOfMonth();
        return getOfflineCaseDetails(startDate, endDate, null);
    }

    public List<InlineCaseDetail> getMonthlyOfflineCaseDetails(String monthYear, String category) {
        LocalDate startDate = CommonUtil.convertStringToDate("01/" + monthYear, CommonUtil.dateTimeFormatter6);
        LocalDate endDate = CommonUtil.convertStringToEndDate("01/" + monthYear, CommonUtil.dateTimeFormatter6);
        return getOfflineCaseDetails(startDate, endDate, category);
    }

    public List<InlineCaseDetail> getOfflineCaseDetails(LocalDate startDate, LocalDate endDate, String category) {
        List<InlineCaseDetail> inlineCaseDetails = new ArrayList<>();
        List<CaseDataQuality> caseDataList = dtoService.loadCaseDataQuality();

        Map<String, List<CaseDataQuality>> caseDataQualityMap = caseDataList.parallelStream()
                .filter(c ->  {
                    boolean filter = true;
                    if (Objects.nonNull(category)) {
                        if (category.equalsIgnoreCase("all")) {
                            filter = true;
                        } else {
                            filter = c.getErrorWorkflow().equalsIgnoreCase(category);
                        }
                    }
                    return filter;
                }).filter(c -> c.getClosed() == OFFLINE_TYPE &&
                        (c.getAwareDate().equals(startDate) || c.getAwareDate().isAfter(startDate)) &&
                        (c.getAwareDate().equals(endDate) || c.getAwareDate().isBefore(endDate)))
                .collect(Collectors.groupingBy(CaseDataQuality::getCaseNumber));


        caseDataQualityMap.entrySet().stream().forEach(e -> {
            String caseNumber = e.getKey();
            List<CaseDataQuality> casesData = e.getValue();
            CaseDataQuality caseData = casesData.get(0);
            long criticalErrors = casesData.stream()
                    .filter(c -> c.getErrorSeverity().equalsIgnoreCase(CRITICAL)).collect(Collectors.counting());
            long highErrors = casesData.stream()
                    .filter(c -> c.getErrorSeverity().equalsIgnoreCase(HIGH)).collect(Collectors.counting());
            long mediumErrors = casesData.stream()
                    .filter(c -> c.getErrorSeverity().equalsIgnoreCase(MEDIUM)).collect(Collectors.counting());
            long lowErrors = casesData.stream()
                    .filter(c -> c.getErrorSeverity().equalsIgnoreCase(LOW)).collect(Collectors.counting());
            inlineCaseDetails.add(new InlineCaseDetail(null, caseNumber, caseData.getAwareDateVal(),
                    caseData.getReportType(), caseData.getCountryOfIncidence(), caseData.getStudyId(), caseData.getPrimaryProductName(),
                    criticalErrors, highErrors, mediumErrors, lowErrors));
        });

        return inlineCaseDetails;
    }

    public List<InlineCaseErrorDetail> getOfflineCaseErrorDetails(String caseNumber, String monthRange) {
        int range;
        switch (monthRange) {
            case "3m":
                range = 2;
                break;
            case "6m":
                range = 5;
                break;
            case "9m":
                range = 8;
                break;
            case "1y":
                range = 11;
                break;
            default:
                range = 0;
                break;
        }
        final YearMonth ym = YearMonth.now();
        final YearMonth pym = ym.minusMonths(range);

        LocalDate startDate = pym.atDay(1);
        LocalDate endDate = ym.atEndOfMonth();
        return getOfflineCaseErrorDetails(caseNumber, startDate, endDate, null);
    }

    public List<InlineCaseErrorDetail> getMonthlyOfflineCaseErrorDetails(String caseNumber, String monthYear, String category) {
        LocalDate startDate = CommonUtil.convertStringToDate("01/" + monthYear, CommonUtil.dateTimeFormatter6);
        LocalDate endDate = CommonUtil.convertStringToEndDate("01/" + monthYear, CommonUtil.dateTimeFormatter6);
        return getOfflineCaseErrorDetails(caseNumber, startDate, endDate, category);
    }

    public List<InlineCaseErrorDetail> getOfflineCaseErrorDetails(final String caseNumber, LocalDate startDate , LocalDate endDate, String category) {
        List<CaseDataQuality> caseDataList = dtoService.loadCaseDataQuality();

        List<InlineCaseErrorDetail> inlineCaseErrorDetails = caseDataList.parallelStream()
                .filter(c ->  {
                    boolean filter = true;
                    if(Objects.nonNull(category)) {
                        filter = c.getErrorWorkflow().equalsIgnoreCase(category);
                    }
                    return filter;
                }).filter(c -> c.getCaseNumber().equalsIgnoreCase(caseNumber) &&
                        (c.getAwareDate().equals(startDate) || c.getAwareDate().isAfter(startDate)) &&
                        (c.getAwareDate().equals(endDate) || c.getAwareDate().isBefore(endDate)))
                .map(c ->
                        new InlineCaseErrorDetail(caseNumber, c.getErrorSeverity(), c.getErrorMessage()))
                .collect(Collectors.toList());

        return inlineCaseErrorDetails;
    }
}
