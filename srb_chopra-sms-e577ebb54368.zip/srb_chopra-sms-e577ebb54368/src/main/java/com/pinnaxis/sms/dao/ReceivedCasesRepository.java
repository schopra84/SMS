package com.pinnaxis.sms.dao;

import com.pinnaxis.sms.dao.model.ReceivedCasesInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ReceivedCasesRepository extends JpaRepository<ReceivedCasesInfo, Long> {

}
