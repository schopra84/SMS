package com.pinnaxis.sms.controller;

import com.pinnaxis.sms.model.OpenCase;
import com.pinnaxis.sms.model.PendingSubmission;
import com.pinnaxis.sms.model.PendingSubmissionCase;
import com.pinnaxis.sms.services.ProcessSubmissionDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.*;
import java.util.stream.Collectors;

@Controller
public class PendingSubmissionController {

    @Autowired
    private ProcessSubmissionDataService service;

    @RequestMapping("/pending-submission")
    public String pendingSubmission(){
        return "track-cases-with-pending-submission";
    }

    @RequestMapping("/scheduled")
    public String getScheduled(Model model){
        PendingSubmission pendingSubmission = new PendingSubmission("Scheduled but", "NOT GENERATED", service.generationStatus(), "generationStatus");
        model.addAttribute(pendingSubmission);
        return "pendingSubmission";
    }

    @RequestMapping("/generated")
    public String getGenerated(Model model){
        PendingSubmission pendingSubmission = new PendingSubmission("Generated but","NOT TRANSMITTED", service.submissionStatus(), "submissionStatus");
        model.addAttribute(pendingSubmission);
        return "pendingSubmission";
    }

    @RequestMapping("/transmitted")
    public String getTransmitted(Model model){
        PendingSubmission pendingSubmission = new PendingSubmission("Transmitted but", "ACK PENDING", service.transmittedStatus(), "transmittedStatus");
        model.addAttribute(pendingSubmission);
        return "pendingSubmission";
    }

    @RequestMapping(value = "/getSubmissionCaseDetails", method = RequestMethod.GET)
    public ResponseEntity<?> getSubmissionCaseDetails(@RequestParam(value = "todayDate") String todayDateVal,
                                                      @RequestParam(value = "filter") String filter) {
        List<PendingSubmissionCase> pendingSubmissionCase = service.getSubmissionCaseDetails(filter, todayDateVal);
        return ResponseEntity.ok(pendingSubmissionCase);
    }
}
