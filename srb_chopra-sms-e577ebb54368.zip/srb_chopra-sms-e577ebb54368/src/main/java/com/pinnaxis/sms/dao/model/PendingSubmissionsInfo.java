package com.pinnaxis.sms.dao.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name = "V_SMS_PENDING_SUBMISSIONS")
public class PendingSubmissionsInfo extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Column(name = "REG_REPORT_ID") private Long regReportId;
    @Column(name = "LIC_NUMBER") private String licNumber;
    @Column(name = "AGENCY_NAME") private String agencyName;
    @Column(name = "REPORT_FORM") private String reportForm;
    @Column(name = "DUE_DATE") private LocalDate dueDate;
    @Column(name = "DATE_GENERATED") private LocalDate dateGenerated;
    @Column(name = "DATE_XMIT") private LocalDate dateXmit;
    @Column(name = "GENERATION_ERROR") private String generationError;
    @Column(name = "STATUS_TEXT") private String statusText;
    @Column(name = "SUSAR") private Long susar;
    @Column(name = "DATE_SCHEDULED") private LocalDate dateScheduled;
    @Column(name = "FLAG_FOR_SUBMISSION_SCREEN") private long flagForSubmissionScreen;
    @Column(name = "EVENT_VERBATIM") private String eventVerbatim;
    @Column(name = "DATE_SUBMITTED") private LocalDate dateSubmitted;

    public Long getRegReportId() {
        return regReportId;
    }

    public void setRegReportId(Long regReportId) {
        this.regReportId = regReportId;
    }

    public String getLicNumber() {
        return licNumber;
    }

    public void setLicNumber(String licNumber) {
        this.licNumber = licNumber;
    }

    public String getAgencyName() {
        return agencyName;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }

    public String getReportForm() {
        return reportForm;
    }

    public void setReportForm(String reportForm) {
        this.reportForm = reportForm;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDate getDateGenerated() {
        return dateGenerated;
    }

    public void setDateGenerated(LocalDate dateGenerated) {
        this.dateGenerated = dateGenerated;
    }

    public String getGenerationError() {
        return generationError;
    }

    public void setGenerationError(String generationError) {
        this.generationError = generationError;
    }

    public String getStatusText() {
        return statusText;
    }

    public void setStatusText(String statusText) {
        this.statusText = statusText;
    }

    public Long getSusar() {
        return susar;
    }

    public void setSusar(Long susar) {
        this.susar = susar;
    }

    public LocalDate getDateScheduled() {
        return dateScheduled;
    }

    public void setDateScheduled(LocalDate dateScheduled) {
        this.dateScheduled = dateScheduled;
    }

    public long getFlagForSubmissionScreen() {
        return flagForSubmissionScreen;
    }

    public void setFlagForSubmissionScreen(long flagForSubmissionScreen) {
        this.flagForSubmissionScreen = flagForSubmissionScreen;
    }

    public String getEventVerbatim() {
        return eventVerbatim;
    }

    public void setEventVerbatim(String eventVerbatim) {
        this.eventVerbatim = eventVerbatim;
    }

    public LocalDate getDateXmit() {
        return dateXmit;
    }

    public void setDateXmit(LocalDate dateXmit) {
        this.dateXmit = dateXmit;
    }

    public LocalDate getDateSubmitted() {
        return dateSubmitted;
    }

    public void setDateSubmitted(LocalDate dateSubmitted) {
        this.dateSubmitted = dateSubmitted;
    }
}
