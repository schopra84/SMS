package com.pinnaxis.sms.config;

import net.sf.ehcache.CacheException;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.config.Configuration;
import net.sf.ehcache.config.ConfigurationFactory;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;

import java.io.ByteArrayInputStream;
import java.nio.charset.Charset;
import java.util.Objects;

public class EhCacheManagerWrapper implements FactoryBean<CacheManager>, InitializingBean, DisposableBean {

    private String cacheManagerName;
    private boolean acceptExisting = false;
    private boolean shared = false;
    private CacheManager cacheManager;
    private boolean locallyManaged = true;
    private String configString;

    public void setCacheManagerName(String cacheManagerName) {
        this.cacheManagerName = cacheManagerName;
    }

    public void setConfigString(String configString) {
        this.configString = configString;
    }

    public void setAcceptExisting(boolean acceptExisting) {
        this.acceptExisting = acceptExisting;
    }

    public void setShared(boolean shared) {
        this.shared = shared;
    }

    @Override
    public void destroy() {
        if(this.locallyManaged) {
            this.cacheManager.shutdown();
        }
    }

    @Override
    public CacheManager getObject() {
        return this.cacheManager;
    }

    @Override
    public Class<?> getObjectType() {
        return (this.cacheManager != null ? this.cacheManager.getClass() : CacheManager.class);
    }

    @Override
    public boolean isSingleton() {
        return true;
    }

    @Override
    public void afterPropertiesSet() throws CacheException {
        Configuration configuration = (StringUtils.isNotEmpty(this.configString)
                ? ConfigurationFactory.parseConfiguration(new ByteArrayInputStream(this.configString.getBytes(Charset.defaultCharset())))
                : ConfigurationFactory.parseConfiguration());
        if(this.cacheManagerName != null) {
            configuration.setName(this.cacheManagerName);
        }
        if(this.shared) {
            this.cacheManager = CacheManager.create(configuration);
        } else if(this.acceptExisting) {
            synchronized (CacheManager.class) {
                this.cacheManager = CacheManager.getCacheManager(this.cacheManagerName);
                if(Objects.isNull(this.cacheManager)) {
                    this.cacheManager =  new CacheManager(configuration);
                } else {
                    this.locallyManaged = false;
                }
            }
        } else {
            this.cacheManager = new CacheManager(configuration);
        }
    }
}
