package com.pinnaxis.sms.dao.model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "T_SMS_USER_DETAILS_C")
public class UserInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "USER_ID") private Long userId;
    @Column(name = "USER_FNAME") private String userFname;
    @Column(name = "USER_NAME") private String username;
    @Column(name = "USER_PASSWORD") private String userPassword;
    @Column(name = "USER_EMAIL_ID") private String userEmailId;
    @Column(name = "MODULE_ENABLE") private Long moduleEnable;
    @Column(name = "ACCOUNT_DISABLED") private Long accountDisabled;
    @Column(name = "FORCE_EXPIRE") private Long forceExpire;
    @Column(name = "NUM_DAYS") private Long numDays;
    @Column(name = "SITE_SECURITY") private Long siteSecurity;
    @Column(name = "SITE_ID") private Long siteId;
    @Column(name = "PRODUCT_SECURITY") private Long productSecurity;
    @Column(name = "STUDY_SECURITY") private Long studySecurity;
    @Column(name = "PWD_SET_DATE") private Date pwdSetDate;
    @Column(name = "CREATION_DATE") private Date creationDate;
    @Column(name = "FORCE_CHANGE") private Long forceChange;
    @Column(name = "DELETED") private Date deleted;
    @Column(name = "LOGIN_COUNT") private Long loginCount;
    @Column(name = "SECURITY_DISABLED") private Long securityDisabled;
    @Column(name = "SECURITY_DISABLED_TEXT") private String securityDisabledText;
    @Column(name = "ENTERPRISE_ID") private Long enterpriseId;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserFname() {
        return userFname;
    }

    public void setUserFname(String userFname) {
        this.userFname = userFname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getUserEmailId() {
        return userEmailId;
    }

    public void setUserEmailId(String userEmailId) {
        this.userEmailId = userEmailId;
    }

    public Long getModuleEnable() {
        return moduleEnable;
    }

    public void setModuleEnable(Long moduleEnable) {
        this.moduleEnable = moduleEnable;
    }

    public Long getAccountDisabled() {
        return accountDisabled;
    }

    public void setAccountDisabled(Long accountDisabled) {
        this.accountDisabled = accountDisabled;
    }

    public Long getForceExpire() {
        return forceExpire;
    }

    public void setForceExpire(Long forceExpire) {
        this.forceExpire = forceExpire;
    }

    public Long getNumDays() {
        return numDays;
    }

    public void setNumDays(Long numDays) {
        this.numDays = numDays;
    }

    public Long getSiteSecurity() {
        return siteSecurity;
    }

    public void setSiteSecurity(Long siteSecurity) {
        this.siteSecurity = siteSecurity;
    }

    public Long getSiteId() {
        return siteId;
    }

    public void setSiteId(Long siteId) {
        this.siteId = siteId;
    }

    public Long getProductSecurity() {
        return productSecurity;
    }

    public void setProductSecurity(Long productSecurity) {
        this.productSecurity = productSecurity;
    }

    public Long getStudySecurity() {
        return studySecurity;
    }

    public void setStudySecurity(Long studySecurity) {
        this.studySecurity = studySecurity;
    }

    public Date getPwdSetDate() {
        return pwdSetDate;
    }

    public void setPwdSetDate(Date pwdSetDate) {
        this.pwdSetDate = pwdSetDate;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Long getForceChange() {
        return forceChange;
    }

    public void setForceChange(Long forceChange) {
        this.forceChange = forceChange;
    }

    public Date getDeleted() {
        return deleted;
    }

    public void setDeleted(Date deleted) {
        this.deleted = deleted;
    }

    public Long getLoginCount() {
        return loginCount;
    }

    public void setLoginCount(Long loginCount) {
        this.loginCount = loginCount;
    }

    public Long getSecurityDisabled() {
        return securityDisabled;
    }

    public void setSecurityDisabled(Long securityDisabled) {
        this.securityDisabled = securityDisabled;
    }

    public String getSecurityDisabledText() {
        return securityDisabledText;
    }

    public void setSecurityDisabledText(String securityDisabledText) {
        this.securityDisabledText = securityDisabledText;
    }

    public Long getEnterpriseId() {
        return enterpriseId;
    }

    public void setEnterpriseId(Long enterpriseId) {
        this.enterpriseId = enterpriseId;
    }
}
