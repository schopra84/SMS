package com.pinnaxis.sms.model;

import com.pinnaxis.sms.util.CommonUtil;

import java.time.LocalDate;
import java.util.Objects;

public class CaseDataQuality {
    private String caseId, caseNumber, awareDateVal, workflowState, reportType,
            countryOfIncidence, studyId, primaryProductName, responsibleUser,
            errorSeverity,  errorWorkflow, errorMessage;

    private LocalDate awareDate;

    private long errorId, closed;

    public CaseDataQuality(String caseId, String caseNumber, LocalDate awareDate, String reportType,
                           String countryOfIncidence, String studyId, String primaryProductName,
                           long errorId, String workflowState, long closed, String responsibleUser,
                           String errorSeverity, String errorWorkflow, String errorMessage) {
        this.caseId = caseId;
        this.caseNumber = caseNumber;
        this.awareDate = awareDate;
        this.reportType = reportType;
        this.countryOfIncidence = countryOfIncidence;
        this.studyId = studyId;
        this.primaryProductName = primaryProductName;
        this.errorId = errorId;
        this.workflowState = workflowState;
        this.closed = closed;
        this.responsibleUser = responsibleUser;
        this.errorSeverity = errorSeverity;
        this.errorWorkflow = errorWorkflow;
        this.errorMessage = errorMessage;

        if(Objects.nonNull(awareDate)) {
            this.awareDateVal = CommonUtil.dateTimeFormatter1.format(awareDate);
        }
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public String getAwareDateVal() {
        return awareDateVal;
    }

    public void setAwareDateVal(String awareDateVal) {
        this.awareDateVal = awareDateVal;
    }

    public long getErrorId() {
        return errorId;
    }

    public void setErrorId(long errorId) {
        this.errorId = errorId;
    }

    public void setClosed(long closed) {
        this.closed = closed;
    }

    public String getWorkflowState() {
        return workflowState;
    }

    public void setWorkflowState(String workflowState) {
        this.workflowState = workflowState;
    }

    public LocalDate getAwareDate() {
        return awareDate;
    }

    public void setAwareDate(LocalDate awareDate) {
        this.awareDate = awareDate;
    }

    public String getReportType() {
        return reportType;
    }

    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    public String getCountryOfIncidence() {
        return countryOfIncidence;
    }

    public void setCountryOfIncidence(String countryOfIncidence) {
        this.countryOfIncidence = countryOfIncidence;
    }

    public String getStudyId() {
        return studyId;
    }

    public void setStudyId(String studyId) {
        this.studyId = studyId;
    }

    public String getPrimaryProductName() {
        return primaryProductName;
    }

    public void setPrimaryProductName(String primaryProductName) {
        this.primaryProductName = primaryProductName;
    }

    public String getResponsibleUser() {
        return responsibleUser;
    }

    public void setResponsibleUser(String responsibleUser) {
        this.responsibleUser = responsibleUser;
    }

    public String getErrorSeverity() {
        return errorSeverity;
    }

    public void setErrorSeverity(String errorSeverity) {
        this.errorSeverity = errorSeverity;
    }

    public String getErrorWorkflow() {
        return errorWorkflow;
    }

    public void setErrorWorkflow(String errorWorkflow) {
        this.errorWorkflow = errorWorkflow;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public long getClosed() {
        return closed;
    }
}
