package com.pinnaxis.sms.services;

import com.pinnaxis.sms.model.ClosedCaseAnalysis;
import com.pinnaxis.sms.model.LineChart;
import com.pinnaxis.sms.util.CommonUtil;
import com.pinnaxis.sms.util.SMSConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Component
public class CaseAnalysisService implements SMSConstant {

    @Autowired
    private DTOService dtoService;

    public LineChart getMonthlyClosedCaseCount(final String filter, String dateFilter) {
        LineChart chart = new LineChart("Case Count", "", "Count");

        int range;
        switch (dateFilter) {
            case "3m":
                range = 3;
                break;
            case "6m":
                range = 6;
                break;
            case "9m":
                range = 9;
                break;
            case "1y":
                range = 12;
                break;
            default:
                range = 0;
                break;
        }
        final YearMonth ym = YearMonth.now();
        List<YearMonth> lastOneYear = revRange(0, range)
                .boxed().map(i -> ym.minusMonths(i)).collect(Collectors.toList());
        final YearMonth pym = lastOneYear.get(0);

        LocalDate startDate = pym.atDay(1);
        LocalDate endDate = ym.atEndOfMonth();

        List<ClosedCaseAnalysis> closedCaseAnalysis = dtoService.loadClosedCaseAnalysis();
        List<ClosedCaseAnalysis> closedCasesAfterFilter = closedCaseAnalysis.stream()
                .filter(c -> {
                    boolean isFilterIn;
                    if (filter.equalsIgnoreCase("all")) {
                        isFilterIn = true;
                    } else {
                        isFilterIn = c.getCaseType().equalsIgnoreCase(filter);
                    }
                    return isFilterIn;
                })
                .collect(Collectors.toList());

        Calendar cal = Calendar.getInstance();

//----------------------------------------------------START CLOSED CASE----------------------------------------------------------------------------
        List<ClosedCaseAnalysis> closedCasesFilteredData = closedCasesAfterFilter.stream()
                .filter(c -> Objects.nonNull(c.getClosedDate())
                        && (c.getClosedDate().equals(startDate) || c.getClosedDate().isAfter(startDate))
                        && (c.getClosedDate().equals(endDate) || c.getClosedDate().isBefore(endDate)))
                .collect(Collectors.toList());

        Map<Integer, Long> totalClosedCasesData = closedCasesFilteredData.stream()
                .collect(Collectors.groupingBy(c -> c.getClosedDate().getMonthValue(),
                        Collectors.counting()
                ));

        Map<Integer, Long> closedCasesSeriousData = closedCasesFilteredData.stream()
                .filter(c -> c.getCaseSeriousness().equalsIgnoreCase(SERIOUS))
                .collect(Collectors.groupingBy(c -> c.getClosedDate().getMonthValue(),
                        Collectors.counting()
                ));

        Map<Integer, Long> closedCasesNoNSeriousData = closedCasesFilteredData.stream()
                .filter(c -> c.getCaseSeriousness().equalsIgnoreCase("Non Serious"))
                .collect(Collectors.groupingBy(c -> c.getClosedDate().getMonthValue(),
                        Collectors.counting()
                ));
//----------------------------------------------------END CLOSED CASE----------------------------------------------------------------------------

        List<ClosedCaseAnalysis> openCasesFilteredData = closedCasesAfterFilter.stream()
                .filter(c -> Objects.nonNull(c.getFollowUpReceiptDate()))
                .filter(c -> (c.getFollowUpReceiptDate().equals(startDate) || c.getFollowUpReceiptDate().isAfter(startDate))
                        && (c.getFollowUpReceiptDate().equals(endDate) || c.getFollowUpReceiptDate().isBefore(endDate)))
                .collect(Collectors.toList());

        Map<Integer, Long> totalOpenCasesData = openCasesFilteredData.stream()
                .collect(Collectors.groupingBy(c -> c.getFollowUpReceiptDate().getMonthValue(),
                        Collectors.counting()
                ));

        Map<Integer, Long> openSeriousCasesData = openCasesFilteredData.stream()
                .filter(c -> c.getCaseSeriousness().equalsIgnoreCase(SERIOUS))
                .collect(Collectors.groupingBy(c -> c.getFollowUpReceiptDate().getMonthValue(),
                        Collectors.counting()
                ));

        Map<Integer, Long> openNoNSeriousCasesData = openCasesFilteredData.stream()
                .filter(c -> c.getCaseSeriousness().equalsIgnoreCase("Non Serious"))
                .collect(Collectors.groupingBy(c -> c.getFollowUpReceiptDate().getMonthValue(),
                        Collectors.counting()
                ));

        openCasesFilteredData = closedCasesAfterFilter.stream()
                .filter(c -> Objects.isNull(c.getFollowUpReceiptDate())
                        && Objects.nonNull(c.getInitialReceiptDate()))
                .filter(c -> (c.getInitialReceiptDate().equals(startDate) || c.getInitialReceiptDate().isAfter(startDate))
                        && (c.getInitialReceiptDate().equals(endDate) || c.getInitialReceiptDate().isBefore(endDate)))
                .collect(Collectors.toList());

        openCasesFilteredData.stream()
                .collect(Collectors.groupingBy(c -> c.getInitialReceiptDate().getMonthValue(),
                        Collectors.counting()
                )).forEach((k, v) -> totalOpenCasesData.merge(k, v, (v1, v2) -> v1 + v2));

        openCasesFilteredData.stream()
                .filter(c -> c.getCaseSeriousness().equalsIgnoreCase("Serious"))
                .collect(Collectors.groupingBy(c -> c.getInitialReceiptDate().getMonthValue(),
                        Collectors.counting()
                )).forEach((k, v) -> openSeriousCasesData.merge(k, v, (v1, v2) -> v1 + v2));

//        m2.forEach((k, v) -> m.merge(k, v, (v1, v2) -> v1 + v2));


        openCasesFilteredData.stream()
                .filter(c -> c.getCaseSeriousness().equalsIgnoreCase("Non Serious"))
                .collect(Collectors.groupingBy(c -> c.getInitialReceiptDate().getMonthValue(),
                        Collectors.counting()
                )).forEach((k, v) -> openNoNSeriousCasesData.merge(k, v, (v1, v2) -> v1 + v2));

//----------------------------------------------------START DELETED CASE----------------------------------------------------------------------------

        List<ClosedCaseAnalysis> deletedCasesFilteredData = closedCasesAfterFilter.stream()
                .filter(c -> Objects.nonNull(c.getDeletedDate()))
                .filter(c -> (c.getDeletedDate().equals(startDate) || c.getDeletedDate().isAfter(startDate))
                        && (c.getDeletedDate().equals(endDate) || c.getDeletedDate().isBefore(endDate)))
                .collect(Collectors.toList());

        Map<Integer, Long> totalDeletedCasesData = deletedCasesFilteredData.stream()
                .collect(Collectors.groupingBy(c -> c.getDeletedDate().getMonthValue(),
                        Collectors.counting()
                ));

        Map<Integer, Long> deletedCasesSeriousData = deletedCasesFilteredData.stream()
                .filter(c -> c.getCaseSeriousness().equalsIgnoreCase(SERIOUS))
                .collect(Collectors.groupingBy(c -> c.getDeletedDate().getMonthValue(),
                        Collectors.counting()
                ));

        Map<Integer, Long> deletedCasesNoNSeriousData = deletedCasesFilteredData.stream()
                .filter(c -> c.getCaseSeriousness().equalsIgnoreCase("Non Serious"))
                .collect(Collectors.groupingBy(c -> c.getDeletedDate().getMonthValue(),
                        Collectors.counting()
                ));

//----------------------------------------------------END DELETED CASE----------------------------------------------------------------------------

      List<Integer> lastOneYearVal = lastOneYear.stream()
                .map(l -> l.getMonthValue())
                .collect(Collectors.toList());

        List<Map<String, Object>> openCases = filteredData(totalOpenCasesData, openSeriousCasesData, openNoNSeriousCasesData, lastOneYearVal);
        List<Map<String, Object>> closeCases = filteredData(totalClosedCasesData, closedCasesSeriousData, closedCasesNoNSeriousData, lastOneYearVal);
        List<Map<String, Object>> deletedCases = filteredData(totalDeletedCasesData, deletedCasesSeriousData, deletedCasesNoNSeriousData, lastOneYearVal);

        List<String> xCategories = lastOneYear.stream()
                .map(d -> d.getMonth().getDisplayName(TextStyle.SHORT, Locale.ENGLISH) + "/" + d.getYear())
                .collect(Collectors.toList());


        List<Map<String, Object>> series = new ArrayList();

        Map<String, Object> marketedMap = new LinkedHashMap<>();
        marketedMap.put("name", CASES_RECEIVED);
        marketedMap.put("data", openCases);
        marketedMap.put("color", "#7CB5EC");

        Map<String, Object> investigationMap = new LinkedHashMap<>();
        investigationMap.put("name", CASES_CLOSED);
        investigationMap.put("data", closeCases);
        investigationMap.put("color", "#b5ec7c");

        Map<String, Object> deletedMap = new LinkedHashMap<>();
        deletedMap.put("name", CASES_DELETED);
        deletedMap.put("data", deletedCases);
        deletedMap.put("color", "#000000");

        series.add(marketedMap);
        series.add(investigationMap);
        series.add(deletedMap);

        chart.setxCategories(xCategories);
        chart.setSeries(series);
        return chart;
    }

    private List<Map<String, Object>> filteredData(Map<Integer, Long> totalCounters,
                                                   Map<Integer, Long> seriousCounters,
                                                   Map<Integer, Long> NoNSeriousCounters ,
                                                   List<Integer> lastOneYearVal) {
//        Map<Integer, Long> seriousCounters = seriousData.stream()
//                .collect(Collectors.groupingBy(c -> c,
//                        () -> new LinkedHashMap<>(),
//                        Collectors.counting()));
//
//        Map<Integer, Long> NoNSeriousCounters = NoNSeriousData.stream()
//                .collect(Collectors.groupingBy(c -> c,
//                        () -> new LinkedHashMap<>(),
//                        Collectors.counting()));
//
//        Map<Integer, List<Long>> counters = Stream.of(seriousCounters, NoNSeriousCounters)
//                .flatMap(m -> m.entrySet().stream())
//                .collect(Collectors.groupingBy(
//                        Map.Entry::getKey,
//                        Collectors.mapping(Map.Entry::getValue, Collectors.toList())
//                ));
//        Map<Integer, List<Long>> value = CommonUtil.sortedIntergerMapByValues(lastOneYearVal, counters);

        return lastOneYearVal.stream().map(m -> {
            Map<String, Object> obj = new HashMap();
            obj.put("y", totalCounters.getOrDefault(m, 0l));
            obj.put(SERIOUS, seriousCounters.getOrDefault(m, 0l));
            obj.put(NON_SERIOUS, NoNSeriousCounters.getOrDefault(m, 0l));
            return obj;
        }).collect(Collectors.toList());

//        return value.values().stream().map(t -> {
//            Map<String, Object> obj = new HashMap();
//            obj.put("y", t.stream().collect(Collectors.summingLong(Long::longValue)));
//            obj.put("serious", t.get(0));
//            obj.put("nonSerious", t.get(1));
//            return obj;
//        }).collect(Collectors.toList());
    }

    private static IntStream revRange(int from, int to) {
        return IntStream.range(from, to).map(i -> to - i + from - 1);
    }

    public List<ClosedCaseAnalysis> getCaseList(String caseType, String monthRange, String category) {
        int range;
        switch (monthRange) {
            case "3m":
                range = 2;
                break;
            case "6m":
                range = 5;
                break;
            case "9m":
                range = 8;
                break;
            case "1y":
                range = 11;
                break;
            default:
                range = 0;
                break;
        }
        final YearMonth ym = YearMonth.now();
        final YearMonth pym = ym.minusMonths(range);

        LocalDate startDate = pym.atDay(1);
        LocalDate endDate = ym.atEndOfMonth();
        List<ClosedCaseAnalysis> closedCaseAnalysis = dtoService.loadClosedCaseAnalysis();
        return filterClosedCaseAnalysis(closedCaseAnalysis, caseType, category, startDate, endDate);
    }

    public List<ClosedCaseAnalysis> getMonthlyCaseList(String caseType, String monthYear, String category) {
        LocalDate startDate = CommonUtil.convertStringToDate("01/" + monthYear, CommonUtil.dateTimeFormatter6);
        LocalDate endDate = CommonUtil.convertStringToEndDate("01/" + monthYear, CommonUtil.dateTimeFormatter6);
        List<ClosedCaseAnalysis> closedCaseAnalysis = dtoService.loadClosedCaseAnalysis();
        return filterClosedCaseAnalysis(closedCaseAnalysis, caseType, category, startDate, endDate);
    }

    private List<ClosedCaseAnalysis> filterClosedCaseAnalysis(List<ClosedCaseAnalysis> dataList, String caseType,
                                                     String category, LocalDate startDate, LocalDate endDate) {
        List<ClosedCaseAnalysis> caseList = new ArrayList<>();
        List<ClosedCaseAnalysis> closedCasesAfterFilter = dataList.stream()
                .filter(c -> {
                    boolean isFilterIn;
                    if (caseType.equalsIgnoreCase("all")) {
                        isFilterIn = true;
                    } else {
                        isFilterIn = c.getCaseType().equalsIgnoreCase(caseType);
                    }
                    return isFilterIn;
                })
                .collect(Collectors.toList());

        if (category.equalsIgnoreCase(CASES_RECEIVED)) {
            caseList.addAll(closedCasesAfterFilter.stream()
                    .filter(c -> Objects.nonNull(c.getFollowUpReceiptDate()) &&
                            (c.getFollowUpReceiptDate().equals(startDate) || c.getFollowUpReceiptDate().isAfter(startDate))
                            && (c.getFollowUpReceiptDate().equals(endDate) || c.getFollowUpReceiptDate().isBefore(endDate)))
                    .collect(Collectors.toList()));
            caseList.addAll(closedCasesAfterFilter.stream()
                    .filter(c -> Objects.isNull(c.getFollowUpReceiptDate()) && Objects.nonNull(c.getInitialReceiptDate())
                            && (c.getInitialReceiptDate().equals(startDate) || c.getInitialReceiptDate().isAfter(startDate))
                            && (c.getInitialReceiptDate().equals(endDate) || c.getInitialReceiptDate().isBefore(endDate)))
                    .collect(Collectors.toList()));
        } else if (category.equalsIgnoreCase(CASES_CLOSED)) {
            caseList.addAll(closedCasesAfterFilter.stream()
                    .filter(c -> Objects.nonNull(c.getClosedDate())
                            && (c.getClosedDate().equals(startDate) || c.getClosedDate().isAfter(startDate))
                            && (c.getClosedDate().equals(endDate) || c.getClosedDate().isBefore(endDate)))
                    .collect(Collectors.toList()));
        } else if (category.equalsIgnoreCase(CASES_DELETED)) {
            caseList.addAll(closedCasesAfterFilter.stream()
                    .filter(c -> Objects.nonNull(c.getDeletedDate())
                            && (c.getDeletedDate().equals(startDate) || c.getDeletedDate().isAfter(startDate))
                            && (c.getDeletedDate().equals(endDate) || c.getDeletedDate().isBefore(endDate)))
                    .collect(Collectors.toList()));
        } else {
            Set<ClosedCaseAnalysis> closedCaseAnalyses = new HashSet<>();
            closedCaseAnalyses.addAll(closedCasesAfterFilter.stream()
                    .filter(c -> Objects.nonNull(c.getFollowUpReceiptDate()) &&
                            (c.getFollowUpReceiptDate().equals(startDate) || c.getFollowUpReceiptDate().isAfter(startDate))
                            && (c.getFollowUpReceiptDate().equals(endDate) || c.getFollowUpReceiptDate().isBefore(endDate)))
                    .collect(Collectors.toList()));
            closedCaseAnalyses.addAll(closedCasesAfterFilter.stream()
                    .filter(c -> Objects.isNull(c.getFollowUpReceiptDate()) && Objects.nonNull(c.getInitialReceiptDate())
                            && (c.getInitialReceiptDate().equals(startDate) || c.getInitialReceiptDate().isAfter(startDate))
                            && (c.getInitialReceiptDate().equals(endDate) || c.getInitialReceiptDate().isBefore(endDate)))
                    .collect(Collectors.toList()));
            closedCaseAnalyses.addAll(closedCasesAfterFilter.stream()
                    .filter(c -> Objects.nonNull(c.getClosedDate())
                            && (c.getClosedDate().equals(startDate) || c.getClosedDate().isAfter(startDate))
                            && (c.getClosedDate().equals(endDate) || c.getClosedDate().isBefore(endDate)))
                    .collect(Collectors.toList()));
            closedCaseAnalyses.addAll(closedCasesAfterFilter.stream()
                    .filter(c -> Objects.nonNull(c.getDeletedDate())
                            && (c.getDeletedDate().equals(startDate) || c.getDeletedDate().isAfter(startDate))
                            && (c.getDeletedDate().equals(endDate) || c.getDeletedDate().isBefore(endDate)))
                    .collect(Collectors.toList()));
            caseList.addAll(closedCaseAnalyses);
        }
        return caseList;
    }
}

