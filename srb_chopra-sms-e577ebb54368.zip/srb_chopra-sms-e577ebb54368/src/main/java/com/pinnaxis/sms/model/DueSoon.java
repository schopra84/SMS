package com.pinnaxis.sms.model;

import java.util.Map;
import java.util.Objects;

public class DueSoon {

    private String title;
    private String filter;
    private long totalCases = 0;
    private String iconType;
    private String titleClass;
    private String panelClass;

    private WorkflowState dataEntry;
    private WorkflowState qualityReview;
    private WorkflowState medicalReview;
    private WorkflowState distribution;

    Map<String, Long> reportStatus;
    Map<String, Long> noProgress;


    public DueSoon(String title, String iconType, String filter) {
        this.title = title;
        this.iconType = iconType;
        this.filter =  filter;
    }

    public DueSoon(String title, String iconType, String titleClass, String panelClass, String filter) {
        this.title = title;
        this.iconType = iconType;
        this.titleClass = titleClass;
        this.panelClass = panelClass;
        this.filter =  filter;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFilter() {
        return filter;
    }

    public void setFilter(String filter) {
        this.filter = filter;
    }

    public long getTotalCases() {
        return totalCases;
    }

    public void setTotalCases(long totalCases) {
        this.totalCases = totalCases;
    }

    public String getIconType() {
        return iconType;
    }

    public void setIconType(String iconType) {
        this.iconType = iconType;
    }

    public String getTitleClass() {
        return titleClass;
    }

    public void setTitleClass(String titleClass) {
        this.titleClass = titleClass;
    }

    public String getPanelClass() {
        return panelClass;
    }

    public void setPanelClass(String panelClass) {
        this.panelClass = panelClass;
    }

    public WorkflowState getDataEntry() {
        return dataEntry;
    }

    public void setDataEntry(WorkflowState dataEntry) {
        this.dataEntry = dataEntry;
    }

    public WorkflowState getQualityReview() {
        return qualityReview;
    }

    public void setQualityReview(WorkflowState qualityReview) {
        this.qualityReview = qualityReview;
    }

    public WorkflowState getMedicalReview() {
        return medicalReview;
    }

    public void setMedicalReview(WorkflowState medicalReview) {
        this.medicalReview = medicalReview;
    }

    public WorkflowState getDistribution() {
        return distribution;
    }

    public void setDistribution(WorkflowState distribution) {
        this.distribution = distribution;
    }

    public Map<String, Long> getReportStatus() {
        return reportStatus;
    }

    public void setReportStatus(Map<String, Long> reportStatus) {
        this.reportStatus = reportStatus;
    }

    public Map<String, Long> getNoProgress() {
        return noProgress;
    }

    public void setNoProgress(Map<String, Long> noProgress) {
        this.noProgress = noProgress;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DueSoon dueSoon = (DueSoon) o;
        return totalCases == dueSoon.totalCases &&
                Objects.equals(title, dueSoon.title) &&
                Objects.equals(filter, dueSoon.filter) &&
                Objects.equals(iconType, dueSoon.iconType) &&
                Objects.equals(titleClass, dueSoon.titleClass) &&
                Objects.equals(panelClass, dueSoon.panelClass) &&
                Objects.equals(dataEntry, dueSoon.dataEntry) &&
                Objects.equals(qualityReview, dueSoon.qualityReview) &&
                Objects.equals(medicalReview, dueSoon.medicalReview) &&
                Objects.equals(distribution, dueSoon.distribution) &&
                Objects.equals(reportStatus, dueSoon.reportStatus) &&
                Objects.equals(noProgress, dueSoon.noProgress);
    }

    @Override
    public int hashCode() {

        return Objects.hash(title, filter, totalCases, iconType, titleClass, panelClass, dataEntry, qualityReview, medicalReview, distribution, reportStatus, noProgress);
    }

    @Override
    public String toString() {
        return "DueSoon{" +
                "title='" + title + '\'' +
                ", filter='" + filter + '\'' +
                ", totalCases=" + totalCases +
                ", iconType='" + iconType + '\'' +
                ", titleClass='" + titleClass + '\'' +
                ", panelClass='" + panelClass + '\'' +
                ", dataEntry=" + dataEntry +
                ", qualityReview=" + qualityReview +
                ", medicalReview=" + medicalReview +
                ", distribution=" + distribution +
                ", reportStatus=" + reportStatus +
                ", noProgress=" + noProgress +
                '}';
    }
}
