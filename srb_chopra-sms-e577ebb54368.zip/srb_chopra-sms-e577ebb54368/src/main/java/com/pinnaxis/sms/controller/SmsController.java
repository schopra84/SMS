package com.pinnaxis.sms.controller;

import com.pinnaxis.sms.model.OpenCase;
import com.pinnaxis.sms.services.TrackCaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.*;
import java.util.stream.Collectors;

@Controller
public class SmsController {

    @Autowired
    private TrackCaseService trackCaseService;

    @RequestMapping(value = "/getCaseDetails", method = RequestMethod.GET)
    public ResponseEntity<?> getCaseDetails(
            @RequestParam(value = "todayDate") String todayDateVal,
            @RequestParam(value = "type1") String type1,
            @RequestParam(value = "filter1") String filter1,
            @RequestParam(value = "type2", required = false, defaultValue = "") String type2,
            @RequestParam(value = "filter2", required = false, defaultValue = "") String filter2,
            @RequestParam(value = "type3", required = false, defaultValue = "") String type3,
            @RequestParam(value = "filter3", required = false, defaultValue = "") String filter3) {
        List<OpenCase> openCases = trackCaseService.getCaseDetails(todayDateVal, type1, filter1,
                type2, filter2, filter3, type3);
        return ResponseEntity.ok(openCases);
    }
}
