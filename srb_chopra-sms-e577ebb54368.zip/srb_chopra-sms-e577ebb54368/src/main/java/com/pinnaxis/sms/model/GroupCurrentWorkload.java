package com.pinnaxis.sms.model;

import java.util.List;

public class GroupCurrentWorkload {
    private String group;
    List<CurrentWorkload> currentWorkloads;

    public GroupCurrentWorkload(String group, List<CurrentWorkload> currentWorkloads) {
        this.group = group;
        this.currentWorkloads = currentWorkloads;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public List<CurrentWorkload> getCurrentWorkloads() {
        return currentWorkloads;
    }

    public void setCurrentWorkloads(List<CurrentWorkload> currentWorkloads) {
        this.currentWorkloads = currentWorkloads;
    }
}
