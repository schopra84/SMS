package com.pinnaxis.sms.model;

import com.pinnaxis.sms.util.CommonUtil;

import java.time.LocalDate;
import java.util.Objects;

public class ClosedCaseAnalysis {

    private String caseId, caseNum, caseType, reportType, country, caseSeriousness, susar,
            initialReceiptDateVal, followUpReceiptDateVal, studyId, primaryProductName,
            primaryProductGenericName, primaryEventVerbatim, primaryEventPreferredTerm, closedDateVal, deletedDateVal;

    private long daysProcess;

    private LocalDate initialReceiptDate, followUpReceiptDate, closedDate, deletedDate;

    public ClosedCaseAnalysis(String caseId, String caseNum, String caseType, String reportType,
                              String country, String caseSeriousness, String susar, LocalDate initialReceiptDate,
                              LocalDate followUpReceiptDate, String studyId, String primaryProductName,
                              String primaryProductGenericName, String primaryEventVerbatim,
                              String primaryEventPreferredTerm, LocalDate closedDate, long daysProcess, LocalDate deletedDate) {
        this.caseId = caseId;
        this.caseNum = caseNum;
        this.caseType = caseType;
        this.reportType = reportType;
        this.country = country;
        this.caseSeriousness = caseSeriousness;
        this.susar = susar;
        this.initialReceiptDate = initialReceiptDate;
        this.followUpReceiptDate = followUpReceiptDate;
        this.studyId = studyId;
        this.primaryProductName = primaryProductName;
        this.primaryProductGenericName = primaryProductGenericName;
        this.primaryEventVerbatim = primaryEventVerbatim;
        this.primaryEventPreferredTerm = primaryEventPreferredTerm;
        this.closedDate = closedDate;
        this.daysProcess = daysProcess;
        this.deletedDate = deletedDate;

        if(Objects.nonNull(initialReceiptDate)) {
            this.initialReceiptDateVal = CommonUtil.dateTimeFormatter1.format(initialReceiptDate);
        }
        if(Objects.nonNull(followUpReceiptDate)) {
            this.followUpReceiptDateVal = CommonUtil.dateTimeFormatter1.format(followUpReceiptDate);
        }

        if(Objects.nonNull(closedDate)) {
            this.closedDateVal = CommonUtil.dateTimeFormatter1.format(closedDate);
        }

        if(Objects.nonNull(deletedDate)) {
            this.deletedDateVal = CommonUtil.dateTimeFormatter1.format(deletedDate);
        }
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public String getCaseNum() {
        return caseNum;
    }

    public void setCaseNum(String caseNum) {
        this.caseNum = caseNum;
    }

    public String getCaseType() {
        return caseType;
    }

    public void setCaseType(String caseType) {
        this.caseType = caseType;
    }

    public String getReportType() {
        return reportType;
    }

    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCaseSeriousness() {
        return caseSeriousness;
    }

    public void setCaseSeriousness(String caseSeriousness) {
        this.caseSeriousness = caseSeriousness;
    }

    public String getInitialReceiptDateVal() {
        return initialReceiptDateVal;
    }

    public void setInitialReceiptDateVal(String initialReceiptDateVal) {
        this.initialReceiptDateVal = initialReceiptDateVal;
    }

    public String getFollowUpReceiptDateVal() {
        return followUpReceiptDateVal;
    }

    public void setFollowUpReceiptDateVal(String followUpReceiptDateVal) {
        this.followUpReceiptDateVal = followUpReceiptDateVal;
    }

    public String getStudyId() {
        return studyId;
    }

    public void setStudyId(String studyId) {
        this.studyId = studyId;
    }

    public String getPrimaryProductName() {
        return primaryProductName;
    }

    public void setPrimaryProductName(String primaryProductName) {
        this.primaryProductName = primaryProductName;
    }

    public String getPrimaryProductGenericName() {
        return primaryProductGenericName;
    }

    public void setPrimaryProductGenericName(String primaryProductGenericName) {
        this.primaryProductGenericName = primaryProductGenericName;
    }

    public String getPrimaryEventVerbatim() {
        return primaryEventVerbatim;
    }

    public void setPrimaryEventVerbatim(String primaryEventVerbatim) {
        this.primaryEventVerbatim = primaryEventVerbatim;
    }

    public String getPrimaryEventPreferredTerm() {
        return primaryEventPreferredTerm;
    }

    public void setPrimaryEventPreferredTerm(String primaryEventPreferredTerm) {
        this.primaryEventPreferredTerm = primaryEventPreferredTerm;
    }

    public String getClosedDateVal() {
        return closedDateVal;
    }

    public void setClosedDateVal(String closedDateVal) {
        this.closedDateVal = closedDateVal;
    }

    public LocalDate getInitialReceiptDate() {
        return initialReceiptDate;
    }

    public void setInitialReceiptDate(LocalDate initialReceiptDate) {
        this.initialReceiptDate = initialReceiptDate;
    }

    public LocalDate getFollowUpReceiptDate() {
        return followUpReceiptDate;
    }

    public void setFollowUpReceiptDate(LocalDate followUpReceiptDate) {
        this.followUpReceiptDate = followUpReceiptDate;
    }

    public LocalDate getClosedDate() {
        return closedDate;
    }

    public void setClosedDate(LocalDate closedDate) {
        this.closedDate = closedDate;
    }

    public String getSusar() {
        return susar;
    }

    public void setSusar(String susar) {
        this.susar = susar;
    }

    public long getDaysProcess() {
        return daysProcess;
    }

    public void setDaysProcess(long daysProcess) {
        this.daysProcess = daysProcess;
    }

    public String getDeletedDateVal() {
        return deletedDateVal;
    }

    public void setDeletedDateVal(String deletedDateVal) {
        this.deletedDateVal = deletedDateVal;
    }

    public LocalDate getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(LocalDate deletedDate) {
        this.deletedDate = deletedDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClosedCaseAnalysis that = (ClosedCaseAnalysis) o;
        return daysProcess == that.daysProcess &&
                Objects.equals(caseId, that.caseId) &&
                Objects.equals(caseNum, that.caseNum) &&
                Objects.equals(caseType, that.caseType) &&
                Objects.equals(reportType, that.reportType) &&
                Objects.equals(country, that.country) &&
                Objects.equals(caseSeriousness, that.caseSeriousness) &&
                Objects.equals(susar, that.susar) &&
                Objects.equals(initialReceiptDateVal, that.initialReceiptDateVal) &&
                Objects.equals(followUpReceiptDateVal, that.followUpReceiptDateVal) &&
                Objects.equals(studyId, that.studyId) &&
                Objects.equals(primaryProductName, that.primaryProductName) &&
                Objects.equals(primaryProductGenericName, that.primaryProductGenericName) &&
                Objects.equals(primaryEventVerbatim, that.primaryEventVerbatim) &&
                Objects.equals(primaryEventPreferredTerm, that.primaryEventPreferredTerm) &&
                Objects.equals(closedDateVal, that.closedDateVal) &&
                Objects.equals(deletedDateVal, that.deletedDateVal) &&
                Objects.equals(initialReceiptDate, that.initialReceiptDate) &&
                Objects.equals(followUpReceiptDate, that.followUpReceiptDate) &&
                Objects.equals(closedDate, that.closedDate) &&
                Objects.equals(deletedDate, that.deletedDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(caseId, caseNum, caseType, reportType, country, caseSeriousness, susar, initialReceiptDateVal, followUpReceiptDateVal, studyId, primaryProductName, primaryProductGenericName, primaryEventVerbatim, primaryEventPreferredTerm, closedDateVal, deletedDateVal, daysProcess, initialReceiptDate, followUpReceiptDate, closedDate, deletedDate);
    }

    @Override
    public String toString() {
        return "ClosedCaseAnalysis{" +
                "caseId='" + caseId + '\'' +
                ", caseNum='" + caseNum + '\'' +
                ", caseType='" + caseType + '\'' +
                ", reportType='" + reportType + '\'' +
                ", country='" + country + '\'' +
                ", caseSeriousness='" + caseSeriousness + '\'' +
                ", susar='" + susar + '\'' +
                ", initialReceiptDateVal='" + initialReceiptDateVal + '\'' +
                ", followUpReceiptDateVal='" + followUpReceiptDateVal + '\'' +
                ", studyId='" + studyId + '\'' +
                ", primaryProductName='" + primaryProductName + '\'' +
                ", primaryProductGenericName='" + primaryProductGenericName + '\'' +
                ", primaryEventVerbatim='" + primaryEventVerbatim + '\'' +
                ", primaryEventPreferredTerm='" + primaryEventPreferredTerm + '\'' +
                ", closedDateVal='" + closedDateVal + '\'' +
                ", deletedDateVal='" + deletedDateVal + '\'' +
                ", daysProcess=" + daysProcess +
                ", initialReceiptDate=" + initialReceiptDate +
                ", followUpReceiptDate=" + followUpReceiptDate +
                ", closedDate=" + closedDate +
                ", deletedDate=" + deletedDate +
                '}';
    }
}
