package com.pinnaxis.sms.model;

public class PendingSubmissionCase {
    private String caseNumber, receiptDate, caseType, lockedDate, productName, country, assignedTo, caseSeriousness,
    reportingDestination, reportForm, reportScheduledDate, generationsStatus, generationError, generatedStatus,
    submissionStatus, submissionError;

    public PendingSubmissionCase(String caseNumber, String caseType, String lockedDate) {
        this.caseNumber = caseNumber;
        this.caseType = caseType;
        this.lockedDate = lockedDate;
    }

    public PendingSubmissionCase(String caseNumber, String receiptDate, String caseType, String lockedDate, String productName, String country, String assignedTo, String caseSeriousness) {
        this.caseNumber = caseNumber;
        this.receiptDate = receiptDate;
        this.caseType = caseType;
        this.lockedDate = lockedDate;
        this.productName = productName;
        this.country = country;
        this.assignedTo = assignedTo;
        this.caseSeriousness = caseSeriousness;
    }


    public PendingSubmissionCase(String caseNumber, String caseType, String lockedDate, String reportingDestination, String reportForm, String reportScheduledDate, String generationsStatus, String generationError, String blank) {
        this.caseNumber = caseNumber;
        this.caseType = caseType;
        this.lockedDate = lockedDate;
        this.reportingDestination = reportingDestination;
        this.reportForm = reportForm;
        this.reportScheduledDate = reportScheduledDate;
        this.generationsStatus = generationsStatus;
        this.generationError = generationError;
    }


    public PendingSubmissionCase(String caseNumber, String caseType, String lockedDate, String reportingDestination, String reportForm, String reportScheduledDate, String generationsStatus, String generatedStatus, String submissionStatus, String submissionError) {
        this.caseNumber = caseNumber;
        this.caseType = caseType;
        this.lockedDate = lockedDate;
        this.reportingDestination = reportingDestination;
        this.reportForm = reportForm;
        this.reportScheduledDate = reportScheduledDate;
        this.generationsStatus = generationsStatus;
        this.generatedStatus = generatedStatus;
        this.submissionStatus = submissionStatus;
        this.submissionError = submissionError;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public String getReceiptDate() {
        return receiptDate;
    }

    public void setReceiptDate(String receiptDate) {
        this.receiptDate = receiptDate;
    }

    public String getCaseType() {
        return caseType;
    }

    public void setCaseType(String caseType) {
        this.caseType = caseType;
    }

    public String getLockedDate() {
        return lockedDate;
    }

    public void setLockedDate(String lockedDate) {
        this.lockedDate = lockedDate;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getAssignedTo() {
        return assignedTo;
    }

    public void setAssignedTo(String assignedTo) {
        this.assignedTo = assignedTo;
    }

    public String getCaseSeriousness() {
        return caseSeriousness;
    }

    public void setCaseSeriousness(String caseSeriousness) {
        this.caseSeriousness = caseSeriousness;
    }

    public String getReportingDestination() {
        return reportingDestination;
    }

    public void setReportingDestination(String reportingDestination) {
        this.reportingDestination = reportingDestination;
    }

    public String getReportForm() {
        return reportForm;
    }

    public void setReportForm(String reportForm) {
        this.reportForm = reportForm;
    }

    public String getReportScheduledDate() {
        return reportScheduledDate;
    }

    public void setReportScheduledDate(String reportScheduledDate) {
        this.reportScheduledDate = reportScheduledDate;
    }

    public String getGenerationsStatus() {
        return generationsStatus;
    }

    public void setGenerationsStatus(String generationsStatus) {
        this.generationsStatus = generationsStatus;
    }

    public String getGenerationError() {
        return generationError;
    }

    public void setGenerationError(String generationError) {
        this.generationError = generationError;
    }

    public String getGeneratedStatus() {
        return generatedStatus;
    }

    public void setGeneratedStatus(String generatedStatus) {
        this.generatedStatus = generatedStatus;
    }

    public String getSubmissionStatus() {
        return submissionStatus;
    }

    public void setSubmissionStatus(String submissionStatus) {
        this.submissionStatus = submissionStatus;
    }

    public String getSubmissionError() {
        return submissionError;
    }

    public void setSubmissionError(String submissionError) {
        this.submissionError = submissionError;
    }
}
