package com.pinnaxis.sms.model;

public class CaseDataQualityError {
    private String errorSeverity,  errorWorkflow, errorMessage, errorEnabled, errorSql, errorModule;

    private int errorId;

    public CaseDataQualityError(int errorId, String errorSeverity, String errorModule, String errorWorkflow, String errorEnabled, String errorMessage, String errorSql) {
        this.errorSeverity = errorSeverity;
        this.errorModule = errorModule;
        this.errorWorkflow = errorWorkflow;
        this.errorEnabled = errorEnabled;
        this.errorMessage = errorMessage;
        this.errorSql = errorSql;
        this.errorId = errorId;
    }

    public String getErrorSeverity() {
        return errorSeverity;
    }

    public void setErrorSeverity(String errorSeverity) {
        this.errorSeverity = errorSeverity;
    }

    public String getErrorModule() {
        return errorModule;
    }

    public void setErrorModule(String errorModule) {
        this.errorModule = errorModule;
    }

    public String getErrorWorkflow() {
        return errorWorkflow;
    }

    public void setErrorWorkflow(String errorWorkflow) {
        this.errorWorkflow = errorWorkflow;
    }

    public String getErrorEnabled() {
        return errorEnabled;
    }

    public void setErrorEnabled(String errorEnabled) {
        this.errorEnabled = errorEnabled;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getErrorSql() {
        return errorSql;
    }

    public void setErrorSql(String errorSql) {
        this.errorSql = errorSql;
    }

    public int getErrorId() {
        return errorId;
    }

    public void setErrorId(int errorId) {
        this.errorId = errorId;
    }
}
