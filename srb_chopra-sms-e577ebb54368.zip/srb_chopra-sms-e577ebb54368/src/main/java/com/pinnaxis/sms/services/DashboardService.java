package com.pinnaxis.sms.services;

import com.pinnaxis.sms.config.ApplicationProperties;
import com.pinnaxis.sms.config.KeyIndicator;
import com.pinnaxis.sms.model.ActionItem;
import com.pinnaxis.sms.model.KeyIndicatorVo;
import com.pinnaxis.sms.model.OpenCase;
import com.pinnaxis.sms.model.SubmissionData;
import com.pinnaxis.sms.util.CommonUtil;
import com.pinnaxis.sms.util.SMSConstant;
import org.apache.commons.collections4.ListUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class DashboardService implements SMSConstant {

    @Autowired
    private DTOService dtoService;

    @Autowired
    private ApplicationProperties properties;

    public List<List<KeyIndicatorVo>> getKeyIndicators(String todayDateVal) {
        LocalDate todayDate = CommonUtil.convertStringToDate(todayDateVal, CommonUtil.dateTimeFormatter4);
        List<OpenCase> openCase = dtoService.loadOpenCases(todayDate);
        List<SubmissionData> submissionData = dtoService.loadSubmissionData();
        List<ActionItem> actionItems = dtoService.loadActionItem();

        List<KeyIndicatorVo> keyIndicatorVo = properties.getKeyIndicators().stream()
                .filter(KeyIndicator::isEnable)
                .map(k -> populateKeyIndicator(k, openCase, submissionData, actionItems, todayDate))
                .collect(Collectors.toList());

        List<List<KeyIndicatorVo>> keyIndicatorsVo = ListUtils.partition(keyIndicatorVo, 3);
        return keyIndicatorsVo;
    }

    public List<OpenCase> getOpenCaseList(String todayDateVal, String keyIndicatorType){
        LocalDate todayDate = CommonUtil.convertStringToDate(todayDateVal, CommonUtil.dateTimeFormatter4);
        List<OpenCase> openCases = dtoService.loadOpenCases(todayDate);
        List<OpenCase> filteredOpenCases;
        switch (keyIndicatorType) {
            case SMSConstant.RECEIVED_TODAY:
                filteredOpenCases = openCases.stream().filter(c -> c.getAwareDate().equals(todayDate) && Objects.isNull(c.getDeletedDate()))
                        .collect(Collectors.toList());
                break;
            case SMSConstant.PROCESSED_TODAY:
                filteredOpenCases = openCases.stream().filter(c -> c.getLastUpdateTime().equals(todayDate) && Objects.isNull(c.getDeletedDate()))
                        .collect(Collectors.toList());
                break;
            case SMSConstant.ACTIVE_CASES:
                filteredOpenCases = openCases.stream().filter(CommonUtil.distinctByKey(c -> c.getCaseId()))
                        .filter(c -> Objects.isNull(c.getDeletedDate()))
                        .collect(Collectors.toList());
                break;
            case SMSConstant.SUBMISSION_TODAY:
                filteredOpenCases = openCases.stream().filter(c -> c.getDueSoon().equalsIgnoreCase("1") && Objects.isNull(c.getDeletedDate()))
                        .collect(Collectors.toList());
                break;
            case SMSConstant.DUE_TODAY:
                List<ActionItem> actionItems = dtoService.loadActionItem();
                Map<String, OpenCase> openCasesMap = openCases.stream().filter(c -> Objects.isNull(c.getDeletedDate())).collect(Collectors.toMap(OpenCase::getCaseId, Function.identity()));
                filteredOpenCases = actionItems.stream()
                        .filter(a -> Objects.nonNull(a.getDueDate()) && a.getDueDate().equals(todayDate))
                        .map(a -> openCasesMap.get(a.getCaseId()))
                        .collect(Collectors.toList());
                break;
            default:
                filteredOpenCases = Collections.EMPTY_LIST;
                break;
        }
        return filteredOpenCases;
    }

    public List<SubmissionData> getSubmissionCaseList(){
        List<SubmissionData> submissionData = dtoService.loadSubmissionData();
        return submissionData.stream()
                .filter(s -> Objects.nonNull(s.getSubmissionError()) && Objects.nonNull(s.getGenerationError()))
                .collect(Collectors.toList());
    }

    private KeyIndicatorVo populateKeyIndicator(KeyIndicator keyIndicator, List<OpenCase> openCases,
                                                List<SubmissionData> submissionData, List<ActionItem> actionItems,
                                                LocalDate todayDate) {
        KeyIndicatorVo keyIndicatorVo;
        long count;
        switch (keyIndicator.getFilter()) {
            case SMSConstant.RECEIVED_TODAY:
                count = openCases.stream().filter(c -> c.getAwareDate().equals(todayDate) && Objects.isNull(c.getDeletedDate()))
                        .collect(Collectors.counting());
                keyIndicatorVo = new KeyIndicatorVo(keyIndicator.getHeader(), count,
                        count > keyIndicator.getMinimumSize() ? BG_RED : BG_GREEN, keyIndicator.getFilter());
                break;
            case SMSConstant.PROCESSED_TODAY:
                count = openCases.stream().filter(c -> c.getLastUpdateTime().equals(todayDate) && Objects.isNull(c.getDeletedDate()))
                        .collect(Collectors.counting());
                keyIndicatorVo = new KeyIndicatorVo(keyIndicator.getHeader(), count,
                        count > keyIndicator.getMinimumSize() ? BG_RED : BG_GREEN, keyIndicator.getFilter());
                break;
            case SMSConstant.ACTIVE_CASES:
                count = openCases.stream().filter(CommonUtil.distinctByKey(c -> c.getCaseId()))
                        .filter(c -> Objects.isNull(c.getDeletedDate()))
                        .collect(Collectors.counting());
                keyIndicatorVo = new KeyIndicatorVo(keyIndicator.getHeader(), count,
                        count > keyIndicator.getMinimumSize() ? BG_RED : BG_GREEN, keyIndicator.getFilter());
                break;
            case SMSConstant.SUBMISSION_TODAY:
                count = openCases.stream().filter(c -> c.getDueSoon().equalsIgnoreCase("1") && Objects.isNull(c.getDeletedDate()))
                        .collect(Collectors.counting());
                keyIndicatorVo = new KeyIndicatorVo(keyIndicator.getHeader(), count,
                        count > keyIndicator.getMinimumSize() ? BG_RED : BG_GREEN, keyIndicator.getFilter());
                break;
            case SMSConstant.FAILED_SUBMISSION:
                count = submissionData.stream().filter(s -> Objects.nonNull(s.getSubmissionError()) && Objects.nonNull(s.getGenerationError()))
                        .collect(Collectors.counting());
                keyIndicatorVo = new KeyIndicatorVo(keyIndicator.getHeader(), count,
                        count > keyIndicator.getMinimumSize() ? BG_RED : BG_GREEN, keyIndicator.getFilter());
                break;
            case SMSConstant.DUE_TODAY:
                count = actionItems.stream().filter(a -> Objects.nonNull(a.getDueDate()) && a.getDueDate().equals(todayDate))
                        .collect(Collectors.counting());
                keyIndicatorVo = new KeyIndicatorVo(keyIndicator.getHeader(), count,
                        count > keyIndicator.getMinimumSize() ? BG_RED : BG_GREEN, keyIndicator.getFilter());
                break;
            default:
                keyIndicatorVo = null;
                break;
        }
        return keyIndicatorVo;
    }
}
