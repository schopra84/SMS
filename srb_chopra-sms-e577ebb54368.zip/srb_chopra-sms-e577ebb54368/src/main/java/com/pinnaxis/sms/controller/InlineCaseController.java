package com.pinnaxis.sms.controller;

import com.pinnaxis.sms.model.InlineCaseDetail;
import com.pinnaxis.sms.model.InlineCaseErrorDetail;
import com.pinnaxis.sms.model.InlineQualityCase;
import com.pinnaxis.sms.model.OpenCase;
import com.pinnaxis.sms.services.InlineQualityCaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class InlineCaseController {

    private final static String INLINE_DATA_ENTRY = "Data Entry";
    private final static String INLINE_QUALITY_REVIEW = "Quality Review";
    private final static String INLINE_MEDICAL_REVIEW = "Medical Review";
    private final static String INLINE_DISTRIBUTION = "Distribution";

    @Autowired
    private InlineQualityCaseService inlineQualityCaseService;

    @RequestMapping("/inline-case")
    public String inlineQualityCase() {
        return "inline-quality-case";
    }

    @RequestMapping(value = "/getInlineCaseDetails", method = RequestMethod.GET)
    public ResponseEntity<?> getInlineCaseDetails(
            @RequestParam(value = "type") String type,
            @RequestParam(value = "startDate") String startDateVal,
            @RequestParam(value = "endDate") String endDateVal,
            @RequestParam(value = "errorType") String errorType) {
        List<InlineCaseDetail> inlineCaseDetails = inlineQualityCaseService.getInlineCaseDetails(type, startDateVal, endDateVal, errorType);
        return ResponseEntity.ok(inlineCaseDetails);
    }

    @RequestMapping(value = "/getInlineCaseErrorDetails", method = RequestMethod.GET)
    public ResponseEntity<?> getInlineCaseErrorDetails(
            @RequestParam(value = "caseNumber") String caseNumber,
            @RequestParam(value = "startDate") String startDateVal,
            @RequestParam(value = "endDate") String endDateVal,
            @RequestParam(value = "errorType") String errorType) {
        List<InlineCaseErrorDetail> inlineCaseDetails = inlineQualityCaseService.getInlineCaseErrorDetails(caseNumber, startDateVal, endDateVal, errorType);
        return ResponseEntity.ok(inlineCaseDetails);
    }

    @RequestMapping("/getInlineDataEntry")
    public String getInlineDataEntry(Model model,
                                     @RequestParam(value = "startDate") String startDateVal,
                                     @RequestParam(value = "endDate") String endDateVal) {
        InlineQualityCase caseData = new InlineQualityCase(INLINE_DATA_ENTRY.toUpperCase(), "ion-android-people", false,
                "Data Entry in progress");
        inlineQualityCaseService.populateInlineDetails(caseData, INLINE_DATA_ENTRY, startDateVal, endDateVal);
        model.addAttribute(caseData);
        return "inline-sub-quality-case";
    }

    @RequestMapping("/getInlineQualityReview")
    public String getInlineQualityReview(Model model,
                                         @RequestParam(value = "startDate") String startDateVal,
                                         @RequestParam(value = "endDate") String endDateVal) {
        InlineQualityCase caseData = new InlineQualityCase(INLINE_QUALITY_REVIEW.toUpperCase(), "ion-android-checkbox", false,
                "Issues post Data Entry");
        inlineQualityCaseService.populateInlineDetails(caseData, INLINE_QUALITY_REVIEW, startDateVal, endDateVal);
        model.addAttribute(caseData);
        return "inline-sub-quality-case";
    }

    @RequestMapping("/getInlineMedicalReview")
    public String getInlineMedicalReview(Model model,
                                         @RequestParam(value = "startDate") String startDateVal,
                                         @RequestParam(value = "endDate") String endDateVal) {
        InlineQualityCase caseData = new InlineQualityCase(INLINE_MEDICAL_REVIEW.toUpperCase(), "ion-eye", false,
                "Issues post Quality Review");
        inlineQualityCaseService.populateInlineDetails(caseData, INLINE_MEDICAL_REVIEW, startDateVal, endDateVal);
        model.addAttribute(caseData);
        return "inline-sub-quality-case";
    }

    @RequestMapping("/getInlineDistribution")
    public String getInlineDistribution(Model model,
                                        @RequestParam(value = "startDate") String startDateVal,
                                        @RequestParam(value = "endDate") String endDateVal) {
        InlineQualityCase caseData = new InlineQualityCase(INLINE_DISTRIBUTION.toUpperCase(), "ion-android-mail", true,
                "Issues post Medical Review");
        inlineQualityCaseService.populateInlineDetails(caseData, INLINE_DISTRIBUTION, startDateVal, endDateVal);
        model.addAttribute(caseData);
        return "inline-sub-quality-case";
    }
}
