package com.pinnaxis.sms.model;

import java.util.Objects;

public class ReportDataSet {
    private String caseNumber, reportForm, reportingDestination, generationStatus,
            submissionStatus, generationError, submissionError;

    public ReportDataSet(String caseNumber, String reportForm, String reportingDestination, String generationStatus, String submissionStatus, String generationError, String submissionError) {
        this.caseNumber = caseNumber;
        this.reportForm = reportForm;
        this.reportingDestination = reportingDestination;
        this.generationStatus = generationStatus;
        this.submissionStatus = submissionStatus;
        this.generationError = generationError;
        this.submissionError = submissionError;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public String getReportForm() {
        return reportForm;
    }

    public void setReportForm(String reportForm) {
        this.reportForm = reportForm;
    }

    public String getReportingDestination() {
        return reportingDestination;
    }

    public void setReportingDestination(String reportingDestination) {
        this.reportingDestination = reportingDestination;
    }

    public String getGenerationStatus() {
        return generationStatus;
    }

    public void setGenerationStatus(String generationStatus) {
        this.generationStatus = generationStatus;
    }

    public String getSubmissionStatus() {
        return submissionStatus;
    }

    public void setSubmissionStatus(String submissionStatus) {
        this.submissionStatus = submissionStatus;
    }

    public String getGenerationError() {
        return generationError;
    }

    public void setGenerationError(String generationError) {
        this.generationError = generationError;
    }

    public String getSubmissionError() {
        return submissionError;
    }

    public void setSubmissionError(String submissionError) {
        this.submissionError = submissionError;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ReportDataSet that = (ReportDataSet) o;
        return Objects.equals(caseNumber, that.caseNumber) &&
                Objects.equals(reportForm, that.reportForm) &&
                Objects.equals(reportingDestination, that.reportingDestination) &&
                Objects.equals(generationStatus, that.generationStatus) &&
                Objects.equals(submissionStatus, that.submissionStatus) &&
                Objects.equals(generationError, that.generationError) &&
                Objects.equals(submissionError, that.submissionError);
    }

    @Override
    public int hashCode() {

        return Objects.hash(caseNumber, reportForm, reportingDestination, generationStatus, submissionStatus, generationError, submissionError);
    }

    @Override
    public String toString() {
        return "ReportDataSet{" +
                "caseNumber='" + caseNumber + '\'' +
                ", reportForm='" + reportForm + '\'' +
                ", reportingDestination='" + reportingDestination + '\'' +
                ", generationStatus='" + generationStatus + '\'' +
                ", submissionStatus='" + submissionStatus + '\'' +
                ", generationError='" + generationError + '\'' +
                ", submissionError='" + submissionError + '\'' +
                '}';
    }
}
