package com.pinnaxis.sms.dao.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name = "V_SMS_WORKLOAD")
public class WorkloadInfo extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Column(name = "EVENT_VERBATIM") private String eventVerbatim;
    @Column(name = "SUSAR") private String susar;
    @Column(name = "WORKFLOW_CATEGORY") private String workflowCategory;
    @Column(name = "SIG_RECEIPT_DATE") private LocalDate sigReceiptDate;
    @Column(name = "FLAG_FOR_CONTACT_ACTION") private Long flagForContactAction;
    @Column(name = "CASE_USER_NAME") private String caseUserName;
    @Column(name = "CASE_GROUP_NAME") private String caseGroupName;
    @Column(name = "ASSIGNED_USER_NAME") private String assignedUserName;
    @Column(name = "ASSIGNED_GROUP_NAME") private String assignedGroupName;
    @Column(name = "CODE") private Long code;
    @Column(name = "DUE_DATE") private LocalDate dueDate;
    @Column(name = "DATE_OPEN") private LocalDate dateOpen;
    @Column(name = "DESCRIPTION") private String description;
    @Column(name = "ACTION_TYPE") private String actionType;

    public String getEventVerbatim() {
        return eventVerbatim;
    }

    public void setEventVerbatim(String eventVerbatim) {
        this.eventVerbatim = eventVerbatim;
    }

    public String getSusar() {
        return susar;
    }

    public void setSusar(String susar) {
        this.susar = susar;
    }

    public String getWorkflowCategory() {
        return workflowCategory;
    }

    public void setWorkflowCategory(String workflowCategory) {
        this.workflowCategory = workflowCategory;
    }

    public LocalDate getSigReceiptDate() {
        return sigReceiptDate;
    }

    public void setSigReceiptDate(LocalDate sigReceiptDate) {
        this.sigReceiptDate = sigReceiptDate;
    }

    public Long getFlagForContactAction() {
        return flagForContactAction;
    }

    public void setFlagForContactAction(Long flagForContactAction) {
        this.flagForContactAction = flagForContactAction;
    }

    public String getCaseUserName() {
        return caseUserName;
    }

    public void setCaseUserName(String caseUserName) {
        this.caseUserName = caseUserName;
    }

    public String getCaseGroupName() {
        return caseGroupName;
    }

    public void setCaseGroupName(String caseGroupName) {
        this.caseGroupName = caseGroupName;
    }

    public String getAssignedUserName() {
        return assignedUserName;
    }

    public void setAssignedUserName(String assignedUserName) {
        this.assignedUserName = assignedUserName;
    }

    public String getAssignedGroupName() {
        return assignedGroupName;
    }

    public void setAssignedGroupName(String assignedGroupName) {
        this.assignedGroupName = assignedGroupName;
    }

    public Long getCode() {
        return code;
    }

    public void setCode(Long code) {
        this.code = code;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDate getDateOpen() {
        return dateOpen;
    }

    public void setDateOpen(LocalDate dateOpen) {
        this.dateOpen = dateOpen;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }
}
