package com.pinnaxis.sms.controller;

import com.pinnaxis.sms.model.DueSoon;
import com.pinnaxis.sms.model.OpenCase;
import com.pinnaxis.sms.model.WorkflowState;
import com.pinnaxis.sms.services.CacheService;
import com.pinnaxis.sms.services.DueSoonService;
import com.pinnaxis.sms.services.TrackCaseService;
import com.pinnaxis.sms.util.SMSConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.*;
import java.util.stream.Collectors;

@Controller
public class DueSoonController implements SMSConstant {

    private final static String DUE_SOON_DAY_ONE = PAST_DUE;
    private final static String DUE_SOON_DAY_TWO = "1 Day";
    private final static String DUE_SOON_DAY_THREE = "2 Days";
    private final static String DUE_SOON_DAY_GREATER_THAN_THREE = ">=3 Days";

    @Autowired
    private TrackCaseService trackCaseService;

    @Autowired
    private DueSoonService dueSoonService;

    @RequestMapping("/due-soon")
    public String dueSoon(){
        return "track-open-cases-on-due-soon";
    }

    @RequestMapping("/day1")
    public String getDayOneData(@RequestParam(value = "todayDate") String todayDateVal, Model model) {
        String filter = "<-3,-3,-2,-1,0";
        DueSoon dueSoon = new DueSoon(DUE_SOON_DAY_ONE.toUpperCase(), "ion-android-people", "bg-brown", "panel-brown", filter);
        trackCaseService.populateDueSoonData(dueSoon, filter, todayDateVal);
        model.addAttribute(dueSoon);
        return "dueSoonCases";
    }

    @RequestMapping("/day2")
    public String getDayTwoData(@RequestParam(value = "todayDate") String todayDateVal, Model model) {
        String filter = "1";
        DueSoon dueSoon = new DueSoon(DUE_SOON_DAY_TWO.toUpperCase(), "ion-android-checkbox", "bg-danger", "panel-danger", filter);
        trackCaseService.populateDueSoonData(dueSoon, filter, todayDateVal);
        model.addAttribute(dueSoon);
        return "dueSoonCases";
    }

    @RequestMapping("/day3")
    public String getDayThreeData(@RequestParam(value = "todayDate") String todayDateVal, Model model) {
        String filter = "2";
        DueSoon dueSoon = new DueSoon(DUE_SOON_DAY_THREE.toUpperCase(), "ion-eye", "bg-light-orange", "panel-orange", filter);
        trackCaseService.populateDueSoonData(dueSoon, filter, todayDateVal);
        model.addAttribute(dueSoon);
        return "dueSoonCases";
    }

    @RequestMapping("/dayGt3")
    public String getDayGtThreeData(@RequestParam(value = "todayDate") String todayDateVal, Model model) {
        String filter = "3,>3";
        DueSoon dueSoon = new DueSoon(DUE_SOON_DAY_GREATER_THAN_THREE.toUpperCase(), "ion-android-mail", "bg-primary", "panel-primary", filter);
        trackCaseService.populateDueSoonData(dueSoon, filter, todayDateVal);
        model.addAttribute(dueSoon);
        return "dueSoonCases";
    }

    @RequestMapping(value = "/getDueSoonCaseDetails", method = RequestMethod.GET)
    public ResponseEntity<?> getDueSoonCaseDetails(
            @RequestParam(value = "todayDate") String todayDate,
            @RequestParam(value = "type1") String type1,
            @RequestParam(value = "filter1") String filter1,
            @RequestParam(value = "type2", required = false, defaultValue = "") String type2,
            @RequestParam(value = "filter2", required = false, defaultValue = "") String filter2,
            @RequestParam(value = "type3", required = false, defaultValue = "") String type3,
            @RequestParam(value = "filter3", required = false, defaultValue = "") String filter3) {
        List<OpenCase> openCases = dueSoonService.getFilteredCaseList(todayDate, filter1, type2,
                 filter2, type3, filter3);
        return ResponseEntity.ok(openCases);
    }
}
