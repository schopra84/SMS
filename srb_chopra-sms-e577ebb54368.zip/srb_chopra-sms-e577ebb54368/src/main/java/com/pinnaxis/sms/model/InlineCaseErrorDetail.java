package com.pinnaxis.sms.model;

public class InlineCaseErrorDetail {
    private String caseNumber, currentWorkflowState, currentUser, errorType, errorDetail, responsibleWorkflow, responsibleUser;

    public InlineCaseErrorDetail(String caseNumber, String errorType, String errorDetail) {
        this.caseNumber = caseNumber;
        this.errorType = errorType;
        this.errorDetail = errorDetail;
    }

    public InlineCaseErrorDetail(String caseNumber, String currentWorkflowState, String currentUser, String errorType, String errorDetail, String responsibleWorkflow, String responsibleUser) {
        this.caseNumber = caseNumber;
        this.currentWorkflowState = currentWorkflowState;
        this.currentUser = currentUser;
        this.errorType = errorType;
        this.errorDetail = errorDetail;
        this.responsibleWorkflow = responsibleWorkflow;
        this.responsibleUser = responsibleUser;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public String getCurrentWorkflowState() {
        return currentWorkflowState;
    }

    public void setCurrentWorkflowState(String currentWorkflowState) {
        this.currentWorkflowState = currentWorkflowState;
    }

    public String getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(String currentUser) {
        this.currentUser = currentUser;
    }

    public String getErrorType() {
        return errorType;
    }

    public void setErrorType(String errorType) {
        this.errorType = errorType;
    }

    public String getErrorDetail() {
        return errorDetail;
    }

    public void setErrorDetail(String errorDetail) {
        this.errorDetail = errorDetail;
    }

    public String getResponsibleWorkflow() {
        return responsibleWorkflow;
    }

    public void setResponsibleWorkflow(String responsibleWorkflow) {
        this.responsibleWorkflow = responsibleWorkflow;
    }

    public String getResponsibleUser() {
        return responsibleUser;
    }

    public void setResponsibleUser(String responsibleUser) {
        this.responsibleUser = responsibleUser;
    }
}
