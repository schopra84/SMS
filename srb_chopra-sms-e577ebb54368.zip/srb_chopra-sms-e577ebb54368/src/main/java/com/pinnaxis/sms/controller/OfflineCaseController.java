package com.pinnaxis.sms.controller;

import com.pinnaxis.sms.model.*;
import com.pinnaxis.sms.services.InlineQualityCaseService;
import com.pinnaxis.sms.services.OfflineQualityCaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class OfflineCaseController {

    private final static String INLINE_DATA_ENTRY = "Data Entry";
    private final static String INLINE_QUALITY_REVIEW = "Quality Review";
    private final static String INLINE_MEDICAL_REVIEW = "Medical Review";
    private final static String INLINE_DISTRIBUTION = "Distribution";

    @Autowired
    private OfflineQualityCaseService service;

    @RequestMapping("/offline-case")
    public String inlineQualityCase() {
        return "offline-quality-case";
    }

    @RequestMapping(value = "/offline-quality-chart", method = RequestMethod.GET)
    public ResponseEntity caseAnalysisChart(@RequestParam(value = "dateFilter") String dateFilter) {
        LineChart chart = service.getMonthlyOfflineCaseCount(dateFilter);
        return ResponseEntity.ok(chart);
    }

    @RequestMapping(value = "/Offline-case-details", method = RequestMethod.GET)
    public ResponseEntity<?> getOfflineCaseDetails(@RequestParam(value = "monthRange") String monthRange) {
        List<InlineCaseDetail> inlineCaseDetails = service.getOfflineCaseDetails(monthRange);
        return ResponseEntity.ok(inlineCaseDetails);
    }

    @RequestMapping(value = "/monthly-Offline-case-details", method = RequestMethod.GET)
    public ResponseEntity<?> getMonthlyOfflineCaseDetails(@RequestParam(value = "monthYear") String monthYear,
                                                          @RequestParam(value = "category") String category) {
        List<InlineCaseDetail> inlineCaseDetails = service.getMonthlyOfflineCaseDetails(monthYear, category);
        return ResponseEntity.ok(inlineCaseDetails);
    }

    @RequestMapping(value = "/Offline-error-case-details", method = RequestMethod.GET)
    public ResponseEntity<?> getOfflineCaseErrorDetails(@RequestParam(value = "caseNumber") String caseNumber,
                                                        @RequestParam(value = "dateRange") String monthRange) {
        List<InlineCaseErrorDetail> inlineCaseErrorDetail = service.getOfflineCaseErrorDetails(
                caseNumber, monthRange);
        return ResponseEntity.ok(inlineCaseErrorDetail);
    }

    @RequestMapping(value = "/monthly-Offline-error-case-details", method = RequestMethod.GET)
    public ResponseEntity<?> getMonthlyOfflineCaseErrorDetails(@RequestParam(value = "caseNumber") String caseNumber,
                                                               @RequestParam(value = "dateRange") String monthYear,
                                                               @RequestParam(value = "category") String category) {
        List<InlineCaseErrorDetail> inlineCaseErrorDetail = service.getMonthlyOfflineCaseErrorDetails(
                caseNumber, monthYear, category);
        return ResponseEntity.ok(inlineCaseErrorDetail);
    }
}
