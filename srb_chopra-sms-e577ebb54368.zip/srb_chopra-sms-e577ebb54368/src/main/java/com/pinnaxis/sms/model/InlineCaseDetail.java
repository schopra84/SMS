package com.pinnaxis.sms.model;

public class InlineCaseDetail {
    private String workflowState, caseNumber, awareDate, reportType, countryOfIncidence, studyId, primaryProductName;

    private long criticalErrors,
            highSeverityErrors, mediumSeverityErrors, lowSeverityErrors;


    public InlineCaseDetail(String workflowState, String caseNumber, String awareDate,
                            String reportType, String countryOfIncidence, String studyId, String primaryProductName,
                            long criticalErrors, long highSeverityErrors, long mediumSeverityErrors, long lowSeverityErrors) {
        this.workflowState = workflowState;
        this.caseNumber = caseNumber;
        this.awareDate = awareDate;
        this.reportType = reportType;
        this.countryOfIncidence = countryOfIncidence;
        this.studyId = studyId;
        this.primaryProductName = primaryProductName;
        this.criticalErrors = criticalErrors;
        this.highSeverityErrors = highSeverityErrors;
        this.mediumSeverityErrors = mediumSeverityErrors;
        this.lowSeverityErrors = lowSeverityErrors;
    }

    public String getWorkflowState() {
        return workflowState;
    }

    public void setWorkflowState(String workflowState) {
        this.workflowState = workflowState;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public long getCriticalErrors() {
        return criticalErrors;
    }

    public void setCriticalErrors(long criticalErrors) {
        this.criticalErrors = criticalErrors;
    }

    public long getHighSeverityErrors() {
        return highSeverityErrors;
    }

    public void setHighSeverityErrors(long highSeverityErrors) {
        this.highSeverityErrors = highSeverityErrors;
    }

    public long getMediumSeverityErrors() {
        return mediumSeverityErrors;
    }

    public void setMediumSeverityErrors(long mediumSeverityErrors) {
        this.mediumSeverityErrors = mediumSeverityErrors;
    }

    public long getLowSeverityErrors() {
        return lowSeverityErrors;
    }

    public void setLowSeverityErrors(long lowSeverityErrors) {
        this.lowSeverityErrors = lowSeverityErrors;
    }

    public String getAwareDate() {
        return awareDate;
    }

    public void setAwareDate(String awareDate) {
        this.awareDate = awareDate;
    }

    public String getReportType() {
        return reportType;
    }

    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    public String getCountryOfIncidence() {
        return countryOfIncidence;
    }

    public void setCountryOfIncidence(String countryOfIncidence) {
        this.countryOfIncidence = countryOfIncidence;
    }

    public String getStudyId() {
        return studyId;
    }

    public void setStudyId(String studyId) {
        this.studyId = studyId;
    }

    public String getPrimaryProductName() {
        return primaryProductName;
    }

    public void setPrimaryProductName(String primaryProductName) {
        this.primaryProductName = primaryProductName;
    }
}
