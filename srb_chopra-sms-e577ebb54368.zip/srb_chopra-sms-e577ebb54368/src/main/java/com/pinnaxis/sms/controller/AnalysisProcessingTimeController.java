package com.pinnaxis.sms.controller;

import com.pinnaxis.sms.model.ClosedCaseAnalysis;
import com.pinnaxis.sms.model.LineChart;
import com.pinnaxis.sms.services.AnalysisProcessingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class AnalysisProcessingTimeController {

    @Autowired
    private AnalysisProcessingService service;

    @RequestMapping("/analysis-processing-time")
    public String analysisCases() {
        return "analysis-processing-time";
    }

    @RequestMapping(value = "/analysis-processing-time-chart", method = RequestMethod.GET)
    public ResponseEntity analysisProcessingTimeChart(@RequestParam(value = "caseType") String caseType,
                                                      @RequestParam(value = "monthYear") String monthYear) {
        LineChart chart = service.getMonthlyProcessingCaseCount(caseType, monthYear);

        return ResponseEntity.ok(chart);
    }

    @RequestMapping(value = "/analysis-processing-time-details", method = RequestMethod.GET)
    public ResponseEntity analysisProcessingTimeDetails(@RequestParam(value = "monthRange") String monthRange,
                                                 @RequestParam(value = "caseType") String caseType) {
        List<ClosedCaseAnalysis> closedCaseAnalysis = service.getCaseList(monthRange, caseType);
        return ResponseEntity.ok(closedCaseAnalysis);
    }

    @RequestMapping(value = "/monthly-analysis-processing-time-details", method = RequestMethod.GET)
    public ResponseEntity monthlyAnalysisProcessingTimeDetails(@RequestParam(value = "monthYear") String monthYear,
                                                 @RequestParam(value = "caseType") String caseType) {
        List<ClosedCaseAnalysis> closedCaseAnalysis = service.getMonthlyCaseList(monthYear, caseType);
        return ResponseEntity.ok(closedCaseAnalysis);
    }

    @RequestMapping(value = "/calculate-average-cases", method = RequestMethod.GET)
    public ResponseEntity calculateAverageCases(@RequestParam(value = "caseType") String caseType,
                                                @RequestParam(value = "monthYear") String monthYear) {
        long averageCases = service.calculateAverageCases(caseType, monthYear);
        return ResponseEntity.ok(averageCases);
    }

}
