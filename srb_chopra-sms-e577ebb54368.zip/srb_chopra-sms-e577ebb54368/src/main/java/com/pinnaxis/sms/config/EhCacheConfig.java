package com.pinnaxis.sms.config;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

@Configuration
@EnableCaching
@EnableConfigurationProperties
public class EhCacheConfig extends CachingConfigurerSupport {

    private static final Logger log = LoggerFactory.getLogger(EhCacheConfig.class);

    @Bean
    public CacheManager cacheManager() {
        return new EhCacheCacheManager(this.ehCacheManagerWrapper().getObject());
    }

    @Bean
    public EhCacheManagerWrapper ehCacheManagerWrapper() {
        EhCacheManagerWrapper ehCacheManagerWrapper = new EhCacheManagerWrapper();
        ehCacheManagerWrapper.setConfigString(getAllEhConfigsString());
        ehCacheManagerWrapper.setShared(true);
        return ehCacheManagerWrapper;
    }

    private static String getAllEhConfigsString() {
        PathMatchingResourcePatternResolver path = new PathMatchingResourcePatternResolver();
        StringBuilder builder = new StringBuilder();
        try{
            Resource[] resources = path.getResources("classpath*:ehcache.xml");
            for (Resource res: resources) {
                builder.append(convertStreamToString(res.getInputStream()));
            }
        } catch (IOException e) {
            log.error("Error in reading configs of EhCache", e.getMessage());
        }
        return getEhCacheConfigString(builder.toString());
    }

    private static String convertStreamToString(InputStream inputStream) throws IOException {
        String strFileContents = IOUtils.toString(inputStream, StandardCharsets.UTF_8.name());
        return strFileContents.substring(strFileContents.indexOf("<cache name"), strFileContents.lastIndexOf("</cache>") + 8);
    }


    private static String getEhCacheConfigString(String input) {
        String startVal = "<ehcache xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"ehcache.xsd\" updateCheck=\"true\" monitoring=\"autodetect\" dynamicConfig=\"true\">" +
                "<defaultCache maxEntriesLocalHeap=\"10000\" eternal=\"false\" timeToIdleSeconds=\"120\" timeToLiveSeconds=\"120\" memoryStoreEvictionPolicy=\"LRU\">" +
                "<persistence strategy=\"none\"/>" +
                "</defaultCache>";
        String endVal="</ehcache>";
        return startVal + input + endVal;
    }
}
