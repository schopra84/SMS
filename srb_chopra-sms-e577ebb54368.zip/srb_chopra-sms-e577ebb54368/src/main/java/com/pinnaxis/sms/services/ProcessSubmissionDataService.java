package com.pinnaxis.sms.services;

import com.pinnaxis.sms.model.OpenCase;
import com.pinnaxis.sms.model.PendingSubmissionCase;
import com.pinnaxis.sms.model.SubmissionData;
import com.pinnaxis.sms.util.CommonUtil;
import com.pinnaxis.sms.util.SMSConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Service
public class ProcessSubmissionDataService implements SMSConstant {

    @Autowired
    private DTOService dtoService;

    public long reportScheduled() {
        return getPendingSubmissionCount(d -> d.getReportsScheduled() == NOT_GENERATED);
    }

    public long generationStatus() {
        return getPendingSubmissionCount(d -> d.getReportsScheduled() == NOT_GENERATED);
    }

    public long submissionStatus() {
        return getPendingSubmissionCount(d -> d.getReportsScheduled() == NOT_TRANSMITTED);
    }

    public long transmittedStatus() {
        return getPendingSubmissionCount(d -> (d.getReportsScheduled() == ACK_PENDING
                && Objects.isNull(d.getSubmissionDate())));
    }

    private long getPendingSubmissionCount(Predicate<SubmissionData> condition) {
        List<SubmissionData> submissionData = dtoService.loadSubmissionData();
        return submissionData.stream().filter(condition).count();
    }

    public List<PendingSubmissionCase> getSubmissionCaseDetails(String filter, String todayDateVal) {
        List<SubmissionData> submissionData = dtoService.loadSubmissionData();
        List<SubmissionData> caseDetails;
        switch (filter) {
            case "reportScheduled":
                caseDetails = submissionData.stream().filter(d -> d.getReportsScheduled() == NOT_GENERATED)
                        .collect(Collectors.toList());
                break;
            case "generationStatus":
                caseDetails = submissionData.stream().filter(d -> d.getReportsScheduled() == NOT_GENERATED)
                        .collect(Collectors.toList());
                break;
            case "submissionStatus":
                caseDetails = submissionData.stream().filter(d -> d.getReportsScheduled() == NOT_TRANSMITTED)
                        .collect(Collectors.toList());
                break;
            case "transmittedStatus":
                caseDetails = submissionData.stream().filter(d -> (d.getReportsScheduled() == ACK_PENDING))
                        .collect(Collectors.toList());
                break;
            default:
                caseDetails = null;
                break;
        }
        LocalDate todayDate = CommonUtil.convertStringToDate(todayDateVal, CommonUtil.dateTimeFormatter4);
        List<OpenCase> openCase= dtoService.loadOpenCases(todayDate);
        List<PendingSubmissionCase> filteredCases = Collections.EMPTY_LIST;
        if (Objects.nonNull(caseDetails)) {
            Map<String, List<OpenCase>> openCasesMap = groupOpenCasesByCaseNumber(openCase);
            filteredCases = caseDetails.stream()
                    .map(c -> {
                            OpenCase o = openCasesMap.get(c.getCaseNumber()).get(0);
                            String reportType = null;
                            if(Objects.nonNull(openCase)){
                                reportType = o.getReportType();
                            }
                            PendingSubmissionCase pendingSubmissionCase;
                            switch (filter) {
                                case "reportScheduled":
                                    if(Objects.nonNull(openCase)){
                                        pendingSubmissionCase = new PendingSubmissionCase(c.getCaseNumber(), o.getReceiptDateVal(), reportType,
                                                c.getLockedDateVal(), o.getProductName(), o.getCountry(), o.getUserName(), o.getCaseSeriousness());
                                    } else {
                                        pendingSubmissionCase = new PendingSubmissionCase(c.getCaseNumber(), reportType, c.getLockedDateVal());
                                    }
                                    break;
                                case "generationStatus":
                                    pendingSubmissionCase = new PendingSubmissionCase(c.getCaseNumber(), reportType, c.getLockedDateVal(),
                                            c.getAgencyName(), c.getReportForm(), c.getSubmissionDateVal(),
                                            c.getReportsScheduled()==NOT_GENERATED ? PENDING : BLANK, c.getGenerationError(), null);
                                    break;
                                case "submissionStatus":
                                    pendingSubmissionCase = new PendingSubmissionCase(c.getCaseNumber(), reportType, c.getLockedDateVal(),
                                            c.getAgencyName(), c.getReportForm(), c.getSubmissionDateVal(),
                                            c.getReportsScheduled()==NOT_GENERATED ? PENDING : BLANK, c.getGenerationError(),
                                            c.getReportsScheduled()==NOT_TRANSMITTED ? PENDING : BLANK, c.getSubmissionError());
                                    break;
                                case "transmittedStatus":
                                    pendingSubmissionCase = new PendingSubmissionCase(c.getCaseNumber(), reportType, c.getLockedDateVal(),
                                            c.getAgencyName(), c.getReportForm(), c.getSubmissionDateVal(),
                                            c.getReportsScheduled()==NOT_GENERATED ? PENDING : BLANK, c.getGenerationError(),
                                            c.getReportsScheduled()==NOT_TRANSMITTED ? PENDING : BLANK, c.getSubmissionError());
                                    break;
                                default:
                                    pendingSubmissionCase = null;
                                    break;
                            }
                            return pendingSubmissionCase;
                    }).collect(Collectors.toList());
        }
        return filteredCases;
    }

    private Map<String, List<OpenCase>> groupOpenCasesByCaseNumber(List<OpenCase> openCases) {
        return openCases.stream()
                .collect(Collectors.groupingBy(OpenCase::getCaseNumber));
    }
}
