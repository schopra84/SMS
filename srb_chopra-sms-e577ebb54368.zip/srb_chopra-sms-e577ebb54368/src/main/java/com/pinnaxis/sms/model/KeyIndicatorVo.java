package com.pinnaxis.sms.model;

public class KeyIndicatorVo {
    private String title;
    private long count;
    private String panelColor;
    private String filterKey;

    public KeyIndicatorVo(String title, long count, String panelColor, String filterKey) {
        this.title = title;
        this.count = count;
        this.panelColor = panelColor;
        this.filterKey = filterKey;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public long getCount() {
        return count;
    }

    public void setCount(long count) {
        this.count = count;
    }

    public String getPanelColor() {
        return panelColor;
    }

    public void setPanelColor(String panelColor) {
        this.panelColor = panelColor;
    }

    public String getFilterKey() {
        return filterKey;
    }

    public void setFilterKey(String filterKey) {
        this.filterKey = filterKey;
    }
}
