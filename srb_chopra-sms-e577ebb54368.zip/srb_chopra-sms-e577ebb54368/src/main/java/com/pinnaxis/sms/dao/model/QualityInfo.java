package com.pinnaxis.sms.dao.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name = "V_SMS_QUALITY")
public class QualityInfo extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Column(name = "ERROR_WORKFLOW") private String errorWorkflow;
    @Column(name = "ERROR_SEVERITY") private String errorSeverity;
    @Column(name = "RESPONSIBLE_USER") private String responsibleUser;
    @Column(name = "EVENT_VERBATIM") private String eventVerbatim;
    @Column(name = "SUSAR") private String susar;
    @Column(name = "WORKFLOW_CATEGORY") private String workflowCategory;
    @Column(name = "SIG_RECEIPT_DATE") private LocalDate sigReceiptDate;
    @Column(name = "ERROR_ID") private Long errorId;
    @Column(name = "ERROR_MESSAGE") private String errorMessage;

    public String getErrorWorkflow() {
        return errorWorkflow;
    }

    public void setErrorWorkflow(String errorWorkflow) {
        this.errorWorkflow = errorWorkflow;
    }

    public String getErrorSeverity() {
        return errorSeverity;
    }

    public void setErrorSeverity(String errorSeverity) {
        this.errorSeverity = errorSeverity;
    }

    public String getResponsibleUser() {
        return responsibleUser;
    }

    public void setResponsibleUser(String responsibleUser) {
        this.responsibleUser = responsibleUser;
    }

    public String getEventVerbatim() {
        return eventVerbatim;
    }

    public void setEventVerbatim(String eventVerbatim) {
        this.eventVerbatim = eventVerbatim;
    }

    public String getSusar() {
        return susar;
    }

    public void setSusar(String susar) {
        this.susar = susar;
    }

    public String getWorkflowCategory() {
        return workflowCategory;
    }

    public void setWorkflowCategory(String workflowCategory) {
        this.workflowCategory = workflowCategory;
    }

    public LocalDate getSigReceiptDate() {
        return sigReceiptDate;
    }

    public void setSigReceiptDate(LocalDate sigReceiptDate) {
        this.sigReceiptDate = sigReceiptDate;
    }

    public Long getErrorId() {
        return errorId;
    }

    public void setErrorId(Long errorId) {
        this.errorId = errorId;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
