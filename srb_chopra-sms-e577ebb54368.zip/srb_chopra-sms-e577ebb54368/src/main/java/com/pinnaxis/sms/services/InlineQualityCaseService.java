package com.pinnaxis.sms.services;

import com.pinnaxis.sms.model.*;
import com.pinnaxis.sms.util.CommonUtil;
import com.pinnaxis.sms.util.SMSConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class InlineQualityCaseService implements SMSConstant {

//    private List<Integer> errorIds;
//    private List<Integer> criticalError;
//    private List<Integer> highError;
//    private List<Integer> mediumError;
//    private List<Integer> lowError;

    private static final int INLINE_TYPE = 0;

    @Autowired
    private DTOService dtoService;

//    private List<CaseDataQuality> caseDataQuality;
//
//    private List<CaseDataQualityError> caseDataQualityError;


//    @PostConstruct
//    public void init() {
//        caseDataQualityError = null;
//        errorIds = caseDataQualityError.parallelStream()
//                .map(e -> e.getErrorId()).collect(Collectors.toList());
//        criticalError = caseDataQualityError.parallelStream().filter(e -> e.getErrorSeverity().equalsIgnoreCase("Critical"))
//                .map(e -> e.getErrorId()).collect(Collectors.toList());
//        highError = caseDataQualityError.parallelStream().filter(e -> e.getErrorSeverity().equalsIgnoreCase("High"))
//                .map(e -> e.getErrorId()).collect(Collectors.toList());
//        mediumError = caseDataQualityError.parallelStream().filter(e -> e.getErrorSeverity().equalsIgnoreCase("Medium"))
//                .map(e -> e.getErrorId()).collect(Collectors.toList());
//        lowError = caseDataQualityError.parallelStream().filter(e -> e.getErrorSeverity().equalsIgnoreCase("Low"))
//                .map(e -> e.getErrorId()).collect(Collectors.toList());
//    }

//    String CRITICAL = "Critical";
//    String HIGH = "High";
//    String MEDIUM = "Medium";
//    String LOW = "Low";

    public void populateInlineDetails(InlineQualityCase inlineQualityCase, String workflowSate, String startDateVal, String endDateVal) {
        List<CaseDataQuality> caseDataList = dtoService.loadCaseDataQuality();

        LocalDate startDate = CommonUtil.convertStringToDate(startDateVal, CommonUtil.dateTimeFormatter1);
        LocalDate endDate = CommonUtil.convertStringToEndDate(endDateVal, CommonUtil.dateTimeFormatter1);
        Supplier<Stream<CaseDataQuality>> caseDataQualitySupplier = () ->
             caseDataList.parallelStream()
                    .filter(c -> c.getClosed() == INLINE_TYPE && c.getWorkflowState().equalsIgnoreCase(workflowSate) &&
                            (c.getAwareDate().equals(startDate) || c.getAwareDate().isAfter(startDate)) &&
                            (c.getAwareDate().equals(endDate) || c.getAwareDate().isBefore(endDate)));
        

        long totalCases = caseDataQualitySupplier.get().collect(Collectors.counting());

        long criticalErrors = caseDataQualitySupplier.get()
                .filter(c -> c.getErrorSeverity().equalsIgnoreCase(CRITICAL)).collect(Collectors.counting());
        long highErrors = caseDataQualitySupplier.get()
                .filter(c -> c.getErrorSeverity().equalsIgnoreCase(HIGH)).collect(Collectors.counting());
        long mediumErrors = caseDataQualitySupplier.get()
                .filter(c -> c.getErrorSeverity().equalsIgnoreCase(MEDIUM)).collect(Collectors.counting());
        long lowErrors = caseDataQualitySupplier.get()
                .filter(c -> c.getErrorSeverity().equalsIgnoreCase(LOW)).collect(Collectors.counting());
        long noErrors = 0;

        inlineQualityCase.setCriticalErrors(criticalErrors);
        inlineQualityCase.setHighErrors(highErrors);
        inlineQualityCase.setMediumErrors(mediumErrors);
        inlineQualityCase.setLowErrors(lowErrors);
        inlineQualityCase.setNoErrors(noErrors);
        inlineQualityCase.setTotalCases(totalCases);
    }

    public List<InlineCaseDetail> getInlineCaseDetails(final String workflowSate, String startDateVal,
                                                       String endDateVal, String errorType) {
        List<InlineCaseDetail> inlineCaseDetails = new ArrayList<>();
        List<CaseDataQuality> caseDataList = dtoService.loadCaseDataQuality();

        LocalDate startDate = CommonUtil.convertStringToDate(startDateVal, CommonUtil.dateTimeFormatter1);
        LocalDate endDate = CommonUtil.convertStringToEndDate(endDateVal, CommonUtil.dateTimeFormatter1);
        Map<String, List<CaseDataQuality>> caseDataQualityMap = caseDataList.parallelStream()
                .filter(c-> {
                    boolean filter;
                    if(workflowSate.equalsIgnoreCase("all")) {
                        filter = true;
                    } else {
                        filter = c.getWorkflowState().equalsIgnoreCase(workflowSate);
                    }
                    return filter;
                })
                .filter(c -> c.getClosed() == INLINE_TYPE &&
                        (c.getAwareDate().equals(startDate) || c.getAwareDate().isAfter(startDate)) &&
                        (c.getAwareDate().equals(endDate) || c.getAwareDate().isBefore(endDate)))
                .collect(Collectors.groupingBy(CaseDataQuality::getCaseNumber));


        caseDataQualityMap.entrySet().stream().forEach(e -> {
            String caseNumber = e.getKey();
            Map<String, List<CaseDataQuality>> casesDataMap = e.getValue().stream().collect(Collectors.groupingBy(CaseDataQuality::getWorkflowState));
            casesDataMap.entrySet().stream().forEach(cd -> {
                List<CaseDataQuality> casesData = cd.getValue();
                CaseDataQuality caseData = casesData.get(0);
                long criticalErrors = 0;
                if(errorType.equalsIgnoreCase("all") || errorType.equalsIgnoreCase("critical")){
                    criticalErrors = casesData.stream()
                            .filter(c -> c.getErrorSeverity().equalsIgnoreCase(CRITICAL)).collect(Collectors.counting());
                }
                long highErrors = 0;
                if(errorType.equalsIgnoreCase("all") || errorType.equalsIgnoreCase("high")) {
                    highErrors = casesData.stream()
                            .filter(c -> c.getErrorSeverity().equalsIgnoreCase(HIGH)).collect(Collectors.counting());
                }
                long mediumErrors = 0;
                if(errorType.equalsIgnoreCase("all") || errorType.equalsIgnoreCase("medium")) {
                    mediumErrors = casesData.stream()
                            .filter(c -> c.getErrorSeverity().equalsIgnoreCase(MEDIUM)).collect(Collectors.counting());
                }
                long lowErrors = 0;
                if(errorType.equalsIgnoreCase("all") || errorType.equalsIgnoreCase("low")) {
                    lowErrors = casesData.stream()
                            .filter(c -> c.getErrorSeverity().equalsIgnoreCase(LOW)).collect(Collectors.counting());
                }
                inlineCaseDetails.add(new InlineCaseDetail(caseData.getWorkflowState(), caseNumber, caseData.getAwareDateVal(),
                        caseData.getReportType(), caseData.getCountryOfIncidence(), caseData.getStudyId(), caseData.getPrimaryProductName(),
                        criticalErrors, highErrors, mediumErrors, lowErrors));
            });
        });

        return inlineCaseDetails;
    }

    public List<InlineCaseErrorDetail> getInlineCaseErrorDetails(final String caseNumber, String startDateVal, String endDateVal, String errorType) {
        List<InlineCaseErrorDetail> inlineCaseErrorDetails = new ArrayList<>();
        List<CaseDataQuality> caseDataList = dtoService.loadCaseDataQuality();

        LocalDate startDate = CommonUtil.convertStringToDate(startDateVal, CommonUtil.dateTimeFormatter1);
        LocalDate endDate = CommonUtil.convertStringToEndDate(endDateVal, CommonUtil.dateTimeFormatter1);
        List<CaseDataQuality> filterCaseDataQuality = caseDataList.parallelStream()
                .filter(c-> {
                    boolean filter;
                    if(caseNumber.equalsIgnoreCase("all")) {
                        filter = true;
                    } else {
                        filter = c.getCaseNumber().equalsIgnoreCase(caseNumber);
                    }
                    return filter;
                })
                .filter(c -> c.getClosed() == INLINE_TYPE &&
                        (c.getAwareDate().equals(startDate) || c.getAwareDate().isAfter(startDate)) &&
                        (c.getAwareDate().equals(endDate) || c.getAwareDate().isBefore(endDate)))
                .filter(c -> {
                            boolean filter = false;
                            if(errorType.equalsIgnoreCase("all")) {
                                filter = true;
                            } else {
                                filter = c.getErrorSeverity().equalsIgnoreCase(errorType);
                            }
                            return filter;
                        }).collect(Collectors.toList());

        filterCaseDataQuality.stream()
                .forEach(e -> inlineCaseErrorDetails.add(
                                new InlineCaseErrorDetail(e.getCaseNumber(), e.getWorkflowState(),
                                        e.getResponsibleUser(), e.getErrorSeverity(),
                                        e.getErrorMessage(),
                                        e.getErrorWorkflow(), e.getResponsibleUser())));

        return inlineCaseErrorDetails;
    }
}
