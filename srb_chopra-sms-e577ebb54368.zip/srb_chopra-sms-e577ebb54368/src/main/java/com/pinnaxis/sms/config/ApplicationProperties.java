package com.pinnaxis.sms.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Component
@EnableConfigurationProperties
@ConfigurationProperties("sms")
public class ApplicationProperties {

    private String refreshSuccessMessage;
    private String refreshErrorMessage;
    private boolean enableRefreshPopup;
    private List<KeyIndicator> keyIndicators;
    private List<String> reportType;
    private HashMap<String, Integer> maxCaseProcessing;


    public String getRefreshSuccessMessage() {
        return refreshSuccessMessage;
    }

    public void setRefreshSuccessMessage(String refreshSuccessMessage) {
        this.refreshSuccessMessage = refreshSuccessMessage;
    }

    public String getRefreshErrorMessage() {
        return refreshErrorMessage;
    }

    public void setRefreshErrorMessage(String refreshErrorMessage) {
        this.refreshErrorMessage = refreshErrorMessage;
    }

    public boolean isEnableRefreshPopup() {
        return enableRefreshPopup;
    }

    public void setEnableRefreshPopup(boolean enableRefreshPopup) {
        this.enableRefreshPopup = enableRefreshPopup;
    }

    public List<KeyIndicator> getKeyIndicators() {
        return keyIndicators;
    }

    public void setKeyIndicators(List<KeyIndicator> keyIndicators) {
        this.keyIndicators = keyIndicators;
    }

    public List<String> getReportType() {
        return reportType;
    }

    public void setReportType(List<String> reportType) {
        this.reportType = reportType;
    }

    public HashMap<String, Integer> getMaxCaseProcessing() {
        return maxCaseProcessing;
    }

    public void setMaxCaseProcessing(HashMap<String, Integer> maxCaseProcessing) {
        this.maxCaseProcessing = maxCaseProcessing;
    }
}
