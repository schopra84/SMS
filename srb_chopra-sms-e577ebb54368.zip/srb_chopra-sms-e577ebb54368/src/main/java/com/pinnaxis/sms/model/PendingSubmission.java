package com.pinnaxis.sms.model;

public class PendingSubmission {
    private String title;
    private String subTitle;
    private long totalCases;
    private String filter;

    public PendingSubmission(String title, String subTitle, long totalCases, String filter) {
        this.title = title;
        this.subTitle = subTitle;
        this.totalCases = totalCases;
        this.filter = filter;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubTitle() {
        return subTitle;
    }

    public void setSubTitle(String subTitle) {
        this.subTitle = subTitle;
    }

    public long getTotalCases() {
        return totalCases;
    }

    public void setTotalCases(long totalCases) {
        this.totalCases = totalCases;
    }

    public String getFilter() {
        return filter;
    }

    public void setFilter(String filter) {
        this.filter = filter;
    }
}
