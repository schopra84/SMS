package com.pinnaxis.sms.util;

import org.springframework.cache.annotation.CacheEvict;

public interface SMSConstant {
    String PENDING = "Pending";
    String PROBABILITY_HIGH = "High";
    String PROBABILITY_LOW = "Low";
    String CASES_RECEIVED = "Cases Received";
    String CASES_CLOSED = "Cases Closed";
    String CASES_DELETED = "Cases Deleted";
    String SERIOUS = "serious";
    String NON_SERIOUS = "nonSerious";
    String BLANK = "";

    String MARKETED = "Marketed";
    String INVESTIGATIONAL = "Investigational";
    String SUSAR = "susar";

    String DATA_ENTRY = "Data Entry";
    String QUALITY_REVIEW = "Quality Review";
    String MEDICAL_REVIEW = "Medical Review";
    String DISTRIBUTION = "Distribution";

    String CRITICAL = "Critical";
    String HIGH = "High";
    String MEDIUM = "Medium";
    String LOW = "Low";

    String VIEW_CASE_DETAILS = "caseDetails";
    String VIEW_PENDING_SUBMISSIONS = "pendingSubmissions";
    String VIEW_QUALITY = "quality";
    String VIEW_RECEIVED_CASES = "receivedCases";
    String VIEW_WORKLOAD = "workload";
    String USER_TABLE = "user";

    long NOT_GENERATED = 2L;
    long NOT_TRANSMITTED = 3L;
    long ACK_PENDING = 4L;

    String PAST_DUE = "Past Due";
    String TODAY_DUE = "Today";

    String RECEIVED_TODAY = "received_today";
    String PROCESSED_TODAY = "processed_today";
    String ACTIVE_CASES = "active_cases";
    String SUBMISSION_TODAY = "submission_today";
    String FAILED_SUBMISSION = "failed_submission";
    String DUE_TODAY = "due_today";

    String BG_GREEN = "bg-green";
    String BG_RED = "bg-red";

}
