package com.pinnaxis.sms.dao.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name = "V_SMS_RECEIVED_CASES")
public class ReceivedCasesInfo extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Column(name = "EVENT_VERBATIM") private String eventVerbatim;
    @Column(name = "SUSAR") private String susar;
    @Column(name = "WORKFLOW_CATEGORY") private String workflowCategory;
    @Column(name = "SIG_RECEIPT_DATE") private LocalDate sigReceiptDate;
    @Column(name = "RECEIPT_DATE") private LocalDate receiptDate;
    @Column(name = "ROUTE_DATE") private LocalDate routeDate;
    @Column(name = "FOLLOUP_TYPE") private String folloupType;
    @Column(name = "PROCESSING_TIME") private Long processingTime;
    @Column(name = "CASE_TYPE") private String caseType;


    public String getEventVerbatim() {
        return eventVerbatim;
    }

    public void setEventVerbatim(String eventVerbatim) {
        this.eventVerbatim = eventVerbatim;
    }

    public String getSusar() {
        return susar;
    }

    public void setSusar(String susar) {
        this.susar = susar;
    }

    public String getWorkflowCategory() {
        return workflowCategory;
    }

    public void setWorkflowCategory(String workflowCategory) {
        this.workflowCategory = workflowCategory;
    }

    public LocalDate getSigReceiptDate() {
        return sigReceiptDate;
    }

    public void setSigReceiptDate(LocalDate sigReceiptDate) {
        this.sigReceiptDate = sigReceiptDate;
    }

    public LocalDate getReceiptDate() {
        return receiptDate;
    }

    public void setReceiptDate(LocalDate receiptDate) {
        this.receiptDate = receiptDate;
    }

    public LocalDate getRouteDate() {
        return routeDate;
    }

    public void setRouteDate(LocalDate routeDate) {
        this.routeDate = routeDate;
    }

    public String getFolloupType() {
        return folloupType;
    }

    public void setFolloupType(String folloupType) {
        this.folloupType = folloupType;
    }

    public Long getProcessingTime() {
        return processingTime;
    }

    public void setProcessingTime(Long processingTime) {
        this.processingTime = processingTime;
    }

    public String getCaseType() {
        return caseType;
    }

    public void setCaseType(String caseType) {
        this.caseType = caseType;
    }
}
