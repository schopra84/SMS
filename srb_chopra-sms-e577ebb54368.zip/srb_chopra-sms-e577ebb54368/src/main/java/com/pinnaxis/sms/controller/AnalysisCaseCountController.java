package com.pinnaxis.sms.controller;

import com.pinnaxis.sms.model.ClosedCaseAnalysis;
import com.pinnaxis.sms.model.LineChart;
import com.pinnaxis.sms.services.CaseAnalysisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
public class AnalysisCaseCountController {

    @Autowired
    private CaseAnalysisService service;

    @RequestMapping("/analysis-cases")
    public String analysisCases() {
        return "analysis-cases";
    }

    @RequestMapping(value = "/case-analysis-chart", method = RequestMethod.GET)
    public ResponseEntity caseAnalysisChart(@RequestParam(value = "filter") String filter,
                                            @RequestParam(value = "dateFilter") String dateFilter) {
        LineChart chart = service.getMonthlyClosedCaseCount(filter, dateFilter);

        return ResponseEntity.ok(chart);
    }

    @RequestMapping(value = "/analysis-case-details", method = RequestMethod.GET)
    public ResponseEntity getAnalysisCaseDetails(@RequestParam(value = "caseType") String caseType,
                                                 @RequestParam(value = "monthRange") String monthRange,
                                                 @RequestParam(value = "category") String category) {
        List<ClosedCaseAnalysis> closedCaseAnalysis = service.getCaseList(caseType,
                monthRange, category);
        return ResponseEntity.ok(closedCaseAnalysis);
    }

    @RequestMapping(value = "/monthly-analysis-case-details", method = RequestMethod.GET)
    public ResponseEntity monthlyAnalysisCaseDetails(@RequestParam(value = "caseType") String caseType,
                                                 @RequestParam(value = "monthYear") String monthYear,
                                                 @RequestParam(value = "category") String category) {
        List<ClosedCaseAnalysis> closedCaseAnalysis = service.getMonthlyCaseList(caseType,
                monthYear, category);
        return ResponseEntity.ok(closedCaseAnalysis);
    }
}
