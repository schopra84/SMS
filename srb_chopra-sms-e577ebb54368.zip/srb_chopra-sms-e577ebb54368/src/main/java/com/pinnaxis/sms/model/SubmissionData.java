package com.pinnaxis.sms.model;

import com.pinnaxis.sms.util.CommonUtil;

import java.time.LocalDate;
import java.util.Objects;

public class SubmissionData {
    private String caseNumber, reportForm, agencyName, lockedDateVal,
            reportScheduledDateVal, submissionDateVal, generationError,
            submissionError;

    private LocalDate submissionDate, lockedDate, reportScheduledDate;

    private long reportsScheduled;

    public SubmissionData(String caseNumber, String reportForm, String agencyName, LocalDate lockedDate, long reportsScheduled,
                          LocalDate reportScheduledDate, LocalDate submissionDate,
                          String generationError, String submissionError) {
        this.caseNumber = caseNumber;
        this.reportForm = reportForm;
        this.lockedDate = lockedDate;
        this.agencyName = agencyName;
        this.reportsScheduled = reportsScheduled;
        this.reportScheduledDate = reportScheduledDate;
        this.submissionDate = submissionDate;
        this.generationError = generationError;
        this.submissionError = submissionError;

        if(Objects.nonNull(submissionDate)) {
            this.submissionDateVal = CommonUtil.dateTimeFormatter1.format(submissionDate);
        }

        if(Objects.nonNull(lockedDate)) {
            this.lockedDateVal = CommonUtil.dateTimeFormatter1.format(lockedDate);
        }
        if(Objects.nonNull(reportScheduledDate)) {
            this.reportScheduledDateVal = CommonUtil.dateTimeFormatter1.format(reportScheduledDate);
        }
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public String getReportForm() {
        return reportForm;
    }

    public void setReportForm(String reportForm) {
        this.reportForm = reportForm;
    }

    public String getAgencyName() {
        return agencyName;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }

    public String getGenerationError() {
        return generationError;
    }

    public void setGenerationError(String generationError) {
        this.generationError = generationError;
    }

    public String getSubmissionError() {
        return submissionError;
    }

    public void setSubmissionError(String submissionError) {
        this.submissionError = submissionError;
    }

    public String getSubmissionDateVal() {
        return submissionDateVal;
    }

    public void setSubmissionDateVal(String submissionDateVal) {
        this.submissionDateVal = submissionDateVal;
    }

    public void setSubmissionDate(LocalDate submissionDate) {
        this.submissionDate = submissionDate;
    }

    public LocalDate getSubmissionDate() {
        return submissionDate;
    }

    public String getLockedDateVal() {
        return lockedDateVal;
    }

    public void setLockedDateVal(String lockedDateVal) {
        this.lockedDateVal = lockedDateVal;
    }

    public LocalDate getLockedDate() {
        return lockedDate;
    }

    public void setLockedDate(LocalDate lockedDate) {
        this.lockedDate = lockedDate;
    }

    public String getReportScheduledDateVal() {
        return reportScheduledDateVal;
    }

    public void setReportScheduledDateVal(String reportScheduledDateVal) {
        this.reportScheduledDateVal = reportScheduledDateVal;
    }

    public LocalDate getReportScheduledDate() {
        return reportScheduledDate;
    }

    public void setReportScheduledDate(LocalDate reportScheduledDate) {
        this.reportScheduledDate = reportScheduledDate;
    }

    public long getReportsScheduled() {
        return reportsScheduled;
    }

    public void setReportsScheduled(long reportsScheduled) {
        this.reportsScheduled = reportsScheduled;
    }
}
