package com.pinnaxis.sms.model;

public class CurrentWorkload {

    private String caseName;
    private long caseAssignedCount;
    private long criticalCaseCount;
    private long actionItemCount;

    public CurrentWorkload(String caseName, long caseAssignedCount, long criticalCaseCount, long actionItemCount) {
        this.caseName = caseName;
        this.caseAssignedCount = caseAssignedCount;
        this.criticalCaseCount = criticalCaseCount;
        this.actionItemCount = actionItemCount;
    }

    public String getCaseName() {
        return caseName;
    }

    public void setCaseName(String caseName) {
        this.caseName = caseName;
    }

    public long getCaseAssignedCount() {
        return caseAssignedCount;
    }

    public void setCaseAssignedCount(long caseAssignedCount) {
        this.caseAssignedCount = caseAssignedCount;
    }

    public long getCriticalCaseCount() {
        return criticalCaseCount;
    }

    public void setCriticalCaseCount(long criticalCaseCount) {
        this.criticalCaseCount = criticalCaseCount;
    }

    public long getActionItemCount() {
        return actionItemCount;
    }

    public void setActionItemCount(long actionItemCount) {
        this.actionItemCount = actionItemCount;
    }
}
