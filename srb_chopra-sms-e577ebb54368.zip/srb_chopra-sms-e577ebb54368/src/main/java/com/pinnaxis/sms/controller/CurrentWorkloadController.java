package com.pinnaxis.sms.controller;

import com.pinnaxis.sms.model.*;
import com.pinnaxis.sms.services.CurrentWorkloadService;
import com.pinnaxis.sms.services.TrackCaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

import static java.util.stream.Collectors.groupingBy;

@Controller
public class CurrentWorkloadController {

    @Autowired
    private CurrentWorkloadService workloadService;

    @RequestMapping("/current-workload")
    public String currentWorkload(){
        return "track-current-workload";
    }

    @RequestMapping(value = "/currentWorkload", method = RequestMethod.GET)
    public ResponseEntity<?> getCurrentWorkload(@RequestParam(value = "todayDate") String todayDate,
            @RequestParam(value = "groupBy", defaultValue = "group") String groupBy) {
        List<CurrentWorkload> currentWorkloads = workloadService.filterOpenCase(todayDate, groupBy.toLowerCase());
        return ResponseEntity.ok(currentWorkloads);
    }

    @RequestMapping(value = "/actionItemList", method = RequestMethod.GET)
    public ResponseEntity<?> getActionItemList(
            @RequestParam(value = "type", defaultValue = "group") String type,
            @RequestParam(value = "filter") String filter) {
        List<ActionItem> actionItems = workloadService.filterActionItem(type, filter);
        return ResponseEntity.ok(actionItems);
    }

    @RequestMapping(value = "/subCurrentWorkload", method = RequestMethod.GET)
    public String getSubCurrentWorkload(
            @RequestParam(value = "todayDate") String todayDate,
            @RequestParam(value = "type") String type,
            @RequestParam(value = "filter") String filter, Model model) {
        GroupCurrentWorkload groupCurrentWorkload = workloadService.filterOpenCaseByValue(todayDate, type, filter);
        model.addAttribute(groupCurrentWorkload);
        return "sub-current-workload";
    }

}
