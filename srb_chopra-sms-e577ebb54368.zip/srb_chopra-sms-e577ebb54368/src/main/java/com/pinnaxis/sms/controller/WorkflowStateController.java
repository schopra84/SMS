package com.pinnaxis.sms.controller;

import com.pinnaxis.sms.model.SubmissionData;
import com.pinnaxis.sms.model.WorkflowState;
import com.pinnaxis.sms.services.ReportsDataSetService;
import com.pinnaxis.sms.services.TrackCaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class WorkflowStateController {

    private final static String WORKFLOW_STATE_DATA_ENTRY = "Data Entry";
    private final static String WORKFLOW_STATE_QUALITY_REVIEW = "Quality Review";
    private final static String WORKFLOW_STATE_MEDICAL_REVIEW = "Medical Review";
    private final static String WORKFLOW_STATE_DISTRIBUTION = "Distribution";

    @Autowired
    private TrackCaseService trackCaseService;

    @Autowired
    private ReportsDataSetService dataSetService;

    @RequestMapping("/workflow-states")
    public String workflowStates() {
        return "track-open-cases-on-workflow-states";
    }

    @RequestMapping(value = "/getReportDataSet", method = RequestMethod.GET)
    public ResponseEntity<?> getReportDataSet(
            @RequestParam(value = "caseNumber") String caseNumber) {
        List<SubmissionData> dataSet = dataSetService.getReportDataSetsCaseNumber(caseNumber);
        return ResponseEntity.ok(dataSet);
    }

    @RequestMapping("/getDataEntry")
    public String getDataEntry(@RequestParam(value = "todayDate") String todayDateVal, Model model) throws Exception {
        WorkflowState caseData = new WorkflowState(WORKFLOW_STATE_DATA_ENTRY.toUpperCase(), "ion-android-people", false);
        trackCaseService.populateWorkflowStateData(caseData, WORKFLOW_STATE_DATA_ENTRY, todayDateVal);
        model.addAttribute(caseData);
        return "workflowState";
    }

    @RequestMapping("/getQualityReview")
    public String getQualityReview(@RequestParam(value = "todayDate") String todayDateVal, Model model) throws Exception {
        WorkflowState caseData = new WorkflowState(WORKFLOW_STATE_QUALITY_REVIEW.toUpperCase(), "ion-android-checkbox", false);
        trackCaseService.populateWorkflowStateData(caseData, WORKFLOW_STATE_QUALITY_REVIEW, todayDateVal);
        model.addAttribute(caseData);
        return "workflowState";
    }

    @RequestMapping("/getMedicalReview")
    public String getMedicalReview(@RequestParam(value = "todayDate") String todayDateVal, Model model) throws Exception {
        WorkflowState caseData = new WorkflowState(WORKFLOW_STATE_MEDICAL_REVIEW.toUpperCase(), "ion-eye", false);
        trackCaseService.populateWorkflowStateData(caseData, WORKFLOW_STATE_MEDICAL_REVIEW, todayDateVal);
        model.addAttribute(caseData);
        return "workflowState";
    }

    @RequestMapping("/getDistribution")
    public String getDistribution(@RequestParam(value = "todayDate") String todayDateVal, Model model) throws Exception {
        WorkflowState caseData = new WorkflowState(WORKFLOW_STATE_DISTRIBUTION.toUpperCase(), "ion-android-mail", true);
        trackCaseService.populateWorkflowStateData(caseData, WORKFLOW_STATE_DISTRIBUTION, todayDateVal);
        model.addAttribute(caseData);
        return "workflowState";
    }
}
