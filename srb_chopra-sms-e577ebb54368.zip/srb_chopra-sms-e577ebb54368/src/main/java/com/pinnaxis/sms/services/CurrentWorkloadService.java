package com.pinnaxis.sms.services;

import com.pinnaxis.sms.model.*;
import com.pinnaxis.sms.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collector;

import static java.util.stream.Collectors.*;

@Service
public class CurrentWorkloadService {

    private List<String> dueSoon;

    @Autowired
    private DTOService dtoService;

    public CurrentWorkloadService() {
        dueSoon = new ArrayList<>();
        dueSoon.add("0");
        dueSoon.add("1");
        dueSoon.add("2");
    }

    public List<CurrentWorkload> filterOpenCase(String todayDateVal, String filter) {
        List<CurrentWorkload> currentWorkloads = new ArrayList<>();
        List<ActionItem> actionItems = dtoService.loadActionItem();
        Collector collector = null;
        if (filter.equalsIgnoreCase("group")) {
            collector = groupingBy(OpenCase::getGroupName);
        } else if (filter.equalsIgnoreCase("user")) {
            collector = groupingBy(OpenCase::getUserName);
        }
        LocalDate todayDate = CommonUtil.convertStringToDate(todayDateVal, CommonUtil.dateTimeFormatter4);
        List<OpenCase> openCases = dtoService.loadOpenCases(todayDate);
        Map<String, List<OpenCase>> openCasesGrouping =
                (Map<String, List<OpenCase>>) openCases.parallelStream().collect(collector);

        openCasesGrouping.entrySet().stream().forEach(e -> {
            List<OpenCase> openCasesList = e.getValue();
            long criticalCaseCount = openCasesList.parallelStream().filter(i -> dueSoon.contains(i.getDueSoon())).collect(counting());
//            List<String> caseIds = openCasesList.parallelStream().map(OpenCase::getCaseId).collect(toList());
            long actionItemCount = 0;
            if (filter.equalsIgnoreCase("group")) {
                actionItemCount = actionItems.parallelStream().filter(a ->
                        e.getKey().equalsIgnoreCase(a.getGroupName())).collect(counting());
            } else if (filter.equalsIgnoreCase("user")) {
                actionItemCount = actionItems.parallelStream().filter(a ->
                        e.getKey().equalsIgnoreCase(a.getUserFullName())).collect(counting());
            }
            currentWorkloads.add(new CurrentWorkload(e.getKey(), openCasesList.size(), criticalCaseCount, actionItemCount));
        });
        return currentWorkloads;
    }

    public GroupCurrentWorkload filterOpenCaseByValue(String todayDateVal, String filter, String value) {
        List<CurrentWorkload> currentWorkloads = new ArrayList<>();
        List<ActionItem> actionItems = dtoService.loadActionItem();
        Collector collector = null;
        String group = null;
        if (filter.equalsIgnoreCase("group")) {
            collector = groupingBy(OpenCase::getGroupName);
            group = "User";
        } else if (filter.equalsIgnoreCase("user")) {
            collector = groupingBy(OpenCase::getUserName);
            group = "Group";
        }
        LocalDate todayDate = CommonUtil.convertStringToDate(todayDateVal, CommonUtil.dateTimeFormatter4);
        List<OpenCase> openCases = dtoService.loadOpenCases(todayDate);
        List<OpenCase> openCasesListForFilter =
                ((Map<String, List<OpenCase>>) openCases.parallelStream().collect(collector)).get(value);

        if(group.equalsIgnoreCase("Group") ){
            collector = groupingBy(OpenCase::getGroupName);
        } else if(group.equalsIgnoreCase("User") ){
            collector = groupingBy(OpenCase::getUserName);
        }
        Map<String, List<OpenCase>> openCasesGrouping = (Map<String, List<OpenCase>>) openCasesListForFilter.parallelStream().collect(collector);


        openCasesGrouping.entrySet().stream()
                .forEach(e -> {
                    long criticalCaseCount = openCasesListForFilter.parallelStream().filter(i -> dueSoon.contains(i.getDueSoon())).collect(counting());
                    List<String> caseIds = openCasesListForFilter.parallelStream().map(OpenCase::getCaseId).collect(toList());
                    long actionItemCount = actionItems.parallelStream().filter(a -> caseIds.contains(a.getCaseId())).collect(counting());
                    currentWorkloads.add(new CurrentWorkload(e.getKey(), openCasesListForFilter.size(), criticalCaseCount, actionItemCount));
                });
        return new GroupCurrentWorkload(group, currentWorkloads);

    }

    public List<ActionItem> filterActionItem(String filterBy, String value) {
        List<ActionItem> actionItems = dtoService.loadActionItem();;
        return actionItems.parallelStream()
                .filter(a -> {
                    boolean filter = false;
                    switch (filterBy) {
                        case "User":
                            filter = a.getUserFullName().equalsIgnoreCase(value);
                            break;
                        case "Group":
                            filter = a.getGroupName().equalsIgnoreCase(value);
                            break;
                        default:
                            break;
                    }
                    return filter;
                })
                .collect(toList());
    }
}
