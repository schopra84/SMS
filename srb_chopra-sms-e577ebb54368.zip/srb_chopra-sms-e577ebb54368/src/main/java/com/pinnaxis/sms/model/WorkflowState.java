package com.pinnaxis.sms.model;

import java.util.Map;
import java.util.Objects;

public class WorkflowState {

    private String title;
    private long totalCases = 0;
    private String iconType;
    private String titleClass;
    private String panelClass;
    private boolean showCaseDetail;

    Map<String, Long> reportStatus;
    Map<String, Long> dueSoon;
    Map<String, Long> caseSeriousness;
    Map<String, Long> noProgress;

    private long serious = 0;
    private long nonSerious = 0;
    private long unknownSerious = 0;

    public WorkflowState() {
    }

    public WorkflowState(String title, String iconType, boolean showCaseDetail) {
        this.title = title;
        this.iconType = iconType;
        this.showCaseDetail = showCaseDetail;
    }

    public WorkflowState(String title, String iconType, String titleClass, String panelClass) {
        this.title = title;
        this.iconType = iconType;
        this.titleClass = titleClass;
        this.panelClass = panelClass;
    }

    public String getTitle() {
        return title;
    }

    public long getTotalCases() {
        return totalCases;
    }

    public void setTotalCases(long totalCases) {
        this.totalCases = totalCases;
    }

    public void incrementTotalCases() {
        this.totalCases++;
    }

    public String getIconType() {
        return iconType;
    }

    public void setIconType(String iconType) {
        this.iconType = iconType;
    }

    public long getSerious() {
        return serious;
    }

    public void setSerious(long serious) {
        this.serious = serious;
    }

    public void incrementSerious() {
        this.serious++;
    }

    public long getNonSerious() {
        return nonSerious;
    }

    public void setNonSerious(long nonSerious) {
        this.nonSerious = nonSerious;
    }

    public void incrementNonSerious() {
        this.nonSerious++;
    }

    public long getUnknownSerious() {
        return unknownSerious;
    }

    public void setUnknownSerious(long unknownSerious) {
        this.unknownSerious = unknownSerious;
    }

    public void incrementUnknownSerious() {
        this.unknownSerious++;
    }

    public String getTitleClass() {
        return titleClass;
    }

    public void setTitleClass(String titleClass) {
        this.titleClass = titleClass;
    }

    public String getPanelClass() {
        return panelClass;
    }

    public void setPanelClass(String panelClass) {
        this.panelClass = panelClass;
    }

    public Map<String, Long> getReportStatus() {
        return reportStatus;
    }

    public void setReportStatus(Map<String, Long> reportStatus) {
        this.reportStatus = reportStatus;
    }

    public Map<String, Long> getDueSoon() {
        return dueSoon;
    }

    public void setDueSoon(Map<String, Long> dueSoon) {
        this.dueSoon = dueSoon;
    }

    public Map<String, Long> getCaseSeriousness() {
        return caseSeriousness;
    }

    public void setCaseSeriousness(Map<String, Long> caseSeriousness) {
        this.caseSeriousness = caseSeriousness;
    }

    public Map<String, Long> getNoProgress() {
        return noProgress;
    }

    public void setNoProgress(Map<String, Long> noProgress) {
        this.noProgress = noProgress;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isShowCaseDetail() {
        return showCaseDetail;
    }

    public void setShowCaseDetail(boolean showCaseDetail) {
        this.showCaseDetail = showCaseDetail;
    }
}
