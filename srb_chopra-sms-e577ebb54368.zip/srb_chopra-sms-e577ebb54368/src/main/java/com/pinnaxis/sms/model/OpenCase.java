package com.pinnaxis.sms.model;

import com.pinnaxis.sms.util.CommonUtil;

import java.time.LocalDate;
import java.util.Objects;

public class OpenCase {

    private String workflowStateCategory, stateName, caseId, caseNumber, studyNum, productName,
            genericName, eventVerbatim, eventName, reportType, country, groupName, userName, dueSoon, caseSeriousness,
            caseCausality, noProgress,
            receiptDateVal, awareDateVal, probability;

    private LocalDate receiptDate, awareDate, deletedDate, lastUpdateTime;

    public OpenCase(String workflowStateCategory, String stateName, String caseId, String caseNumber,
                    LocalDate receiptDate, LocalDate awareDate, String studyNum, String productName, String genericName,
                    String eventVerbatim, String eventName, String reportType, String country, String groupName,
                    String userName, String dueSoon, String caseSeriousness, String caseCausality, String noProgress,
                    LocalDate deletedDate, LocalDate lastUpdateTime) {
        this.workflowStateCategory = workflowStateCategory;
        this.stateName = stateName;
        this.caseId = caseId;
        this.caseNumber = caseNumber;
        this.receiptDate = receiptDate;
        this.awareDate = awareDate;
        this.studyNum = studyNum;
        this.productName = productName;
        this.genericName = genericName;
        this.eventName = eventName;
        this.eventVerbatim = eventVerbatim;
        this.reportType = reportType;
        this.country = country;
        this.groupName = groupName;
        this.userName = userName;
        this.dueSoon = dueSoon;
        this.noProgress = noProgress;
        this.caseSeriousness = caseSeriousness;
        this.caseCausality = caseCausality;
        this.deletedDate = deletedDate;
        this.lastUpdateTime = lastUpdateTime;

        if(Objects.nonNull(receiptDate)) {
            this.receiptDateVal = CommonUtil.dateTimeFormatter1.format(receiptDate);
        }
        if(Objects.nonNull(awareDate)) {
            this.awareDateVal = CommonUtil.dateTimeFormatter1.format(awareDate);
        }
    }

    public String getWorkflowStateCategory() {
        return workflowStateCategory;
    }

    public void setWorkflowStateCategory(String workflowStateCategory) {
        this.workflowStateCategory = workflowStateCategory;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public String getStudyNum() {
        return studyNum;
    }

    public void setStudyNum(String studyNum) {
        this.studyNum = studyNum;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getGenericName() {
        return genericName;
    }

    public void setGenericName(String genericName) {
        this.genericName = genericName;
    }

    public String getEventVerbatim() {
        return eventVerbatim;
    }

    public void setEventVerbatim(String eventVerbatim) {
        this.eventVerbatim = eventVerbatim;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getReportType() {
        return reportType;
    }

    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getDueSoon() {
        return dueSoon;
    }

    public void setDueSoon(String dueSoon) {
        this.dueSoon = dueSoon;
    }

    public String getCaseSeriousness() {
        return caseSeriousness;
    }

    public void setCaseSeriousness(String caseSeriousness) {
        this.caseSeriousness = caseSeriousness;
    }

    public String getCaseCausality() {
        return caseCausality;
    }

    public void setCaseCausality(String caseCausality) {
        this.caseCausality = caseCausality;
    }

    public String getNoProgress() {
        return noProgress;
    }

    public void setNoProgress(String noProgress) {
        this.noProgress = noProgress;
    }

    public String getReceiptDateVal() {
        return receiptDateVal;
    }

    public void setReceiptDateVal(String receiptDateVal) {
        this.receiptDateVal = receiptDateVal;
    }

    public String getAwareDateVal() {
        return awareDateVal;
    }

    public void setAwareDateVal(String awareDateVal) {
        this.awareDateVal = awareDateVal;
    }

    public LocalDate getReceiptDate() {
        return receiptDate;
    }

    public void setReceiptDate(LocalDate receiptDate) {
        this.receiptDate = receiptDate;
    }

    public LocalDate getAwareDate() {
        return awareDate;
    }

    public void setAwareDate(LocalDate awareDate) {
        this.awareDate = awareDate;
    }

    public String getProbability() {
        return probability;
    }

    public void setProbability(String probability) {
        this.probability = probability;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public LocalDate getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(LocalDate deletedDate) {
        this.deletedDate = deletedDate;
    }

    public LocalDate getLastUpdateTime() {
        return lastUpdateTime;
    }

    public void setLastUpdateTime(LocalDate lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }
}
