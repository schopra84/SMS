package com.pinnaxis.sms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;

@EntityScan( basePackageClasses = {SmsApplication.class, Jsr310JpaConverters.class})
@SpringBootApplication
@EnableCaching
public class SmsApplication {
    public static void main(String[] args){
        SpringApplication.run(SmsApplication.class, args);
    }
}
