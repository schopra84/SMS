package com.pinnaxis.sms.services;

import com.pinnaxis.sms.dao.model.PendingSubmissionsInfo;
import com.pinnaxis.sms.dao.model.QualityInfo;
import com.pinnaxis.sms.dao.model.ReceivedCasesInfo;
import com.pinnaxis.sms.dao.model.WorkloadInfo;
import com.pinnaxis.sms.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import java.time.temporal.ChronoUnit;

@Service
public class DTOService {

    @Autowired
    private CacheService cacheService;

    private static ClosedCaseAnalysis apply(ReceivedCasesInfo i) {
        return new ClosedCaseAnalysis(i.getCaseId().toString(), i.getCaseNum(),  i.getCaseType(), i.getReportType(),
                i.getCountry(), i.getSeriousness(), i.getSusar(), i.getInitReptDate(), i.getReceiptDate(),
                i.getStudyNum(), i.getProductName(), i.getProductName(), i.getEventVerbatim(), i.getEventName(),
                i.getRouteDate(), i.getProcessingTime(),
                i.getDeletedDate());
    }

    private static ActionItem apply(WorkloadInfo i) {
        return new ActionItem(i.getCaseId().toString(), i.getCaseNum(), i.getStateName(), i.getGroupName(), i.getSigReceiptDate(),
                i.getAwareDate(), i.getUserName(), i.getDescription(), i.getDateOpen(), i.getDueDate(), i.getActionType(),
                i.getAssignedUserName(), i.getAssignedGroupName());
    }

    private static CaseDataQuality apply(QualityInfo i) {
        return new CaseDataQuality(i.getCaseId().toString(), i.getCaseNum(),
                i.getAwareDate(), i.getReportType(), i.getCountry(), i.getStudyNum(), i.getProductName(),
                i.getErrorId().intValue(), i.getWorkflowCategory(), i.getOpenCloseCase(), i.getResponsibleUser(), i.getErrorSeverity()
        , i.getErrorWorkflow(), i.getErrorMessage());
    }

    private static CaseReceivedAndClosed apply2(ReceivedCasesInfo i) {
        return new CaseReceivedAndClosed(i.getCaseNum(), i.getCaseId().toString(), i.getInitReptDate(),
                i.getSigReceiptDate(), i.getFolloupType(), i.getReceiptDate());
    }

    private static SubmissionData apply(PendingSubmissionsInfo i) {
        return new SubmissionData(i.getCaseNum(), i.getReportForm(), i.getAgencyName(), i.getLockDate(),
                i.getFlagForSubmissionScreen(), i.getDateScheduled(),i.getDateSubmitted(),
                i.getGenerationError(), i.getStatusText());
    }

    public List<OpenCase> loadOpenCases(LocalDate todayDate) {
        return cacheService.getCaseDetails().stream().map(c -> {
            String dueSoon = getDueSoon(todayDate, c.getDueSoon());
            String lastUpdate = getLastUpdate(c.getLastUpdateTime(), todayDate);
            return new OpenCase(c.getWorkflowCategory(), c.getStateName(), c.getCaseId().toString(), c.getCaseNum(), c.getSigReceiptDate(),
                    c.getAwareDate(), c.getStudyNum(), c.getProductName(), c.getGenericName(), c.getEventVerbatim(),
                    c.getEventName(), c.getReportType(), c.getCountry(), c.getGroupName(), c.getUserName(),
                    dueSoon, c.getSeriousness(), c.getCaseCausality(), lastUpdate, c.getDeletedDate(), c.getLastUpdateTime());
        }).collect(Collectors.toList());
    }

    public List<ClosedCaseAnalysis> loadClosedCaseAnalysis() {
        return cacheService.getReceivedCases().stream().map(DTOService::apply).collect(Collectors.toList());
    }

    public List<ActionItem> loadActionItem() {
        return cacheService.getWorkload().stream().map(DTOService::apply).collect(Collectors.toList());
    }

    public List<CaseDataQuality> loadCaseDataQuality() {
        return cacheService.getQualityDetails().stream().map(DTOService::apply).collect(Collectors.toList());
    }

    public List<SubmissionData> loadSubmissionData() {
        return cacheService.getPendingSubmissions().stream().map(DTOService::apply).collect(Collectors.toList());
    }

    public List<CaseReceivedAndClosed> loadCaseReceivedAndClosed() {
        return cacheService.getReceivedCases().stream().map(DTOService::apply2).collect(Collectors.toList());
    }

    private String getDueSoon(LocalDate start, LocalDate end) {
        long dueSoon = ChronoUnit.DAYS.between(start, end);
        String dueSoonVal;
        if(dueSoon < -3) {
            dueSoonVal = "<-3";
        } else if(dueSoon > 3) {
            dueSoonVal = ">3";
        } else {
            dueSoonVal = String.valueOf(dueSoon);
        }
        return dueSoonVal;
    }

    private String getLastUpdate(LocalDate start, LocalDate end) {
        long lastUpdate = ChronoUnit.DAYS.between(start, end);
        String lastUpdateVal;
        if(lastUpdate < 0) {
            lastUpdateVal = "0";
        } else if(lastUpdate > 5) {
            lastUpdateVal = ">5";
        } else {
            lastUpdateVal = String.valueOf(lastUpdate);
        }
        return lastUpdateVal;
    }
}
