package com.pinnaxis.sms.model;

import com.pinnaxis.sms.util.CommonUtil;

import java.time.LocalDate;
import java.util.Objects;

public class ActionItem {
    private String caseId, caseNum, stateName, groupName, userFullName,
            description, actionType, actionAssignedTo, actionAssignedGroup,
            receiptDateVal, awareDateVal, openDateVal, dueDateVal;

    private LocalDate receiptDate, awareDate, openDate, dueDate;

    public ActionItem(String caseId, String caseNum, String stateName, String groupName, LocalDate receiptDate,
                      LocalDate awareDate, String userFullName, String description, LocalDate openDate, LocalDate dueDate,
                      String actionType, String actionAssignedTo, String actionAssignedGroup) {
        this.caseId = caseId;
        this.caseNum = caseNum;
        this.stateName = stateName;
        this.groupName = groupName;
        this.receiptDate = receiptDate;
        this.awareDate = awareDate;
        this.userFullName = userFullName;
        this.description = description;
        this.openDate = openDate;
        this.dueDate = dueDate;
        this.actionType = actionType;
        this.actionAssignedTo = actionAssignedTo;
        this.actionAssignedGroup = actionAssignedGroup;

        if(Objects.nonNull(receiptDate)) {
            this.receiptDateVal = CommonUtil.dateTimeFormatter1.format(receiptDate);
        }
        if(Objects.nonNull(awareDate)) {
            this.awareDateVal = CommonUtil.dateTimeFormatter1.format(awareDate);
        }
        if(Objects.nonNull(openDate)) {
            this.openDateVal = CommonUtil.dateTimeFormatter1.format(openDate);
        }
        if(Objects.nonNull(dueDate)) {
            this.dueDateVal = CommonUtil.dateTimeFormatter1.format(dueDate);
        }
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public String getCaseNum() {
        return caseNum;
    }

    public void setCaseNum(String caseNum) {
        this.caseNum = caseNum;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public String getUserFullName() {
        return userFullName;
    }

    public void setUserFullName(String userFullName) {
        this.userFullName = userFullName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getActionAssignedTo() {
        return actionAssignedTo;
    }

    public void setActionAssignedTo(String actionAssignedTo) {
        this.actionAssignedTo = actionAssignedTo;
    }

    public String getActionAssignedGroup() {
        return actionAssignedGroup;
    }

    public void setActionAssignedGroup(String actionAssignedGroup) {
        this.actionAssignedGroup = actionAssignedGroup;
    }

    public String getReceiptDateVal() {
        return receiptDateVal;
    }

    public void setReceiptDateVal(String receiptDateVal) {
        this.receiptDateVal = receiptDateVal;
    }

    public String getAwareDateVal() {
        return awareDateVal;
    }

    public void setAwareDateVal(String awareDateVal) {
        this.awareDateVal = awareDateVal;
    }

    public String getOpenDateVal() {
        return openDateVal;
    }

    public void setOpenDateVal(String openDateVal) {
        this.openDateVal = openDateVal;
    }

    public String getDueDateVal() {
        return dueDateVal;
    }

    public void setDueDateVal(String dueDateVal) {
        this.dueDateVal = dueDateVal;
    }

    public LocalDate getReceiptDate() {
        return receiptDate;
    }

    public void setReceiptDate(LocalDate receiptDate) {
        this.receiptDate = receiptDate;
    }

    public LocalDate getAwareDate() {
        return awareDate;
    }

    public void setAwareDate(LocalDate awareDate) {
        this.awareDate = awareDate;
    }

    public LocalDate getOpenDate() {
        return openDate;
    }

    public void setOpenDate(LocalDate openDate) {
        this.openDate = openDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
}
