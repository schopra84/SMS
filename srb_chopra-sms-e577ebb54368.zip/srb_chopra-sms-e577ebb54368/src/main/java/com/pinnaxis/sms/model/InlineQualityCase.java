package com.pinnaxis.sms.model;

import java.util.Map;

public class InlineQualityCase {

    private String title;
    private long totalCases = 0;
    private String iconType;
    private String titleClass;
    private String panelClass;
    private boolean showCaseDetail;
    private String panelTitle;

    private long criticalErrors = 0;
    private long highErrors = 0;
    private long mediumErrors = 0;
    private long lowErrors = 0;
    private long noErrors = 0;

    public InlineQualityCase() {
    }

    public InlineQualityCase(String title, String iconType, boolean showCaseDetail, String panelTitle) {
        this.title = title;
        this.iconType = iconType;
        this.showCaseDetail = showCaseDetail;
        this.panelTitle = panelTitle;
    }

    public InlineQualityCase(String title, String iconType, String titleClass, String panelClass) {
        this.title = title;
        this.iconType = iconType;
        this.titleClass = titleClass;
        this.panelClass = panelClass;
    }

    public String getTitle() {
        return title;
    }

    public long getTotalCases() {
        return totalCases;
    }

    public void setTotalCases(long totalCases) {
        this.totalCases = totalCases;
    }

    public void incrementTotalCases() {
        this.totalCases++;
    }

    public String getIconType() {
        return iconType;
    }

    public void setIconType(String iconType) {
        this.iconType = iconType;
    }

    public String getTitleClass() {
        return titleClass;
    }

    public void setTitleClass(String titleClass) {
        this.titleClass = titleClass;
    }

    public String getPanelClass() {
        return panelClass;
    }

    public void setPanelClass(String panelClass) {
        this.panelClass = panelClass;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isShowCaseDetail() {
        return showCaseDetail;
    }

    public void setShowCaseDetail(boolean showCaseDetail) {
        this.showCaseDetail = showCaseDetail;
    }

    public String getPanelTitle() {
        return panelTitle;
    }

    public void setPanelTitle(String panelTitle) {
        this.panelTitle = panelTitle;
    }

    public long getCriticalErrors() {
        return criticalErrors;
    }

    public void setCriticalErrors(long criticalErrors) {
        this.criticalErrors = criticalErrors;
    }

    public long getHighErrors() {
        return highErrors;
    }

    public void setHighErrors(long highErrors) {
        this.highErrors = highErrors;
    }

    public long getMediumErrors() {
        return mediumErrors;
    }

    public void setMediumErrors(long mediumErrors) {
        this.mediumErrors = mediumErrors;
    }

    public long getLowErrors() {
        return lowErrors;
    }

    public void setLowErrors(long lowErrors) {
        this.lowErrors = lowErrors;
    }

    public long getNoErrors() {
        return noErrors;
    }

    public void setNoErrors(long noErrors) {
        this.noErrors = noErrors;
    }
}
